create trigger WILD_ANIMALS_CITES_TRG
  instead of insert or update
  on WILD_ANIMALS_CITES
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW."ID_WILD_ANIMAL_CITES" IS NULL THEN 
              :NEW."ID_WILD_ANIMAL_CITES":="WILD_ANIMALS_CITES_SEQ".NEXTVAL; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    --  запоминаем ID_GOODS_GROUP "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_WILD_ANIMAL_CITES";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

      INSERT INTO WILD_ANIMALS_CITES_HISTORY (
        ID_WILD_ANIMAL_CITES,
        IS_ACTUAL,
        CODE_TNVED,
        ID_PARENT,
        ANIMALS,
        CLASS_LAT,
        CLASS_RU,
        SUBCLASS_LAT,
        SUBCLASS_RU,
        ORDER_LAT,
        ORDER_RU,
        SUBORDER_LAT,
        SUBORDER_RU,
        FAMILY_LAT,
        FAMILY_RU,
        SUBFAMILY_LAT,
        SUBFAMILY_RU,
        GENUS_LAT,
        GENUS_RU,
        SPECIES_LAT,
        SPECIES_RU,
        NUM_ATTACHMENT_CITES,
        OBTAINED_PRODUCT,
        DATE_CHANGE,
        TYPE_OPERATION,
        ID_USER
      )
      VALUES (
        :NEW."ID_WILD_ANIMAL_CITES",
        :NEW."IS_ACTUAL",
        :NEW."CODE_TNVED",
        :NEW."ID_PARENT",
        :NEW."ANIMALS",
        :NEW."CLASS_LAT",
        :NEW."CLASS_RU",
        :NEW."SUBCLASS_LAT",
        :NEW."SUBCLASS_RU",
        :NEW."ORDER_LAT",
        :NEW."ORDER_RU",
        :NEW."SUBORDER_LAT",
        :NEW."SUBORDER_RU",
        :NEW."FAMILY_LAT",
        :NEW."FAMILY_RU",
        :NEW."SUBFAMILY_LAT",
        :NEW."SUBFAMILY_RU",
        :NEW."GENUS_LAT",
        :NEW."GENUS_RU",
        :NEW."SPECIES_LAT",
        :NEW."SPECIES_RU",
        :NEW."NUM_ATTACHMENT_CITES",
        :NEW."OBTAINED_PRODUCT",
        SYSDATE,
        TYPE_OPER,
        1   
      );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE WILD_ANIMALS_CITES SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(COUNTER);
    END AFTER STATEMENT;
END WILD_ANIMALS_CITES_TRG;
/

