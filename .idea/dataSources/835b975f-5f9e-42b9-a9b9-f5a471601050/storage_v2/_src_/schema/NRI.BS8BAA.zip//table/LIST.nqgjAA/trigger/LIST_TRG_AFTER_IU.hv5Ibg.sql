create trigger LIST_TRG_AFTER_IU
  after insert or update
  on LIST
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;
  
  INSERT INTO LIST_HISTORY (
    ID_LIST,
    IS_ACTUAL,
    IS_SYSTEM,
    NAME_LIST,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER, NOTE
  )
  VALUES (
    :NEW."ID_LIST",
    :NEW."IS_ACTUAL",
    :NEW."IS_SYSTEM",
    :NEW."NAME_LIST",
    SYSDATE,
    TYPE_OPER,
    1,:NEW."NOTE"  
  );
  
END;
/

