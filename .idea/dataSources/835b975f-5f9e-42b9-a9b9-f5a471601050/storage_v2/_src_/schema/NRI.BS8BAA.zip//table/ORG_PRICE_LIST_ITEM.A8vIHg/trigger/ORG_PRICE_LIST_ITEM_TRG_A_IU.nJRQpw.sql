create trigger ORG_PRICE_LIST_ITEM_TRG_A_IU
  after insert or update
  on ORG_PRICE_LIST_ITEM
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;

  INSERT INTO ORG_PRICE_LIST_ITEM_HISTORY (
    ID_ORG_PRICE_LIST_ITEM,
    IS_ACTUAL,
    ID_ORG_PRICE_LIST,
    ORDERBY_ITEM,
    NAME,
    ID_MEASURE,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER,
    COST_WITHOUT_VAT,
    VAT,
    COST_VAT, 
    COST_WITH_VAT
   ) 
  VALUES (
    :NEW."ID_ORG_PRICE_LIST_ITEM", 
    :NEW."IS_ACTUAL", 
    :NEW."ID_ORG_PRICE_LIST", 
    :NEW."ORDERBY_ITEM", 
    :NEW."NAME", 
    :NEW."ID_MEASURE", 
     sysdate,
     TYPE_OPER,
     1,
     :NEW."COST_WITHOUT_VAT",
     :NEW."VAT",
     :NEW."COST_VAT", 
     :NEW."COST_WITH_VAT");
  
END;
/

