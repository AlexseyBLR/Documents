create trigger ORGANIZATION_TRG
  instead of insert or update
  on ORGANIZATION
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW."ID_ORGANIZATION" IS NULL THEN 
              :NEW."ID_ORGANIZATION":="ORGANIZATION_SEQ".NEXTVAL ; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    --  запоминаем ID_GOODS_GROUP "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_ORGANIZATION";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

    INSERT INTO ORGANIZATION_HISTORY (
      ID_ORGANIZATION, 
      UNP, 
      REG_NUMBER,
      IS_ACTUAL, 
      IS_ORGANIZATION, 
      CONDITION_CODE, 
      CONDITION_NAME, 
      ID_PARENT, 
      NAME_FULL_RU,
      NAME_SHORT_RU,
      NAME_BM_FIO_RU, 
      ORG_LEGAL_CODE,
      ORG_LEGAL_FORM, 
      FOUNDER_CODE, 
      FOUNDER,
      FOUNDER_SHARE,
      ORG_PARENT_CODE, 
      ORG_PARENT_NAME, 
      OKED_CODE, 
      OKED_NAME, 
      UNP_MNS, 
      TAX_ORG_CODE, 
      TAX_ORG_NAME, 
      PAYER_STATUS_CODE,
      PAYER_STATUS_NAME,
      REQ_GOODS_GROUP, 
      REQ_LICENSE,
      ID_LICENSE,
      REQ_AUCTION_PLACE, 
      ID_KIND_YO, 
      DATE_CHANGE,
      TYPE_OPERATION, 
      ID_USER,
      NAME_FULL_BY, 
      NAME_SHORT_BY, 
      NAME_BM_FIO_BY) 
VALUES ( 
      :NEW."ID_ORGANIZATION" ,
      :NEW."UNP" ,
      :NEW."REG_NUMBER",
      :NEW."IS_ACTUAL" ,
      :NEW."IS_ORGANIZATION" ,
      :NEW."CONDITION_CODE" ,
      :NEW."CONDITION_NAME",
      :NEW."ID_PARENT" ,
      :NEW."NAME_FULL_RU" ,
      :NEW."NAME_SHORT_RU" ,
      :NEW."NAME_BM_FIO_RU" ,
      :NEW."ORG_LEGAL_CODE" ,
      :NEW."ORG_LEGAL_FORM" ,
      :NEW."FOUNDER_CODE" ,
      :NEW."FOUNDER" ,
      :NEW."FOUNDER_SHARE" ,
      :NEW."ORG_PARENT_CODE" ,
      :NEW."ORG_PARENT_NAME" ,
      :NEW."OKED_CODE" ,
      :NEW."OKED_NAME" ,
      :NEW."UNP_MNS" ,
      :NEW."TAX_ORG_CODE" ,
      :NEW."TAX_ORG_NAME" ,
      :NEW."PAYER_STATUS_CODE" ,
      :NEW."PAYER_STATUS_NAME" ,
      :NEW."REQ_GOODS_GROUP" ,
      :NEW."REQ_LICENSE" ,
      :NEW."ID_LICENSE" ,
      :NEW."REQ_AUCTION_PLACE" ,
      :NEW."ID_KIND_YO",
      sysdate,
      TYPE_OPER,
      1,
      :NEW."NAME_FULL_BY",
      :NEW."NAME_SHORT_BY", 
      :NEW."NAME_BM_FIO_BY"
      );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FOR INDX IN 1..ID_UDPATE.COUNT() LOOP
        --FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE ORGANIZATION SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(INDX);
            PKG_MANAGE_CONSTAINTS.SET_IS_ACTUAL_ORG_CASCADE(ID_UDPATE(INDX), 0);
        END LOOP;    
    END AFTER STATEMENT;
END ORGANIZATION_TRG;
/

