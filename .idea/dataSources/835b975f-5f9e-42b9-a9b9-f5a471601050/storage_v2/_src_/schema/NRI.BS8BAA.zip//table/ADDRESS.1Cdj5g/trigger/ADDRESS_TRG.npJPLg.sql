create trigger ADDRESS_TRG
  before insert
  on ADDRESS
  for each row
  BEGIN
  if :NEW."ID_ADDRESS" is null then 
    :NEW."ID_ADDRESS":="ADDRESS_SEQ".nextval; 
  end if;
END;
/

