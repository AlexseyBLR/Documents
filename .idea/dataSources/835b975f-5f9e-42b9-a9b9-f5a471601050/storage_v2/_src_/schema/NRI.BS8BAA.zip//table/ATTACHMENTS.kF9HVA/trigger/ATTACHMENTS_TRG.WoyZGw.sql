create trigger ATTACHMENTS_TRG
  before insert
  on ATTACHMENTS
  for each row
  BEGIN
  if :NEW."ID_ATTACHMENT" is null then 
    :NEW."ID_ATTACHMENT":="ATTACHMENTS_SEQ".nextval; 
  end if;
END;
/

