create trigger CONTACT_TRG_AFTER_IU
  after insert or update
  on CONTACT
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1;  
      END IF;
  END CASE;
  
  INSERT INTO CONTACT_HISTORY (
    ID_CONTACT,
    IS_ACTUAL,
    CONTACT_TYPE,
    ID_ORGANIZATION,
    ID_EMPLOYEES,
    PHONE_NUMBER,
    FAX,
    MAIL,
    SITE,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER 
  )
  VALUES (
    :NEW."ID_CONTACT",
    :NEW."IS_ACTUAL",
    :NEW."CONTACT_TYPE",
    :NEW."ID_ORGANIZATION",
    :NEW."ID_EMPLOYEES",
    :NEW."PHONE_NUMBER",
    :NEW."FAX",
    :NEW."MAIL",
    :NEW."SITE",
    SYSDATE,
    TYPE_OPER,
    1   
  );
  
END;
/

