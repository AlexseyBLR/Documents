create trigger ATE_STREETS_TRG
  before insert
  on ATE_STREETS
  for each row
  BEGIN
     IF INSERTING AND :NEW.ID_STREET IS NULL THEN
        :NEW.ID_STREET:=ATE_STREETS_SEQ.NEXTVAL; 
    END IF;
 
END;
/

