create trigger NOTIF_TYPE_TRG
  before insert
  on NOTIF_TYPE
  for each row
  BEGIN
  
    IF INSERTING AND :NEW.ID_NOTIF_TYPE IS NULL THEN
       :NEW.ID_NOTIF_TYPE:=NOTIF_TYPE_SEQ.NEXTVAL ;
    END IF;
END;
/

