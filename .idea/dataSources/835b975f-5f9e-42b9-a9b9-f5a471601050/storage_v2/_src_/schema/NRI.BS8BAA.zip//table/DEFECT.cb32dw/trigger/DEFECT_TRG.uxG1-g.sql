create trigger DEFECT_TRG
  before insert
  on DEFECT
  for each row
  BEGIN
    IF INSERTING AND :NEW.ID_DEFECT IS NULL THEN
      :NEW.ID_DEFECT:=DEFECT_SEQ.NEXTVAL;
    END IF;

END;
/

