create trigger CONTACT_TRG
  before insert
  on CONTACT
  for each row
  BEGIN
  if :NEW."ID_CONTACT" is null then 
    :NEW."ID_CONTACT":="CONTACT_SEQ".nextval; 
  end if;
END;
/

