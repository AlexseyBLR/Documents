create trigger DRUG_TRG
  instead of insert or update
  on DRUG
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW.ID_DRUG IS NULL THEN 
             :NEW.ID_DRUG:=DRUG_SEQ.NEXTVAL; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    --  запоминаем ID_DRUG "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_DRUG";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

        INSERT INTO DRUG_HISTORY (
            ID_DRUG,
            IS_ACTUAL,
            DATE_START,
            DATE_FINISH,
            ID_PARENT,
            CODE_DRUG,
            NAME_DRUG,
            CHEMICAL_DESCRIPTION,
            CONCENTRATION,
            DATE_CHANGE,
            TYPE_OPERATION,
            ID_USER
          )
          VALUES (
            :NEW."ID_DRUG",
            :NEW."IS_ACTUAL",
            :NEW."DATE_START",
            :NEW."DATE_FINISH",
            :NEW."ID_PARENT",
            :NEW."CODE_DRUG",
            :NEW."NAME_DRUG",
            :NEW."CHEMICAL_DESCRIPTION",
            :NEW."CONCENTRATION",
            SYSDATE,
            TYPE_OPER,
            1   
          );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE DRUG SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(COUNTER);
    END AFTER STATEMENT;
END DRUG_TRG;
/

