create trigger COURRENCY_HISTORY_TRG
  before insert
  on CURRENCY_HISTORY
  for each row
  BEGIN
  if :NEW."ID_CURRENCY_HISTORY" is null then 
    :NEW."ID_CURRENCY_HISTORY":="CURRENCY_HISTORY_SEQ".nextval; 
  end if;
END;
/

