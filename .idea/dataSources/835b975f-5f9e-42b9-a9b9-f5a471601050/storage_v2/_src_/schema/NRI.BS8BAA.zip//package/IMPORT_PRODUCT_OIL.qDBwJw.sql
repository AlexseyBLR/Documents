create PACKAGE     IMPORT_PRODUCT_OIL
IS
---------------------------------------------------
----   загрузка данных из файла  загруженного из сайта www. belneftekhim. by и сохраненного в формате .csv
--          Прейскурант № 3					
--     «Розничные цены на нефтепродукты, реализуемые через АЗС»					
---------------------  
   
    FUNCTION ALL_FILES  RETURN NUMBER ;
    FUNCTION LOAD_FILE_BLOB(P_FILE_NAME VARCHAR2)  RETURN NUMBER ;
    FUNCTION OIL_PRODUCT_ONE_ROW( IMPORTED_ROW NUMBER,FHANDLE_LOG  UTL_FILE.FILE_TYPE,IN_MUM_ITEM NUMBER,IN_ID_LIST NUMBER) RETURN NUMBER;
    FUNCTION OIL_PRODUCT_IMPORT( FILE_NAME VARCHAR2)  RETURN NUMBER ;
    
    
   
END IMPORT_PRODUCT_OIL;
/

