create trigger DEFECT_GG_TRG
  before insert
  on DEFECT_GG
  for each row
  BEGIN
    IF INSERTING AND :NEW.ID_DEFECT_GG IS NULL THEN
      :NEW.ID_DEFECT_GG:=DEFECT_GG_SEQ.NEXTVAL ;
    END IF;
END;
/

