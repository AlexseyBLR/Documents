create trigger BASE_AMOUNT_TRG
  before insert
  on BASE_AMOUNT
  for each row
  BEGIN   
  IF :NEW.ID IS NULL THEN
    :NEW.ID := BASE_AMOUNT_SEQ.NEXTVAL;
  END IF; 
END;
/

