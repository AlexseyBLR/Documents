create trigger DEFECT_GG_TRG_AFTER_IU
  after insert or update
  on DEFECT_GG
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;
  
  INSERT INTO DEFECT_GG_HISTORY (
    ID_DEFECT_GG,
    ID_DEFECT,
    ID_GOODS_GROUP,
    ID_REASON_OF_DECREASE,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER  
  )
  VALUES (
    :NEW."ID_DEFECT_GG",
    :NEW."ID_DEFECT",
    :NEW."ID_GOODS_GROUP",
    :NEW."ID_REASON_OF_DECREASE",
    SYSDATE,
    TYPE_OPER,
    1   
  );
  
END;
/

