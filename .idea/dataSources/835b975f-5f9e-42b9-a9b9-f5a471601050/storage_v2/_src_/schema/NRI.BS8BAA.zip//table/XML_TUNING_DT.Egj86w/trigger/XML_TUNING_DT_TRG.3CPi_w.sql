create trigger XML_TUNING_DT_TRG
  before insert
  on XML_TUNING_DT
  for each row
  BEGIN
  if :NEW."ID_XML_TUNING_DT" is null then 
    :NEW."ID_XML_TUNING_DT":="XML_TUNING_DT_SEQ".nextval; 
  end if;
END;
/

