create PACKAGE     PKG_ID_ORG_TYPE
IS

    FUNCTION DEPARTAMENT_ID RETURN NUMBER; -- ID Департамента как организации    

    -- Типы организаций
    FUNCTION DEPARTMENT RETURN NUMBER;                      --Департамент
    FUNCTION AUTHORIZED_AGENCY RETURN NUMBER;               --Уполномоченные органы
    FUNCTION COMPETENT_AUTHORITY RETURN NUMBER;             --Компетентные органы
    FUNCTION SELLER RETURN NUMBER;                          --Реализующие организации
    FUNCTION AUCTION RETURN NUMBER;                         --Организаторы аукционов
    FUNCTION EXPERT_APPRAISERS RETURN NUMBER;               --Эксперты-оценщики
    FUNCTION KEEPER RETURN NUMBER;                          --Хранители
    FUNCTION UTILIZATION RETURN NUMBER;                     --Организации промышленной переработки и утилизации
    FUNCTION QUALITY_SAFETY_INSPECTION RETURN NUMBER;       --Организации по проведению работ по проверке на качество и безопасность
    FUNCTION OTHER_TYPE_EXPERTISE RETURN NUMBER;            --Организации правомочные проводить иные виды работ (экспертиз)
    FUNCTION DESTRUCTION_GOODS RETURN NUMBER;               --Организации осуществляющие уничтожение имущества
    FUNCTION EXTRACTION_NON_METAL_MINERALS RETURN NUMBER;   --Предприятия, занимающиеся добычей нерудных полезных ископаемых
    FUNCTION ACCOUNTS_STATE_AGENCY RETURN NUMBER;           --Государственные органы на счетах которых могут отражаться денежные средства полученные от реализации
    FUNCTION GOODS_IDENTIFICATION RETURN NUMBER;            --Организации осуществляющие идентификацию имущества
    FUNCTION GOODS_EXPERT RETURN NUMBER;                    --Организации специалисты (товароведы) которых привлекаются к приемке имущества, проведению товароведческой экспертизы
    FUNCTION CONDITIONS_FOR_WILD_ANIMALS RETURN NUMBER;     --Организации, имеющие условия для содержания и (или) разведения в неволе диких животных
    FUNCTION OTHER_ORGANIZATION RETURN NUMBER;              --Иные (НАН(Идентификация ДЖ и растений), Мин. Природы, МЧС, Мин. Культуры)
    FUNCTION NOT_SUBJECT_TO_PROCESSES RETURN NUMBER;        --Организации (участники системы) функции которых не подпадают под процессы постановления
    FUNCTION BANK RETURN NUMBER;                            --Банки
    FUNCTION SUBDIVISION_DEPARTMENT RETURN NUMBER;          --Подразделение Департамента
    FUNCTION TRADING_OBJECT RETURN NUMBER;                  --Торговый объект
    FUNCTION WAREHOUSE RETURN NUMBER;                       --Складское помещение
    FUNCTION STORAGE_VEHICLES RETURN NUMBER;                --Площадка по хранению транспортных средств
    
END;
/

