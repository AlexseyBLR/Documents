create trigger GOODS_SECURITY_TRG
  instead of insert or update
  on GOODS_SECURITY
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW.ID_GOODS_SECURITY IS NULL THEN 
             :NEW.ID_GOODS_SECURITY:=GOODS_SECURITY_SEQ.NEXTVAL ; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    --  запоминаем ID_GOODS_GROUP "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_GOODS_SECURITY";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

      INSERT INTO GOODS_SECURITY_HISTORY (
        ID_GOODS_SECURITY,
        ID_PARENT,
        IS_ACTUAL,
        DATE_START,
        DATE_FINISH,
        NAME_GOODS_SECURITY,
        DATE_CHANGE,
        TYPE_OPERATION,
        ID_USER
      )
      VALUES (
        :NEW."ID_GOODS_SECURITY",
        :NEW."ID_PARENT",
        :NEW."IS_ACTUAL",
        :NEW."DATE_START",
        :NEW."DATE_FINISH",
        :NEW."NAME_GOODS_SECURITY",
        SYSDATE,
        TYPE_OPER,
        1   
      );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE GOODS_SECURITY SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(COUNTER);
    END AFTER STATEMENT;
END GOODS_SECURITY_TRG;
/

