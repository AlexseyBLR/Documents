create trigger ASSET_STATUSES_TRG
  before insert
  on ASSET_STATUSES
  for each row
  BEGIN
  if :NEW."ID_ASSET_STATUS" is null then 
    :NEW."ID_ASSET_STATUS":="ASSET_STATUSES_SEQ".nextval; 
  end if;
END;
/

