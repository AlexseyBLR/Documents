create trigger GOODS_GROUP_TRG
  instead of insert or update
  on GOODS_GROUP
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW.ID_GOODS_GROUP IS NULL THEN 
             :NEW.ID_GOODS_GROUP:=GOODS_GROUP_SEQ.NEXTVAL; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    --  запоминаем ID_GOODS_GROUP "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_GOODS_GROUP";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

      INSERT INTO GOODS_GROUP_HISTORY (
        ID_GOODS_GROUP,
        ID_PARENT,
        IS_ACTUAL,
        DATE_START,
        DATE_FINISH,
        CODE_GOODS_GROUP,
        NAME_GOODS_GROUP,
        IS_ANOTHERWORK,
        IS_EXPERT_EVALUATION,
        IS_PERISHABLE,
        IS_WORTH,
        IS_NORECEPTION,
        IS_SPECIFIC,
        IS_REALTY,
        IS_EQUIPMENT_MORE,
        IS_TRANSPORT,
        IS_WEAPONS,
        IS_CULTURAL,
        IS_EQUIPMENT,
        IS_ALCOHOL,
        IS_TOBACCO,
        IS_DEFECT_HIDDEN,
        IS_SPECIAL_STORAGE,
        IS_MARKDOWN_MORE,
        IS_MARKDOWN_REALIZ,
        IS_ESTIMATED_VALUE,
        DATE_CHANGE,
        TYPE_OPERATION,
        ID_USER
      )
      VALUES (
        :NEW."ID_GOODS_GROUP",
        :NEW."ID_PARENT",
        :NEW."IS_ACTUAL",
        :NEW."DATE_START",
        :NEW."DATE_FINISH",
        :NEW."CODE_GOODS_GROUP",
        :NEW."NAME_GOODS_GROUP",
        :NEW."IS_ANOTHERWORK",
        :NEW."IS_EXPERT_EVALUATION",
        :NEW."IS_PERISHABLE",
        :NEW."IS_WORTH",
        :NEW."IS_NORECEPTION",
        :NEW."IS_SPECIFIC",
        :NEW."IS_REALTY",
        :NEW."IS_EQUIPMENT_MORE",
        :NEW."IS_TRANSPORT",
        :NEW."IS_WEAPONS",
        :NEW."IS_CULTURAL",
        :NEW."IS_EQUIPMENT",
        :NEW."IS_ALCOHOL",
        :NEW."IS_TOBACCO",
        :NEW."IS_DEFECT_HIDDEN",
        :NEW."IS_SPECIAL_STORAGE",
        :NEW."IS_MARKDOWN_MORE",
        :NEW."IS_MARKDOWN_REALIZ",
        :NEW."IS_ESTIMATED_VALUE",
        SYSDATE,
        TYPE_OPER,
        1   
      );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE GOODS_GROUP SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(COUNTER);
    END AFTER STATEMENT;
END GOODS_GROUP_TRG;
/

