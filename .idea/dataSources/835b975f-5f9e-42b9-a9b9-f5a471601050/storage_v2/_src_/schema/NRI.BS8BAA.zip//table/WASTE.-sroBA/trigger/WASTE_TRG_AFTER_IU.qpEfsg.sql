create trigger WASTE_TRG_AFTER_IU
  after insert or update
  on WASTE
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;
  
  INSERT INTO WASTE_HISTORY (
    ID_WASTE,
    WASTE_NAME,
    ID_MEASURE,
    IS_ACTUAL,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER
  )
  VALUES (
    :NEW."ID_WASTE",
    :NEW."WASTE_NAME",
    :NEW."ID_MEASURE",
    :NEW."IS_ACTUAL",
    SYSDATE,
    TYPE_OPER,
    1   
  );
  
END;
/

