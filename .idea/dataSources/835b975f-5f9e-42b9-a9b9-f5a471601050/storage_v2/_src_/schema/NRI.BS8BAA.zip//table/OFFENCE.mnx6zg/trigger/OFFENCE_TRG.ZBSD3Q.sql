create trigger OFFENCE_TRG
  before insert
  on OFFENCE
  for each row
  BEGIN
  
    IF INSERTING AND :NEW.ID_OFFENCE IS NULL THEN
      :NEW.ID_OFFENCE:=OFFENCE_SEQ.NEXTVAL;
    END IF;
 
END;
/

