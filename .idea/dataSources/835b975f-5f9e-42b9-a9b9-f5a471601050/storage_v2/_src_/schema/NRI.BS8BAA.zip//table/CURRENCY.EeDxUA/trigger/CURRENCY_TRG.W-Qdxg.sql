create trigger CURRENCY_TRG
  before insert
  on CURRENCY
  for each row
  BEGIN
  if :NEW."ID_CURRENCY" is null then 
  :NEW."ID_CURRENCY":="CURRENCY_SEQ".nextval; 
  end if;
END;
/

