create trigger XML_TUNING_TRG
  before insert
  on XML_TUNING
  for each row
  BEGIN
    IF INSERTING AND :NEW.ID_TUNING IS NULL THEN
       :NEW.ID_TUNING:=XML_TUNING_SEQ.NEXTVAL;
    END IF;

END;
/

