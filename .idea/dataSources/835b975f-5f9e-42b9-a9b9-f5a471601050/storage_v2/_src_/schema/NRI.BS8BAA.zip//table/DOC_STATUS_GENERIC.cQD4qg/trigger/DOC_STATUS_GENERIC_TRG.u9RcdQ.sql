create trigger DOC_STATUS_GENERIC_TRG
  before insert
  on DOC_STATUS_GENERIC
  for each row
  BEGIN
  if :NEW."ID_DOC_STATUS_GENERIC" is null then 
  :NEW."ID_DOC_STATUS_GENERIC":="DOC_STATUS_GENERIC_SEQ".nextval; 
  end if;
END;
/

