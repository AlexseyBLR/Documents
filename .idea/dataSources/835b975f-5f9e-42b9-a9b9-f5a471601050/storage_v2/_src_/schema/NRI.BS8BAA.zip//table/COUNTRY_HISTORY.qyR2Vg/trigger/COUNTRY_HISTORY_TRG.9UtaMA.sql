create trigger COUNTRY_HISTORY_TRG
  before insert
  on COUNTRY_HISTORY
  for each row
  BEGIN
  if :NEW."ID_COUNTRY_HISTORY" is null then 
       :NEW."ID_COUNTRY_HISTORY":="COUNTRY_HISTORY_SEQ".nextval; 
  end if;
END;
/

