create trigger EMPLOYEES_TRG
  before insert
  on EMPLOYEES
  for each row
  BEGIN

       IF INSERTING AND :NEW.ID_EMPLOYEES IS NULL THEN
        :NEW.ID_EMPLOYEES :=EMPLOYEES_SEQ.NEXTVAL;
       END IF;
 
END;
/

