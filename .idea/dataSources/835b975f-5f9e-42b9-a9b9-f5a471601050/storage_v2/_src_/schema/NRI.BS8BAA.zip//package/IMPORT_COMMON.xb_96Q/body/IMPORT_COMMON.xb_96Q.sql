create PACKAGE BODY     IMPORT_COMMON
IS
    L_ERRMSG VARCHAR2(1024);
    COUNTER_IMPORTED_ROW NUMBER:=0;
    COUNTER_ERROR_ROW NUMBER:=0;
    
    --IMPORT_FILE_NAME VARCHAR2(100);

FUNCTION EXTRACT_FILE_EXT(IN_FILENAME IN VARCHAR2) RETURN VARCHAR2
IS
VR_RETURNVALUE VARCHAR2(255);
BEGIN
    BEGIN
        VR_RETURNVALUE := SUBSTR(IN_FILENAME, INSTR(IN_FILENAME,'.',-1));
    EXCEPTION
        WHEN OTHERS THEN RETURN NULL;
    END;
    RETURN VR_RETURNVALUE;
END EXTRACT_FILE_EXT;

/*FUNCTION EXTRACT_FILENAME(IN_FILENAME IN VARCHAR2) RETURN VARCHAR2
IS
VR_RETURNVALUE VARCHAR2(255);
BEGIN
    BEGIN
        VR_RETURNVALUE := SUBSTR(IN_FILENAME, INSTR(IN_FILENAME,GV_OSSEPARATOR,-1)+1);
        RETURN VR_RETURNVALUE;
    EXCEPTION
    WHEN OTHERS THEN 
        RETURN NULL; 
    END;
END EXTRACT_FILENAME;
     */

/*FUNCTION CHANGE_FILE_EXT(IN_FILENAME IN VARCHAR2, IN_EXT VARCHAR2) RETURN VARCHAR2
IS
VR_RETURNVALUE VARCHAR2(255);
BEGIN
    BEGIN
        VR_RETURNVALUE := REPLACE(IN_FILENAME, EXTRACT_FILE_EXT(IN_FILENAME ),IN_EXT );
    EXCEPTION
    WHEN OTHERS THEN 
        RETURN NULL;
    END;
    RETURN VR_RETURNVALUE;
END CHANGE_FILE_EXT;
*/
    
FUNCTION GET_OS_SEPARATOR RETURN VARCHAR2
IS
    VR_OSSTRING VARCHAR2(255) ;
    VR_RETURNVALUE VARCHAR2(1) ;
BEGIN
    BEGIN
        SELECT DBMS_UTILITY.PORT_STRING INTO VR_OSSTRING FROM DUAL;
        IF INSTR(UPPER(VR_OSSTRING), 'WIN') <> 0 THEN
        VR_RETURNVALUE := '\';
        ELSE VR_RETURNVALUE := '/';
        END IF;
    EXCEPTION
    WHEN OTHERS THEN 
        VR_RETURNVALUE := '';
    END;
    RETURN VR_RETURNVALUE;
END GET_OS_SEPARATOR;
 
    
FUNCTION CHECK_DATE(IN_DATE IN VARCHAR2, ERR OUT VARCHAR2) RETURN NUMBER
--1  -IN_DATE ЭТО ДАТА, 0 - IN_DATE ДАТОЙ НЕ ЯВЛЯЕТСЯ    
IS
    RES NUMBER := 1;
    D DATE;
BEGIN
    D:= TO_DATE(IN_DATE, FORMAT_DATE);
    RETURN RES;
    
    EXCEPTION
    WHEN OTHERS THEN
    BEGIN
        ERR:= IN_DATE ||' НЕ ЯВЛЯЕТСЯ ДАТОЙ'; 
        RETURN 0; 
    END;        
    
END;

FUNCTION DEL_RIGHT_SYM1013(IN_STR IN VARCHAR2) RETURN VARCHAR2
-- УДАЛЯЕТ В КОНЦЕ СТРОКИ СИМВОЛЫ ВОЗВРАТА КАРЕТКИ И ПЕРЕХОДА НА НОВУЮ СТРОКУ
IS
I NUMBER;
C VARCHAR2 (1);
STR VARCHAR2(1000);
CH CHAR;
BEGIN
                
    STR:= IN_STR;
    I:= LENGTH(STR);
    CH:= SUBSTR(STR, I,1);

    IF  CH = CHR(10) THEN  
        I:= I-1; 
    END IF;
    CH:= SUBSTR(STR, I,1);
    IF  CH = CHR(13) THEN  
        I:= I-1; 
    END IF;
    STR:= SUBSTR(STR, 1, I);
    I:= LENGTH(STR);
    RETURN STR;
END; 

FUNCTION REPLACE_QUOT(IN_STR IN VARCHAR2) RETURN VARCHAR2
IS
BEGIN
    RETURN REPLACE (REPLACE(IN_STR, ' ;', ' '), ';', '') ;
END;

FUNCTION CHECK_NUMBER(IN_NUM IN OUT VARCHAR2, L_INT IN NUMBER, L_FRAC IN NUMBER, ERR OUT VARCHAR2) RETURN NUMBER
 --1  -IN_NUM ЭТО ЧИСЛО С УКАЗАННЫМ РАЗМЕРМ ЦЕЛОЙ И ДРОБНОЙ ЧАСТИ , 0 - IN_NUM ЧИСЛОМ НЕ ЯВЛЯЕТСЯ, ЛИБО ПРЕВЫШАЕТ УКАЗАННЫЙ РАЗМЕР
IS
    CURR_FORMAT VARCHAR2(41);
    N NUMBER;
    RES NUMBER := 1;
    DELIMETER       VARCHAR2(1);
    I NUMBER;
BEGIN
  
    SELECT DECODE( INSTR(RTRIM(LTRIM(VALUE)), '.'), 0, ',', '.') INTO DELIMETER
        FROM V$NLS_PARAMETERS
        WHERE PARAMETER = 'NLS_NUMERIC_CHARACTERS';
    
    IN_NUM:= REPLACE(IN_NUM, '.', DELIMETER);
    IN_NUM:= REPLACE(IN_NUM, ',', DELIMETER);  
    IN_NUM:= REPLACE(IN_NUM, ' ','');  

    BEGIN
        N:= TO_NUMBER(IN_NUM);
        
        EXCEPTION
        WHEN OTHERS THEN 
        BEGIN
            ERR:= IN_NUM || ' НЕ ЯВЛЯЕТСЯ ЧИСЛОМ';
            --ERR:= ERR || ' L = ' || LENGTH(IN_NUM);
            RETURN 0;
            
        END;
    END;
--    
    BEGIN
        IF L_INT != -1 THEN
            CURR_FORMAT:= SUBSTR(FORMAT_NUMBER, 1, L_INT);
            IF L_FRAC > 0 
            THEN
                CURR_FORMAT:= CURR_FORMAT || 'D' || SUBSTR(FORMAT_NUMBER, 1, L_FRAC);
            END IF;                  
            N:= TO_NUMBER(LTRIM(IN_NUM, '0'), CURR_FORMAT);
        END IF;
        RETURN RES;    
    
    EXCEPTION
    WHEN OTHERS THEN 
    BEGIN
        ERR:= IN_NUM || ' НЕ СООТВЕТСТВУЕТ НЕОБХОДИМОМУ РАЗМЕРУ';
        RETURN 0;
        
    END;
    END;
END;    

FUNCTION CHECK_STR(IN_STR IN VARCHAR2, L_STR IN NUMBER, ERR OUT VARCHAR2) RETURN NUMBER
--1  -IN_STR ЭТО СТРОКА УКАЗАННОЙ ДЛИННЫ, 0 - IN_STR СЛИШКОМ ДЛИННАЯ СТРОКА
IS
    RES NUMBER:= 1;
BEGIN
    IF NOT(IN_STR IS NULL) 
    THEN
        IF (L_STR > 0) AND (LENGTH(IN_STR) > L_STR) THEN 
            RES:= 0;
            ERR:= 'ДЛИНА СТРОКИ "' || IN_STR || '" ПРЕВЫШАЕТ МАКСИМАЛЬНО ДОПУСТИМЫЙ ' || TO_CHAR(L_STR)|| ' СИМВОЛОВ';                
        END IF;
    END IF;        
    RETURN RES; 
END;

FUNCTION CHECK_F(IN_STR IN OUT VARCHAR2, L_STR IN NUMBER, IN_TYPE_CHECK IN NUMBER, IN_TABLE_PK_NAME IN VARCHAR2, IN_FIELD_PK_NAME IN VARCHAR2, IN_NAME_CHECKED_FIELD IN VARCHAR2, IN_ERR OUT VARCHAR2) RETURN NUMBER
-- IN_STR ОБРЕЗАЕТСЯ ДО УКАЗАННОЙ ДЛИНЫ И ПРОВЕРЯЕТСЯ НА КОРРЕКТНОСТЬ ВТОРИЧНОГО КЛЮЧА  --1  -IN_STR КЛЮЧ ЕСТЬ, 0 - IN_STR КЛЮЧА НЕТ
-- IN_TYPE_CHECK - ТИП ДОПОЛНИТЕЛЬНОЙ ПРОВЕРКИ
--  - 0 - НИЧЕГО НЕ ПРОВЕРЯЕМ
--  - 1 - В IN_TABLE_PK_NAME ПОЛЕ DATE_FINISH ДОЛЖНО БЫТЬ IS NULL
--  - 2 - В IN_TABLE_PK_NAME ПОЛЕ IS_ACTUAL ДОЛЖНО БЫТЬ =  1
-- ВОЗВРАЩАЕ 1 ЕСЛИ ВСЕ ХОРОШО
-- ВОЗВРАЩАЕТ 0 ЕСЛИ БЫЛА ОШИБКА  
IS
    RES NUMBER:= 1;
    CUR SYS_REFCURSOR;
    COUNT_PK NUMBER;
    VALUE_PK VARCHAR2(255);
    STR VARCHAR2(1000);
    
BEGIN
    IN_ERR:= IN_STR;  
    IN_STR:= SUBSTR(IN_STR, 1, L_STR);
    -- ПРОВЕРКА ВТОРИЧНЫХ КЛЮЧЕЙ--
    IF IN_TYPE_CHECK = 1 THEN
        STR:=  'SELECT COUNT('|| IN_FIELD_PK_NAME || ') FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || ''' AND DATE_FINISH IS NULL';
    ELSIF IN_TYPE_CHECK = 2 THEN
        STR:=  'SELECT COUNT('|| IN_FIELD_PK_NAME || ') FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || ''' AND IS_ACTUAL = 1';
    ELSE     
        STR:=  'SELECT COUNT('|| IN_FIELD_PK_NAME || ') FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || '''';
    END IF;  
    OPEN CUR FOR STR; 
    FETCH CUR INTO COUNT_PK;
    CLOSE CUR;
    IF COUNT_PK = 0 THEN
        IN_ERR:= IN_ERR || ' - ИСХОДНЫЙ КЛЮЧ НЕ НАЙДЕН';
        RES:=0;
    ELSE
        IF IN_TYPE_CHECK = 1 THEN
            STR:=  'SELECT '|| IN_FIELD_PK_NAME || ' FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || ''' AND DATE_FINISH IS NULL';
        ELSIF IN_TYPE_CHECK = 2 THEN
            STR:=  'SELECT '|| IN_FIELD_PK_NAME || ' FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || ''' AND IS_ACTUAL = 1';
        ELSE     
            STR:=  'SELECT '|| IN_FIELD_PK_NAME || ' FROM ' || IN_TABLE_PK_NAME || ' WHERE ' || IN_NAME_CHECKED_FIELD || ' = ''' || IN_STR || '''';
        END IF;  
        OPEN CUR FOR STR; 
        FETCH CUR INTO VALUE_PK;
        IF CUR%NOTFOUND THEN
            IN_ERR:= IN_ERR || ' - ИСХОДНЫЙ КЛЮЧ НЕ НАЙДЕН';
            RES:=0;
        ELSE
            STR:= TO_CHAR(VALUE_PK); -- ВОЗВРАЩАЕМ ЗНАЧЕНИЕ НАЙДЕННОГО PK 
            IN_ERR:= NULL;
            RES:=1;
        END IF;
        CLOSE CUR;
    END IF;
    RETURN RES;
    
    EXCEPTION
    WHEN OTHERS THEN 
    BEGIN
        L_ERRMSG:=SQLERRM;
        DBMS_OUTPUT.PUT_LINE(L_ERRMSG);
        DBMS_OUTPUT.PUT_LINE('ERROR');
        IN_ERR:= ' ERROR :' || L_ERRMSG || CHR(10);
        
        RETURN 0;
        
    END;
    
END;
FUNCTION PARSE_STR(IN_STR IN OUT VARCHAR2) RETURN ARR_V
IS
  RES ARR_V;
  
BEGIN
    
    WITH T AS
    (
        SELECT IN_STR STR
            FROM   DUAL ) ,
    MODEL_PARAM AS
    (
        SELECT STR                                           ORIG_STR ,
            DELIMETER
            || STR
            || DELIMETER                                        MOD_STR,
            1                                             START_POS,
            LENGTH(STR)                                   END_POS,
            (LENGTH(STR) - LENGTH(REPLACE(STR, DELIMETER))) + 1 ELEMENT_COUNT,
            0                                             ELEMENT_NO,
            ROWNUM                                        RN
        FROM   T )
    SELECT TRIM(SUBSTR(MOD_STR, START_POS, END_POS-START_POS)) STR BULK COLLECT INTO RES
    FROM     (
        SELECT *
            FROM   MODEL_PARAM MODEL PARTITION BY (RN, ORIG_STR, MOD_STR)
        DIMENSION BY (ELEMENT_NO)
        MEASURES (START_POS, END_POS, ELEMENT_COUNT)
        RULES ITERATE (2000)
        UNTIL (ITERATION_NUMBER+1 = ELEMENT_COUNT[0])
        (START_POS[ITERATION_NUMBER+1] = INSTR(CV(MOD_STR), DELIMETER, 1, 
                                      CV(ELEMENT_NO)) + 1,
        END_POS[ITERATION_NUMBER+1] = INSTR(CV(MOD_STR), DELIMETER, 1, 
                                    CV(ELEMENT_NO) + 1) ) )
    WHERE    ELEMENT_NO != 0
    ORDER BY MOD_STR, ELEMENT_NO;    
    RETURN RES; 
END PARSE_STR;

FUNCTION XBLOB_TO_CLOB(L_BLOB BLOB) RETURN CLOB IS
L_CLOB CLOB;
L_SRC_OFFSET NUMBER;
L_DEST_OFFSET NUMBER;
L_BLOB_CSID NUMBER := DBMS_LOB.DEFAULT_CSID;
V_LANG_CONTEXT NUMBER := DBMS_LOB.DEFAULT_LANG_CTX;
L_WARNING NUMBER;
L_AMOUNT NUMBER;
BEGIN
    IF DBMS_LOB.GETLENGTH(L_BLOB) > 0 THEN
        DBMS_LOB.CREATETEMPORARY(L_CLOB, TRUE);
        
        L_SRC_OFFSET := 1;
        L_DEST_OFFSET := 1;
        L_AMOUNT := DBMS_LOB.GETLENGTH(L_BLOB);
        DBMS_LOB.CONVERTTOCLOB(L_CLOB,
        L_BLOB,
        L_AMOUNT,
        L_SRC_OFFSET,
        L_DEST_OFFSET,
        NLS_CHARSET_ID('CL8MSWIN1251'),
        V_LANG_CONTEXT,
        L_WARNING);
        RETURN L_CLOB;
    ELSE
        L_CLOB:= TO_CLOB('');
        RETURN L_CLOB;
    END IF;
    DBMS_LOB.FREETEMPORARY(L_CLOB);
END;
---------

BEGIN
    GV_OSSEPARATOR := GET_OS_SEPARATOR;
    
END IMPORT_COMMON;
/

