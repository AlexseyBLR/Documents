create trigger LIST_DETAIL_TRG
  instead of insert or update
  on LIST_DETAIL
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_UDPATE   ID_UDPATE_T;
    CNT                  PLS_INTEGER := 0;
    TYPE_OPER NUMBER;
           
    /*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.put_line ('In before statement');
    END
    BEFORE STATEMENT;*/

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW.ID_LIST_DETAIL IS NULL THEN 
             :NEW.ID_LIST_DETAIL:=LIST_DETAIL_SEQ.NEXTVAL; 
            END IF;
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
            IF :NEW."IS_ACTUAL" = 0 THEN  
                TYPE_OPER:= 2;
                IF :OLD."IS_ACTUAL" = 1 THEN
                    -- запоминаем ID_LIST_DETAIL "удаленных" элементов
                    CNT:= CNT + 1;
                    ID_UDPATE(CNT):= :NEW."ID_LIST_DETAIL";
                END IF; 
            ELSE  
                TYPE_OPER:= 1; 
            END IF;
        ELSE NULL;            
        END CASE;

        INSERT INTO LIST_DETAIL_HISTORY (
            ID_LIST_DETAIL,
            IS_ACTUAL,
            ID_PARENT,
            ID_LIST,
            NAME_LIST_DETAIL,
            NAME_SHORT_LIST_DETAIL,
            DATE_CHANGE,
            TYPE_OPERATION,
            ID_USER,
            ORDER_NUM
        )
        VALUES (
            :NEW."ID_LIST_DETAIL",
            :NEW."IS_ACTUAL",
            :NEW."ID_PARENT",
            :NEW."ID_LIST",
            :NEW."NAME_LIST_DETAIL",
            :NEW."NAME_SHORT_LIST_DETAIL",
            SYSDATE,
            TYPE_OPER,
            1,
            :NEW."ORDER_NUM"   
        );
    END AFTER EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        FORALL COUNTER IN 1..ID_UDPATE.COUNT()
            UPDATE LIST_DETAIL SET IS_ACTUAL = 0 WHERE ID_PARENT = ID_UDPATE(COUNTER);
    END AFTER STATEMENT;
END LIST_DETAIL_TRG;
/

