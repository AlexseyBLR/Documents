create trigger DOC_STATUS_TRG
  before insert
  on DOC_STATUS
  for each row
  BEGIN
  if :NEW."ID_DOC_STATUS" is null then 
  :NEW."ID_DOC_STATUS":="DOC_STATUS_SEQ".nextval; 
  end if;
END;
/

