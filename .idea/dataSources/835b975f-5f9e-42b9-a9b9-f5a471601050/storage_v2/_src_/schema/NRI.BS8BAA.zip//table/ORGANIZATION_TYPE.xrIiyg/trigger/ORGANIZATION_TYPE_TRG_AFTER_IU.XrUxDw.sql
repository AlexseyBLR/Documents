create trigger ORGANIZATION_TYPE_TRG_AFTER_IU
  instead of insert or update
  on ORGANIZATION_TYPE
  for each row
COMPOUND TRIGGER

    TYPE ID_UDPATE_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    ID_ORG_UDPATE       ID_UDPATE_T;
    ID_TYPE_UDPATE      ID_UDPATE_T;
    CNT                 PLS_INTEGER := 0;

    TYPE_OPER NUMBER;

    BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
            IF :NEW."ID_ORGANIZATION_TYPE" IS NULL THEN 
                :NEW."ID_ORGANIZATION_TYPE":="ORGANIZATION_TYPE_SEQ".NEXTVAL ; 
            END IF;            
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;

    AFTER EACH ROW
    IS
    BEGIN
      CASE
        WHEN INSERTING THEN TYPE_OPER:= 0; 
        WHEN UPDATING THEN 
          IF :NEW."IS_ACTUAL" = 0 THEN  
            TYPE_OPER:= 2; 
            IF :OLD."IS_ACTUAL" = 1 THEN
                --  запоминаем ID_ORGANIZATION И ID_TYPE "удаленных" элементов
                CNT:= CNT + 1;
                ID_ORG_UDPATE(CNT):= :NEW."ID_ORGANIZATION";
                ID_TYPE_UDPATE(CNT):= :NEW."ID_TYPE";
            END IF; 
          ELSE  
            TYPE_OPER:= 1; 
          END IF;
      END CASE;

        INSERT INTO ORGANIZATION_TYPE_HISTORY (
           ID_ORGANIZATION_TYPE, 
           ID_ORGANIZATION, 
           ID_TYPE,
           DATE_CHANGE, 
           TYPE_OPERATION,   
           ID_USER) 
        VALUES (
          :NEW."ID_ORGANIZATION_TYPE", 
          :NEW."ID_ORGANIZATION", 
          :NEW."ID_TYPE", 
           sysdate,
           TYPE_OPER,
           1);
    END AFTER EACH ROW;  
    
    AFTER STATEMENT IS
    BEGIN
        
        FOR INDX IN 1..ID_ORG_UDPATE.COUNT() LOOP
            -- для любого типа чистим привязку в ORG_GOODS_GROUP
            UPDATE ORG_GOODS_GROUP SET IS_ACTUAL = 0 WHERE ID_ORGANIZATION_TYPE =  ID_TYPE_UDPATE(INDX);
            
            IF ID_TYPE_UDPATE(INDX) = PKG_ID_ORG_TYPE.AUCTION THEN
                -- чистим информацию по Организатору аукционов   
                UPDATE ORG_AUCTION SET IS_ACTUAL = 0 WHERE ID_ORGANIZATION = ID_ORG_UDPATE(INDX);
            END IF;
            
            IF ID_TYPE_UDPATE(INDX) = PKG_ID_ORG_TYPE.KEEPER THEN
                ---- чистим информацию по Хранителю
                UPDATE ORG_KEEPER SET IS_ACTUAL = 0 WHERE ID_ORGANIZATION = ID_ORG_UDPATE(INDX);
                -- удаляем структурные подразделения хранителя
                UPDATE ORGANIZATION SET IS_ACTUAL = 0 WHERE ID_ORGANIZATION IN
                    (
                        SELECT O.ID_ORGANIZATION 
                        FROM ORGANIZATION O,ORGANIZATION_TYPE OT
                        WHERE O.ID_ORGANIZATION = OT.ID_ORGANIZATION
                            AND OT.ID_TYPE IN (SELECT ID_LIST_DETAIL 
                                                FROM LIST_DETAIL 
                                                CONNECT BY PRIOR ID_LIST_DETAIL = ID_PARENT 
                                                START WITH ID_PARENT = NRI.PKG_ID_ORG_TYPE.KEEPER)
                            AND O.ID_ORGANIZATION IN (SELECT O.ID_ORGANIZATION 
                                                        FROM ORGANIZATION O 
                                                        CONNECT BY PRIOR  ID_ORGANIZATION =ID_PARENT 
                                                        START WITH ID_PARENT = ID_ORG_UDPATE(INDX))
                    );
            END IF;
        END LOOP;    

    END AFTER STATEMENT;
END;
/

