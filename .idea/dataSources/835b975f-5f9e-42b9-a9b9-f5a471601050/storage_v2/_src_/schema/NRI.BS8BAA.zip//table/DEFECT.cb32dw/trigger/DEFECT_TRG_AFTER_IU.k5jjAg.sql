create trigger DEFECT_TRG_AFTER_IU
  after insert or update
  on DEFECT
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;
  
  INSERT INTO DEFECT_HISTORY (
    ID_DEFECT,
    IS_ACTUAL,
    DATE_START,
    DATE_FINISH,
    NAME_DEFECT,
    PERCENT,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER  
  )
  VALUES (
    :NEW."ID_DEFECT",
    :NEW."IS_ACTUAL",
    :NEW."DATE_START",
    :NEW."DATE_FINISH",
    :NEW."NAME_DEFECT",
    :NEW."PERCENT",
    SYSDATE,
    TYPE_OPER,
    1   
  );
  
END;
/

