create trigger ORG_KEEPER_TRG
  before insert
  on ORG_KEEPER
  for each row
  BEGIN
  
    IF INSERTING AND :NEW.ID_ORG_KEEPER IS NULL THEN
       :NEW.ID_ORG_KEEPER:=ORG_KEEPER_SEQ.NEXTVAL;
    END IF;
 
END;
/

