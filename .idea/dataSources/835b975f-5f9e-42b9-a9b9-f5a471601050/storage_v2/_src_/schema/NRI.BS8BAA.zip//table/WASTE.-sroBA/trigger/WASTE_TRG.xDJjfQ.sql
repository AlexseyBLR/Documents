create trigger WASTE_TRG
  before insert
  on WASTE
  for each row
  BEGIN
    IF INSERTING AND :NEW.ID_WASTE IS NULL THEN
      :NEW.ID_WASTE:=WASTE_SEQ.NEXTVAL;
    END IF;

END;
/

