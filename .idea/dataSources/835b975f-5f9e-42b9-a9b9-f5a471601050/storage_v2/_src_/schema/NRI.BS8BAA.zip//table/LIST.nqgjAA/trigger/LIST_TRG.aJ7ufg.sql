create trigger LIST_TRG
  before insert
  on LIST
  for each row
  begin   
  if :NEW."ID_LIST" is null then 
     :NEW."ID_LIST":="LIST_SEQ".nextval ; 
  end if; 
end;
/

