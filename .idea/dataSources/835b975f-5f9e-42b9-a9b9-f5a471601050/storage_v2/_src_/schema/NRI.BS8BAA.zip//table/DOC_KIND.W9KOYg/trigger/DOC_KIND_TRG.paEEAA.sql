create trigger DOC_KIND_TRG
  before insert
  on DOC_KIND
  for each row
  BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    IF INSERTING AND :NEW.ID_doc_kind IS NULL THEN
      :NEW.ID_doc_kind := doc_kind_SEQ.NEXTVAL;
    END IF;
  END COLUMN_SEQUENCES;
END;
/

