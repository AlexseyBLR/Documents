create trigger OFFENCE_TRG_AFTER_IU
  after insert or update
  on OFFENCE
  for each row
  DECLARE 
  TYPE_OPER NUMBER;
BEGIN
  CASE
    WHEN INSERTING THEN TYPE_OPER:= 0; 
    WHEN UPDATING THEN 
      IF :NEW."IS_ACTUAL" = 0 then  
        TYPE_OPER:= 2; 
      ELSE  
        TYPE_OPER:= 1; 
      END IF;
  END CASE;
  
  INSERT INTO OFFENCE_HISTORY (
    ID_OFFENCE,
    IS_ACTUAL,
    DATE_START,
    DATE_FINISH,
    ID_OFFENCE_TYPE,
    ARTICLE,
    ITEM,
    SUBITEM,
    PART,
    PARAGRAPH,
    OFFENCE_NAME,
    DATE_CHANGE,
    TYPE_OPERATION,
    ID_USER
  )
  VALUES (
    :NEW."ID_OFFENCE",
    :NEW."IS_ACTUAL",
    :NEW."DATE_START",
    :NEW."DATE_FINISH",
    :NEW."ID_OFFENCE_TYPE",
    :NEW."ARTICLE",
    :NEW."ITEM",
    :NEW."SUBITEM",
    :NEW."PART",
    :NEW."PARAGRAPH",
    :NEW."OFFENCE_NAME",
    SYSDATE,
    TYPE_OPER,
    1   
  );
  
END;
/

