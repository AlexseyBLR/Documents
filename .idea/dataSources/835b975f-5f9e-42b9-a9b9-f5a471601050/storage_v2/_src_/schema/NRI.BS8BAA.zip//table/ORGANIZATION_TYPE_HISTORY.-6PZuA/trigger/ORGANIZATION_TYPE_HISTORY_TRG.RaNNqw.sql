create trigger ORGANIZATION_TYPE_HISTORY_TRG
  before insert
  on ORGANIZATION_TYPE_HISTORY
  for each row
  begin   
  if :NEW."ID_ORGANIZATION_TYPE_HIST" is null then 
      :NEW."ID_ORGANIZATION_TYPE_HIST":="ORGANIZATION_TYPE_HISTORY_SEQ".nextval ; 
  end if;
end;
/

