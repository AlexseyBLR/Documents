create PACKAGE BODY     IMPORT_PRODUCT_OIL
IS
    L_LITR NUMBER:=780;  --- List_Detail (list_id=38)
    L_ID_ORG NUMBER:=999;  --- Идентификатор Белнефтехим
    L_PRICE_LIST_NUM NUMBER:=3;  --- Номер прайс-листа
    L_ERRMSG VARCHAR2(1024);
    DIR_BNKHIM VARCHAR2(64):='LOAD_DATA_BNKHIM';  --Наименование директории для загрузки информации о стоимости нефтепродуктов
    DIR_OUT VARCHAR2(64):='OUT_DATA';  --Наименование директории для уже загруженных файлов и для журнада    
    FIELD_COUNT_BNKHIM NUMBER:=5;
    COUNTER_IMPORTED_ROW NUMBER:=0;
    COUNTER_ERROR_ROW NUMBER:=0;
    PREPARED_DATA IMPORT_COMMON.ARR_V;
    FORMAT_DATE VARCHAR2(10):= 'DD-MM-YYYY';
    
  B_DESCRIBE ARR_DESCRIBE := 
        ARR_DESCRIBE(
            DESCRIBE_STRUCT('ORG_PRICE_LIST_ITEM.NAME',             '1.Наименование услуги',                 'V', 200, 0,1, '', '', ''),
            DESCRIBE_STRUCT('ORG_PRICE_LIST_ITEM.COST_WITHOUT_VAT', '2.Стоимость тоны ',                     'V', -1, 0,1, '', '', ''),
            DESCRIBE_STRUCT('ORG_PRICE_LIST_ITEM.COST_WITHOUT_VAT', '3.Стоимость литра без НДС',             'N', -1, 0,1, '', '', ''),
            DESCRIBE_STRUCT('ORG_PRICE_LIST_ITEM.COST_VAT',         '4.Сумма  НДС',                          'N', -1, 0,1, '', '', ''),
            DESCRIBE_STRUCT('ORG_PRICE_LIST_ITEM.COST_WITH_VAT',    '5.Стоимость литра с НДС',               'N', -1, 0,1, '', '', '')
            
        );
        
     
          
    --IMPORT_FILE_NAME VARCHAR2(100);

FUNCTION ALL_FILES  RETURN NUMBER 
IS
------------------------------------------------
----              ВСЕ ФАЙЛЫ ИЗ ДИРЕКТОРИИ ---------------------  
---------------------------------------------- 
     DIR VARCHAR2(255);
     KOL NUMBER ;
   
        
BEGIN
     DELETE FROM DIR_LIST;
      
           GET_DIR_LIST(DIR_BNKHIM);     
   
   FOR C_DIR IN (SELECT FILENAME FROM DIR_LIST)
   LOOP
        KOL:=OIL_PRODUCT_IMPORT(C_DIR.FILENAME);
     
   END LOOP;
         RETURN 0;
END;
FUNCTION OIL_PRODUCT_IMPORT( FILE_NAME VARCHAR2)  RETURN NUMBER 
IS
------------------------------------------------
----             Прейскурант № 3					
--«Розничные цены на нефтепродукты, реализуемые через АЗС»					
---------------------  
---------------------------------------------- 
 DIR VARCHAR2(255);
    
      FHANDLE  UTL_FILE.FILE_TYPE;
      FHANDLE_LOG  UTL_FILE.FILE_TYPE;
      CURR_STR                          VARCHAR2(32000);
      CURR_STR_NEXT                    VARCHAR2(32000);
    
      NO_IMPORT                         NUMBER:= 1; -- 1 -    импортируем, 0 - били ошибки, импорт не производим
      IMPORTED_ROW NUMBER;
      KOL NUMBER;
      KOL_NULL_STR NUMBER:=0;
      NUM_STR NUMBER:=1;
      L_ID_LIST NUMBER;
    sss varchar2(512);
BEGIN

         ---
           SELECT COUNT(*) INTO KOL FROM ORG_PRICE_LIST 
           WHERE ID_ORGANIZATION=L_ID_ORG
             AND PRICE_LIST_NUM=L_PRICE_LIST_NUM
             AND  TO_CHAR(PRICE_LIST_DATE,'DDMMYYYY')=SUBSTR(FILE_NAME,1,8);
           if kol=1 then  
              return -1;
           end if;
         --- Убрать актуальность  
           
              UPDATE  ORG_PRICE_LIST 
                 SET IS_ACTUAL=0 
               WHERE ID_ORGANIZATION=L_ID_ORG 
                 AND PRICE_LIST_NUM=L_PRICE_LIST_NUM
                 AND IS_ACTUAL=1;      
            
           -----        
           INSERT INTO ORG_PRICE_LIST (
                      IS_ACTUAL, ID_ORGANIZATION, 
                      PRICE_LIST_NUM, PRICE_LIST_DATE) 
              VALUES ( 
                      1,/* IS_ACTUAL */
                      L_ID_ORG/* ID_ORGANIZATION */,
                      L_PRICE_LIST_NUM/* PRICE_LIST_NUM */,
                      TO_DATE(SUBSTR(FILE_NAME,1,8),'DDMMYYYY') /* PRICE_LIST_DATE */ )
            returning ID_ORG_PRICE_LIST 
               INTO L_ID_LIST;
           
                   
           ----- 
  
            FHANDLE := UTL_FILE.FOPEN(DIR_BNKHIM, FILE_NAME, 'r');
            FHANDLE_LOG := UTL_FILE.FOPEN(DIR_OUT, FILE_NAME||IMPORT_COMMON.LOG_EXT, 'w');
                   
            COUNTER_IMPORTED_ROW:=0;
            COUNTER_ERROR_ROW:= 0;
            IMPORTED_ROW:= 0;
            -- ПРОЦЕСС ИМПОРТА ФАЙЛА
            
            IMPORTED_ROW:= IMPORTED_ROW +21;
            
            for i in 1..20 loop
            
                UTL_FILE.GET_LINE(FHANDLE,CURR_STR);
               
            end loop;   
             
           
              
     LOOP
            BEGIN
                
                    UTL_FILE.GET_LINE(FHANDLE,CURR_STR);
                    CURR_STR:= CONVERT(CURR_STR,'AL32UTF8','CL8MSWIN1251');
                    if KOL_NULL_STR>2 THEN 
                     exit;
                    end if;
                    
                    
                if length(CURR_STR) >FIELD_COUNT_BNKHIM+1    then    -- пропустить пустую строку 
                        
                     KOL_NULL_STR:=0;
                    WHILE  length(CURR_STR)- length(replace(CURR_STR,';',''))+1< FIELD_COUNT_BNKHIM  
                    LOOP
                 
                     
                      UTL_FILE.GET_LINE(FHANDLE,CURR_STR_NEXT);
                      CURR_STR:= replace(CURR_STR,chr(10),'')|| CONVERT(CURR_STR_NEXT,'AL32UTF8','CL8MSWIN1251');
                                  
                     
                    END LOOP;
                    
                    
                   
                   -- если последний символ это разделитель, то удаляем его
                    PREPARED_DATA:= IMPORT_COMMON.PARSE_STR(CURR_STR);
                  
                    KOL:=  OIL_PRODUCT_ONE_ROW( IMPORTED_ROW,FHANDLE_LOG,NUM_STR, L_ID_LIST);
                    NUM_STR:=NUM_STR+1; 
                    
                 ELSE
                    KOL_NULL_STR:=KOL_NULL_STR+1;
                 END IF;
                                   
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN EXIT; -- если больше не читается, то выходим из цикла
                   WHEN OTHERS THEN
                       l_errmsg:=SQLERRM;
                     COUNTER_ERROR_ROW:= COUNTER_ERROR_ROW + 1;
                   END;
            
     END LOOP;
            UTL_FILE.FCLOSE(FHANDLE);
            COMMIT;
            UTL_FILE.FCOPY(DIR_BNKHIM, FILE_NAME, DIR_OUT, FILE_NAME);
            UTL_FILE.FREMOVE(DIR_BNKHIM, FILE_NAME);
            
            UTL_FILE.PUT_LINE(FHANDLE_LOG, TO_CHAR(SYSDATE, 'DD.MM.YYYY HH24:MI:SS'));
            UTL_FILE.PUT_LINE(FHANDLE_LOG, TO_CHAR(COUNTER_IMPORTED_ROW) || ' строк были успешно импортированы');
            UTL_FILE.PUT_LINE(FHANDLE_LOG, TO_CHAR(COUNTER_ERROR_ROW) || ' (ошибочных) строк не импортированы');
            UTL_FILE.FCLOSE(FHANDLE_LOG);
            COMMIT;
     
  return 0;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
      l_errmsg:=SQLERRM;
     return -1 ;
     WHEN OTHERS THEN
      l_errmsg:=SQLERRM;
      return -1;
       -- Consider logging the error and then re-raise
      
END OIL_PRODUCT_IMPORT;

FUNCTION LOAD_FILE_BLOB(P_FILE_NAME VARCHAR2)  RETURN NUMBER IS
F_LOB BFILE; 
B_LOB BLOB;
ID_FILE NUMBER; 
BEGIN 
--INSERT INTO SAM_EMP(EMPNO,ENAME,RESUME) 
--VALUES ( 9001, 'SAMIR',EMPTY_BLOB() ) 
--RETURN DOCUMENTS INTO B_LOB; 
-- SELECT IMPORT_FILES_RO_SEQ.NEXTVAL INTO ID_FILE FROM DUAL;
INSERT INTO IMPORT_FILES (
                     
                      FILE_NAME,
                      FILE_DATE,
                      FILE_CONTENT )
                      VALUES(
                              P_FILE_NAME,SYSDATE,
                             EMPTY_BLOB() 
                             )
                              RETURNING FILE_CONTENT INTO B_LOB ;

F_LOB := BFILENAME( DIR_BNKHIM, P_FILE_NAME); 
DBMS_LOB.FILEOPEN(F_LOB, DBMS_LOB.FILE_READONLY); 
DBMS_LOB.LOADFROMFILE    
( B_LOB, F_LOB, DBMS_LOB.GETLENGTH(F_LOB) ); 
DBMS_LOB.FILECLOSE(F_LOB); 
COMMIT;
RETURN ID_FILE; 

END; 
-----------
FUNCTION OIL_PRODUCT_ONE_ROW( IMPORTED_ROW NUMBER,FHANDLE_LOG  UTL_FILE.FILE_TYPE,IN_MUM_ITEM NUMBER,IN_ID_LIST NUMBER) RETURN NUMBER  is 
  --  FHANDLE_LOG  UTL_FILE.FILE_TYPE;
    ERROR_STR                         VARCHAR2(1000);
    RES_CHECK_TYPE                    NUMBER;
    NO_IMPORT                         NUMBER:= 1; 
 
    
   -- sss varchar2(512):=''; 
    BEGIN    
                    -- проверка на обязательные для заполнения поля
                ERROR_STR := '';
                NO_IMPORT := 1;
                FOR I IN 1..FIELD_COUNT_BNKHIM
                    LOOP
                        IF (B_DESCRIBE(I).F_MANDATORY = '1') AND (PREPARED_DATA(I) IS NULL)
                        THEN
                            UTL_FILE.PUT_LINE(FHANDLE_LOG, CONVERT('Строка' ||TO_CHAR(IMPORTED_ROW) || ' - Поле' ||B_DESCRIBE(I).F_NAME_RU || ' является обязательным, но не заполнено.','CL8MSWIN1251','AL32UTF8'));
                                                       NO_IMPORT:=0;  
                        END IF; 
                        ERROR_STR:= NULL;
                        
                        IF B_DESCRIBE(I).F_TYPE = 'N'
                        THEN
                            RES_CHECK_TYPE:= IMPORT_COMMON.CHECK_NUMBER(PREPARED_DATA(I), B_DESCRIBE(I).F_SIZE,  B_DESCRIBE(I).F_SIZE_ADD, ERROR_STR);
                             
                        ELSIF B_DESCRIBE(I).F_TYPE = 'V'
                        THEN
                            RES_CHECK_TYPE:= IMPORT_COMMON.CHECK_STR(PREPARED_DATA(I), B_DESCRIBE(I).F_SIZE, ERROR_STR);
                            
                        END IF;
                        
                        IF ERROR_STR IS NOT NULL  
                        THEN
                            UTL_FILE.PUT_LINE(FHANDLE_LOG,CONVERT( 'Строка' ||TO_CHAR(IMPORTED_ROW) || ' - ' || ERROR_STR,'CL8MSWIN1251','AL32UTF8') );
                            
                            NO_IMPORT:=0;
                            
                        END IF;
                        
                    END LOOP;  
                
                IF NO_IMPORT = 1  then 
                     
                        BEGIN
                      
                        INSERT INTO ORG_PRICE_LIST_ITEM (
                                    
                                    ID_ORG_PRICE_LIST, 
                                    ORDERBY_ITEM, 
                                    NAME, 
                                    ID_MEASURE, 
                                    COST_WITHOUT_VAT,
                                    VAT, 
                                    COST_VAT, 
                                    COST_WITH_VAT) 
                           VALUES ( 
                   
                                   IN_ID_LIST/* ID_ORG_PRICE_LIST */,
                                   IN_MUM_ITEM/* ORDERBY_ITEM */,
                                   PREPARED_DATA(1)/* NAME */,
                                   L_LITR/* ID_MEASURE */,
                                   PREPARED_DATA(3)/* COST_WITHOUT_VAT */,
                                   20/* VAT */,
                                   PREPARED_DATA(4) /* COST_VAT */,
                                   PREPARED_DATA(5)   /* COST_WITH_VAT */ );
                                              
                           
                          EXCEPTION
                                  WHEN DUP_VAL_ON_INDEX THEN
                                  COUNTER_ERROR_ROW:= COUNTER_ERROR_ROW + 1;
                                  UTL_FILE.PUT_LINE(FHANDLE_LOG,CONVERT( 'Строка' ||TO_CHAR(IMPORTED_ROW) || ' - при вставке в таблицу ПОЗИЦИИ ПРЕЙСКУРАНТА  дубликат ключа','CL8MSWIN1251','AL32UTF8') );
                                  WHEN OTHERS THEN
                                  COUNTER_ERROR_ROW:= COUNTER_ERROR_ROW + 1;
                                  l_errmsg:=SQLERRM;
                                  UTL_FILE.PUT_LINE(FHANDLE_LOG, CONVERT('Строка' ||TO_CHAR(IMPORTED_ROW) || ' - при вставке в таблицу ПОЗИЦИИ ПРЕЙСКУРАНТА ' ||l_errmsg,'CL8MSWIN1251','AL32UTF8') );
                                   
                        END;
                       
                                            COUNTER_IMPORTED_ROW:=COUNTER_IMPORTED_ROW+1;
                ELSE
                  COUNTER_ERROR_ROW:=COUNTER_ERROR_ROW+1;
                
                END IF;
               
      return 0;  
               
END  OIL_PRODUCT_ONE_ROW;


  
END IMPORT_PRODUCT_OIL;
/

