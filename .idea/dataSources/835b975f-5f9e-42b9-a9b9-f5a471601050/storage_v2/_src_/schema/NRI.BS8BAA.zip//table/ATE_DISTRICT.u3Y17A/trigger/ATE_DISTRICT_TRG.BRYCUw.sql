create trigger ATE_DISTRICT_TRG
  before insert
  on ATE_DISTRICT
  for each row
  BEGIN
     IF INSERTING AND :NEW.ID_OBJECT IS NULL THEN
      :NEW.ID_OBJECT:=ATE_DISTRICT_SEQ.NEXTVAL ;
    END IF;
 
END;
/

