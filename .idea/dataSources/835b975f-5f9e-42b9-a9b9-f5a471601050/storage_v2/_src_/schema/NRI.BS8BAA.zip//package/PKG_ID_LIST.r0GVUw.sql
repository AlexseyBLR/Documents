create PACKAGE     PKG_ID_LIST
IS
    FUNCTION BASE_CONFISCATION RETURN NUMBER;               --Основания для ареста и (или) изъятия имущества
    FUNCTION BASE_END_ACCOUNTING_UO RETURN NUMBER;          --Основания завершения учета уполномоченными органами
    FUNCTION BASE_END_ACCOUNTING_PD RETURN NUMBER;          --Основания завершения учета подразделениями Департамента
    FUNCTION STATUS_ACCOUNTING_CARD RETURN NUMBER;          --Статусы карточки учета имущества
    FUNCTION STATUS_FOLLOW_ACCOUNTING_CARD RETURN NUMBER;   --Статусы карточки последующего учета имущества
    FUNCTION BASE_DESTRUCTION RETURN NUMBER;                --Основания и критерии принятия решения об уничтожении имущества
    FUNCTION COST_WILD_ANIMAL_PLANT RETURN NUMBER;          --Стоимость живых диких животных, дикорастущих растений
    FUNCTION TYPES_SALE_AND_OTHER_USE RETURN NUMBER;        --Виды реализации и иного использования имущества
    FUNCTION TYPES_OF_TRADE  RETURN NUMBER;                 --Формы торговли
    FUNCTION BASE_CALC_MARKET_PRICE RETURN NUMBER;          --Основание расчета (определения) рыночной стоимости
    FUNCTION CATEGORY_CONFISCATION_NO_MONEY RETURN NUMBER;  --Категории изъятия имущества без поступления денежных средств
    FUNCTION CATEGORY_GOODS_RECEIPT_MONEY RETURN NUMBER;    --Категории имущества (по поступлению денежных средств)
    FUNCTION WAREHOUSE_TYPE RETURN NUMBER;                  --Виды складских помещений
    FUNCTION UO_GROUPS RETURN NUMBER;                       --Группы Уполномоченых органов
    FUNCTION POSTS RETURN NUMBER;                           --Должности
    FUNCTION CATEGORY_KEEPER RETURN NUMBER;                 --Категории хранителей
    FUNCTION MODE_STORAGE_WAREHOUSE RETURN NUMBER;          --Режимы хранения склада    
    FUNCTION STATUS_SUBDIVISION RETURN NUMBER;              --Статусы структурного подразделения
    FUNCTION TYPE_ORGANIZATION RETURN NUMBER;               --Типы организаций
    FUNCTION TYPE_SUBDIVISION RETURN NUMBER;                --Типы Структурных подразделений
    FUNCTION VEHICLE_TYPE RETURN NUMBER;                    --Типы транспортных средств
    FUNCTION VEHICLE_BODY_TYPE RETURN NUMBER;               --Типы кузова транспортных средств
    FUNCTION VEHICLE_FUEL_TYPE RETURN NUMBER;               --Типы топлива транспортных средств
    FUNCTION VEHICLE_FUEL_KIND RETURN NUMBER;               --Виды топлива транспортных средств    
    FUNCTION METHOD_DESTRUCTION RETURN NUMBER;              --Способы уничтожения имущества
    FUNCTION METHOD_DESTRUCTION_DANGER RETURN NUMBER;       --Способы уничтожения пиротехнических и ртутьсодержащих изделий, других опасных веществ
    FUNCTION BASE_DECREASE_MARKET_PRICE RETURN NUMBER;      --Основания уменьшения рыночной стоимости имущества
    FUNCTION BASE_INCREASE_MARKET_PRICE RETURN NUMBER;      --Основания увеличения рыночной стоимости имущества
    FUNCTION CRITERION_DECREASE_PRICE RETURN NUMBER;        --Критерии принятия решения об уценке имущества
    FUNCTION BASE_REPRICING RETURN NUMBER;                  --Основания переоценки
    FUNCTION NORMATIVE_LEGAL_ACTS RETURN NUMBER;            --Нормативные правовые акты
    FUNCTION PERISHABLE_GOODS_GROUPS RETURN NUMBER;         --Группы Скоропортящегося имущества 
    FUNCTION NOT_PRE_SALETRAINING_GOODS RETURN NUMBER;      --Ценности, не требующие предпродажной подготовки
    FUNCTION GOODS_GROUP_TYPES RETURN NUMBER;               --Виды групп имущества
    FUNCTION DOCUMENT_TEMPLATE_STATUS RETURN NUMBER;        --Статусы шаблона документа
    FUNCTION INPUT_PROCESS_TYPE RETURN NUMBER;              --Тип входного процесса 
    FUNCTION ATRIBUTE_TYPE RETURN NUMBER;                   --Типы атрибутов
    FUNCTION PRICE_LIST_MEASURE RETURN NUMBER;              --Единицы измерения (для прейскуранта)
    FUNCTION VEHICLE_DELIVERY_METHOD RETURN NUMBER;         --Способы доставки ТС 
    FUNCTION SECTION_VEHICLE_REPORT RETURN NUMBER;          --Описание разделов акта осмотра ТС
    FUNCTION STATE_ORGANIZATION_LICENSE RETURN NUMBER;      --Гос.органы и гос.организации, уполномоченные на выдачу специального разрешения (лицензии)
    FUNCTION DOCUMENT_CLASSIFIER RETURN NUMBER;             --Классификатор документов    
    FUNCTION TERM_TYPE RETURN NUMBER;                       --Тип срока
    FUNCTION GOODS_MIN_VOL RETURN NUMBER;                   --Признак имущества к которому относится минимальное количество
END;
/

