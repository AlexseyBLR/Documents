create PACKAGE BODY     PKG_ID_ORG_TYPE
IS
    DEF_DEPARTAMENT_ID CONSTANT NUMBER := 1000;-- ID Департамента как организации  

    DEF_DEPARTMENT CONSTANT NUMBER := 253;--Департамент
    DEF_AUTHORIZED_AGENCY CONSTANT NUMBER := 254;--Уполномоченные органы
    DEF_COMPETENT_AUTHORITY CONSTANT NUMBER := 255;--Компетентные органы
    DEF_SELLER CONSTANT NUMBER := 256;--Реализующие организации
    DEF_AUCTION CONSTANT NUMBER := 257;--Организаторы аукционов
    DEF_EXPERT_APPRAISERS CONSTANT NUMBER := 258;--Эксперты-оценщики
    DEF_KEEPER CONSTANT NUMBER := 259;--Хранители
    DEF_UTILIZATION CONSTANT NUMBER := 260;--Организации промышленной переработки и утилизации
    DEF_QUALITY_SAFETY_INSPECTION CONSTANT NUMBER := 261;--Организации по проведению работ по проверке на качество и безопасность
    DEF_OTHER_TYPE_EXPERTISE CONSTANT NUMBER := 262;--Организации правомочные проводить иные виды работ (экспертиз)
    DEF_DESTRUCTION_GOODS CONSTANT NUMBER := 263;--Организации осуществляющие уничтожение имущества
    DEF_EXTRACTION_NON_METAL_MNRLS CONSTANT NUMBER := 264;--Предприятия, занимающиеся добычей нерудных полезных ископаемых
    DEF_ACCOUNTS_STATE_AGENCY CONSTANT NUMBER := 265;--Государственные органы на счетах которых могут отражаться денежные средства полученные от реализации
    DEF_GOODS_IDENTIFICATION CONSTANT NUMBER := 266;--Организации осуществляющие идентификацию имущества
    DEF_GOODS_EXPERT CONSTANT NUMBER := 267;--Организации специалисты (товароведы) которых привлекаются к приемке имущества, проведению товароведческой экспертизы
    DEF_CONDITIONS_FOR_WILD_ANMLS CONSTANT NUMBER := 268;--Организации, имеющие условия для содержания и (или) разведения в неволе диких животных
    DEF_OTHER_ORGANIZATION CONSTANT NUMBER := 269;--Иные (НАН(Идентификация ДЖ и растений), Мин. Природы, МЧС, Мин. Культуры)
    DEF_NOT_SUBJECT_TO_PROCESSES CONSTANT NUMBER := 270;--Организации (участники системы) функции которых не подпадают под процессы постановления
    DEF_BANK CONSTANT NUMBER := 271;--Банки
    DEF_SUBDIVISION_DEPARTMENT CONSTANT NUMBER := 272;--Подразделение Департамента
    DEF_TRADING_OBJECT CONSTANT NUMBER := 273;--Торговый объект
    DEF_WAREHOUSE CONSTANT NUMBER := 274;--Складское помещение
    DEF_STORAGE_VEHICLES CONSTANT NUMBER := 275;--Площадка по хранению транспортных средств


    FUNCTION DEPARTAMENT_ID RETURN NUMBER -- ID Департамента как организации    
    IS
    BEGIN
        RETURN DEF_DEPARTAMENT_ID;
    END;

    FUNCTION DEPARTMENT RETURN NUMBER                      --Департамент
    IS 
    BEGIN
        RETURN DEF_DEPARTMENT;
    END;

    FUNCTION AUTHORIZED_AGENCY RETURN NUMBER               --Уполномоченные органы
    IS 
    BEGIN
        RETURN DEF_AUTHORIZED_AGENCY;
    END;
    
    FUNCTION COMPETENT_AUTHORITY RETURN NUMBER             --Компетентные органы
    IS 
    BEGIN
        RETURN DEF_COMPETENT_AUTHORITY;
    END;
    
    FUNCTION SELLER RETURN NUMBER                          --Реализующие организации
    IS 
    BEGIN
        RETURN DEF_SELLER;
    END;
    
    FUNCTION AUCTION RETURN NUMBER                         --Организаторы аукционов
    IS 
    BEGIN
        RETURN DEF_AUCTION;
    END;
    
    FUNCTION EXPERT_APPRAISERS RETURN NUMBER               --Эксперты-оценщики
    IS 
    BEGIN
        RETURN DEF_EXPERT_APPRAISERS;
    END;
    
    FUNCTION KEEPER RETURN NUMBER                          --Хранители
    IS 
    BEGIN
        RETURN DEF_KEEPER;
    END;
    
    FUNCTION UTILIZATION RETURN NUMBER                     --Организации промышленной переработки и утилизации
    IS 
    BEGIN
        RETURN DEF_UTILIZATION;
    END;
    
    FUNCTION QUALITY_SAFETY_INSPECTION RETURN NUMBER       --Организации по проведению работ по проверке на качество и безопасность
    IS 
    BEGIN
        RETURN DEF_QUALITY_SAFETY_INSPECTION;
    END;
    
    FUNCTION OTHER_TYPE_EXPERTISE RETURN NUMBER            --Организации правомочные проводить иные виды работ (экспертиз)
    IS 
    BEGIN
        RETURN DEF_OTHER_TYPE_EXPERTISE;
    END;
    
    FUNCTION DESTRUCTION_GOODS RETURN NUMBER               --Организации осуществляющие уничтожение имущества
    IS 
    BEGIN
        RETURN DEF_DESTRUCTION_GOODS;
    END;
    
    FUNCTION EXTRACTION_NON_METAL_MINERALS RETURN NUMBER   --Предприятия, занимающиеся добычей нерудных полезных ископаемых
    IS 
    BEGIN
        RETURN DEF_EXTRACTION_NON_METAL_MNRLS;
    END;
    
    FUNCTION ACCOUNTS_STATE_AGENCY RETURN NUMBER           --Государственные органы на счетах которых могут отражаться денежные средства полученные от реализации
    IS 
    BEGIN
        RETURN DEF_ACCOUNTS_STATE_AGENCY;
    END;
    
    FUNCTION GOODS_IDENTIFICATION RETURN NUMBER            --Организации осуществляющие идентификацию имущества
    IS 
    BEGIN
        RETURN DEF_GOODS_IDENTIFICATION;
    END;
    
    FUNCTION GOODS_EXPERT RETURN NUMBER               --Организации специалисты (товароведы) которых привлекаются к приемке имущества, проведению товароведческой экспертизы
    IS 
    BEGIN
        RETURN DEF_GOODS_EXPERT;
    END;
    
    FUNCTION CONDITIONS_FOR_WILD_ANIMALS RETURN NUMBER     --Организации, имеющие условия для содержания и (или) разведения в неволе диких животных
    IS 
    BEGIN
        RETURN DEF_CONDITIONS_FOR_WILD_ANMLS;
    END;
    
    FUNCTION OTHER_ORGANIZATION RETURN NUMBER              --Иные (НАН(Идентификация ДЖ и растений), Мин. Природы, МЧС, Мин. Культуры)
    IS 
    BEGIN
        RETURN DEF_OTHER_ORGANIZATION;
    END;
    
    FUNCTION NOT_SUBJECT_TO_PROCESSES RETURN NUMBER        --Организации (участники системы) функции которых не подпадают под процессы постановления
    IS 
    BEGIN
        RETURN DEF_NOT_SUBJECT_TO_PROCESSES;
    END;
       
    FUNCTION BANK RETURN NUMBER                            --Банки
    IS 
    BEGIN
        RETURN DEF_BANK;
    END;
    
    FUNCTION SUBDIVISION_DEPARTMENT RETURN NUMBER          --Подразделение Департамента
    IS 
    BEGIN
        RETURN DEF_SUBDIVISION_DEPARTMENT;
    END;
    
    FUNCTION TRADING_OBJECT RETURN NUMBER                  --Торговый объект
    IS 
    BEGIN
        RETURN DEF_TRADING_OBJECT;
    END;
    
    FUNCTION WAREHOUSE RETURN NUMBER                       --Складское помещение
    IS 
    BEGIN
        RETURN DEF_WAREHOUSE;
    END;
    
    FUNCTION STORAGE_VEHICLES RETURN NUMBER               --Площадка по хранению транспортных средств
    IS 
    BEGIN
        RETURN DEF_STORAGE_VEHICLES;
    END;
    

END;
/

