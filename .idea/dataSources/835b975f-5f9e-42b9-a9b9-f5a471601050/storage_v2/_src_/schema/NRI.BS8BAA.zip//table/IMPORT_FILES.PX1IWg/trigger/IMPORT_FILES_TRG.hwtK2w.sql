create trigger IMPORT_FILES_TRG
  before insert
  on IMPORT_FILES
  for each row
  begin   
  if :NEW."ID" is null then 
    select "IMPORT_FILES_SEQ".nextval into :NEW."ID" from sys.dual; 
  end if; 
end;
/

