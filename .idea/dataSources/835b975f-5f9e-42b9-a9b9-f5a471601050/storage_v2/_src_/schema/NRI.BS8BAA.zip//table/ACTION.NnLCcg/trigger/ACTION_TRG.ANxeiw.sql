create trigger ACTION_TRG
  before insert
  on ACTION
  for each row
  BEGIN
  if :NEW."ID_ACTION" is null then 
    :NEW."ID_ACTION":="ACTION_SEQ".nextval; 
  end if;
END;
/

