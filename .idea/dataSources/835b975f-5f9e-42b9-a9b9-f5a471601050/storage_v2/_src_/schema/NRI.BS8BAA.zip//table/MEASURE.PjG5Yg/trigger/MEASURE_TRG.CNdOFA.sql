create trigger MEASURE_TRG
  before insert
  on MEASURE
  for each row
  BEGIN

    IF INSERTING AND :NEW.ID_MEASURE IS NULL THEN
      :NEW.ID_MEASURE:=MEASURE_SEQ.NEXTVAL;
    END IF;
 
END;
/

