create trigger CONTACT_HISTORY_TRG
  before insert
  on CONTACT_HISTORY
  for each row
  BEGIN
  if :NEW."ID_CONTACT_HISTORY" is null then 
      :NEW."ID_CONTACT_HISTORY":="CONTACT_HISTORY_SEQ".nextval; 
  end if;
END;
/

