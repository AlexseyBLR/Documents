create trigger COUNTRY_TRG
  before insert
  on COUNTRY
  for each row
  BEGIN
  if :NEW."ID_COUNTRY" is null then 
       :NEW."ID_COUNTRY":="COUNTRY_SEQ".nextval; 
  end if;
END;
/

