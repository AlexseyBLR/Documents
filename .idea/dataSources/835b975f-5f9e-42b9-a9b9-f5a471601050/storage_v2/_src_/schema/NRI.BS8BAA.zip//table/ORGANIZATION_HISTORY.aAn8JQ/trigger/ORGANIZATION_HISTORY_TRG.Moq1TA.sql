create trigger ORGANIZATION_HISTORY_TRG
  before insert
  on ORGANIZATION_HISTORY
  for each row
  begin   
  if :NEW."ID_ORGANIZATION_HISTORY" is null then 
     :NEW."ID_ORGANIZATION_HISTORY":="ORGANIZATION_HISTORY_SEQ".nextval; 
  end if;
end;
/

