create trigger DOC_DOCS_TRG
  before insert
  on DOC_DOCS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_DOCS_SEQ.NEXTVAL;
  END IF; 
END;
/

