create trigger DOC_TEMPL_WASTE_TRG
  before insert
  on DOC_TEMPL_WASTE
  for each row
  begin   
  if :NEW.ID_DOC_TEMPL_ATTR is null then
    :NEW.ID_DOC_TEMPL_ATTR := konf.DOC_TEMPL_ATTR_SEQ.nextval;
  end if; 
end;
/

