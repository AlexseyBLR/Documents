create trigger DOC_HISTORY_TRG
  before insert
  on DOC_HISTORY
  for each row
  BEGIN   
  IF :NEW.ID_DOC_HISTORY IS NULL THEN
    :NEW.ID_DOC_HISTORY := DOC_HISTORY_SEQ.NEXTVAL;
  END IF; 
END;
/

