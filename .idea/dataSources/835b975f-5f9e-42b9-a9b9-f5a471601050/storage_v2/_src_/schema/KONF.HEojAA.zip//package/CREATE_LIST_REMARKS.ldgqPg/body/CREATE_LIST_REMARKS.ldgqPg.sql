create PACKAGE BODY      CREATE_LIST_REMARKS
IS
L_ID_PARENT DOC.ID_PARENT%TYPE:=0;
L_ID_DOC_TYPE DOC.ID_DOC_TYPE%TYPE:=0;
L_ID_DOC_PREV DOC.ID_DOC%TYPE;
----------------------
--- Создание листа замечаний
-- На основании сравнения данных в акте осмотра раздел 1 
FUNCTION CREATE_LIST( IN_ID_DOC  DOC.ID_DOC%TYPE) RETURN NUMBER IS
STR VARCHAR2(1024);
STR_1 VARCHAR2(1024);
l_errmsg VARCHAR2(1024);

BEGIN
  
SELECT ID_DOC_TYPE, ID_PARENT 
  INTO L_ID_DOC_TYPE,L_ID_PARENT
  FROM DOC
 WHERE ID_DOC = IN_ID_DOC;
 -- Определение идентификатора предшествующего листа амечаний 
 
 
 IF L_ID_DOC_TYPE=5 then 
    L_ID_DOC_PREV:=L_ID_PARENT;
 ELSE
 
     IF L_ID_DOC_TYPE=11 then 
        L_ID_DOC_TYPE:=10;
     END IF;
    
      SELECT ID_DOC
        INTO L_ID_DOC_PREV
        FROM DOC
       WHERE ID_DOC_TYPE = L_ID_DOC_TYPE - 1 
         AND ID_PARENT = L_ID_PARENT;
 END IF;
  
  --- Формирование различий по разделу 1
  
FOR ITEM IN (

SELECT ID_VEHICLE_MODEL,
       YEAR_ISSUE,
       ID_TYPE_VEHICLE,
       ID_TYPE_BODY,
       TYPE_VEHICLE_TEXT,
       REG_NUMBER,
       REG_CERTIFICATE_NUM,
       ID_REG_CERTIFICATE_COUNTRY,
       CAR_BODY_NUM,
       ENGINE_NUM,
       ID_COLOR,
       ID_COLOR_MOD,
       ID_COLOR_SHADE,
       NUMBER_SEATS,
       ODOMETER_VALUE,
       ODOMETER_NO_CAUSE,
       ID_FUEL_TYPE,
       FUEL_AMOUNT,
       FUEL_NO_CAUSE,
       FUEL_METERING_METHOD,
       ID_DELIVER_METHOD,
       TECHNICAL_CONDITION,
       NUMBER_PHOTOS,
       PERSONAL_ITEMS,
       REMARKS_STATEMENTS
  FROM KONF.ACT_INSPECTION_VEHICLE
 WHERE ID_DOC = IN_ID_DOC
)
LOOP
 
   FOR ITEM_PREV IN (

            SELECT ID_VEHICLE_MODEL,
                   YEAR_ISSUE,
                   ID_TYPE_VEHICLE,
                   ID_TYPE_BODY,
                   TYPE_VEHICLE_TEXT,
                   REG_NUMBER,
                   REG_CERTIFICATE_NUM,
                   ID_REG_CERTIFICATE_COUNTRY,
                   CAR_BODY_NUM,
                   ENGINE_NUM,
                   ID_COLOR,
                   ID_COLOR_MOD,
                   ID_COLOR_SHADE,
                   NUMBER_SEATS,
                   ODOMETER_VALUE,
                   ODOMETER_NO_CAUSE,
                   ID_FUEL_TYPE,
                   FUEL_AMOUNT,
                   FUEL_NO_CAUSE,
                   FUEL_METERING_METHOD,
                   ID_DELIVER_METHOD,
                   TECHNICAL_CONDITION,
                   NUMBER_PHOTOS,
                   PERSONAL_ITEMS,
                   REMARKS_STATEMENTS
               FROM KONF.ACT_INSPECTION_VEHICLE
              WHERE ID_DOC = L_ID_DOC_PREV
               )
            LOOP
              
            
            FOR ITEM_ACT IN (

            SELECT ID_VEHICLE_MODEL,
                   YEAR_ISSUE,
                   ID_TYPE_VEHICLE,
                   ID_TYPE_BODY,
                   TYPE_VEHICLE_TEXT,
                   REG_NUMBER,
                   REG_CERTIFICATE_NUM,
                   ID_REG_CERTIFICATE_COUNTRY,
                   CAR_BODY_NUM,
                   ENGINE_NUM,
                   ID_COLOR,
                   ID_COLOR_MOD,
                   ID_COLOR_SHADE,
                   NUMBER_SEATS,
                   ODOMETER_VALUE,
                   ODOMETER_NO_CAUSE,
                   ID_FUEL_TYPE,
                   FUEL_AMOUNT,
                   FUEL_NO_CAUSE,
                   FUEL_METERING_METHOD,
                   ID_DELIVER_METHOD,
                   TECHNICAL_CONDITION,
                   NUMBER_PHOTOS,
                   PERSONAL_ITEMS,
                   REMARKS_STATEMENTS
               FROM KONF.ACT_INSPECTION_VEHICLE
              WHERE ID_DOC = L_ID_PARENT
               )
                 LOOP
                           -------------
                           IF nvl(ITEM.ID_VEHICLE_MODEL,-1) <>nvl(ITEM_PREV.ID_VEHICLE_MODEL,-1) THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Марка, модель( модификация)',
                                    NRI.GET_NAME_LIST_DETAIL(ITEM_ACT.ID_VEHICLE_MODEL),
                                     NRI.GET_NAME_LIST_DETAIL(ITEM.ID_VEHICLE_MODEL));
                           END IF;
                          ----------------
                           IF nvl(ITEM.YEAR_ISSUE,to_date('01011800','ddmmyyyy'))<>nvl(ITEM_PREV.YEAR_ISSUE,to_date('01011800','ddmmyyyy')) THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Год выпуска',
                                    ITEM_ACT.YEAR_ISSUE,
                                    ITEM.YEAR_ISSUE);
                           END IF;
                           ------------------
                           IF nvl(ITEM.ID_TYPE_VEHICLE,-1)<>nvl(ITEM_PREV.ID_TYPE_VEHICLE,-1) or
                              nvl(ITEM.ID_TYPE_BODY,-1)<>nvl(ITEM_PREV.ID_TYPE_BODY,-1) or
                              nvl(ITEM.TYPE_VEHICLE_TEXT,'-1')<>nvl(ITEM_PREV.ID_TYPE_BODY,'-1') THEN
                             
                               INSERT_LIST_REM( IN_ID_DOC,1,'Тип транспортного средства',
                                        NRI.GET_NAME_LIST_DETAIL(ITEM_ACT.ID_TYPE_VEHICLE)||', '||
                                        NRI.GET_NAME_LIST_DETAIL(ITEM_ACT.ID_TYPE_BODY)||', '||
                                        ITEM_ACT.TYPE_VEHICLE_TEXT,
                                        
                                        NRI.GET_NAME_LIST_DETAIL(ITEM.ID_TYPE_VEHICLE)||', '||
                                        NRI.GET_NAME_LIST_DETAIL(ITEM.ID_TYPE_BODY)||', '||
                                        ITEM.TYPE_VEHICLE_TEXT);
                            END IF;
                            ---------------
                            
                           IF nvl(ITEM.REG_NUMBER,-1)<>nvl(ITEM_PREV.REG_NUMBER,-1) THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Регистрационный знак',
                                    ITEM_ACT.REG_NUMBER,
                                    ITEM.REG_NUMBER);
                           END IF;
                           ---------------
                            IF nvl(ITEM.REG_CERTIFICATE_NUM,-1)<>nvl(ITEM_PREV.REG_CERTIFICATE_NUM,-1) or 
                                nvl(ITEM.ID_REG_CERTIFICATE_COUNTRY,-1)<>nvl(ITEM_PREV.ID_REG_CERTIFICATE_COUNTRY,-1) 
                             THEN
                             SELECT    COUNTRY_NAME INTO STR
                              FROM NRI.COUNTRY WHERE ID_COUNTRY=ITEM_ACT.ID_REG_CERTIFICATE_COUNTRY AND IS_ACTUAL=1 and rownum=1;
                              
                              SELECT    COUNTRY_NAME INTO STR_1
                              FROM NRI.COUNTRY WHERE ID_COUNTRY=ITEM.ID_REG_CERTIFICATE_COUNTRY AND IS_ACTUAL=1 and rownum=1;
                              
                              
                              INSERT_LIST_REM( IN_ID_DOC,1,'Свидетельство о регистрации',
                                    ITEM_ACT.REG_CERTIFICATE_NUM||', '||STR,
                                    ITEM.ID_REG_CERTIFICATE_COUNTRY||', '||STR_1);
                           END IF;
                           ------------------
                            IF nvl(ITEM.CAR_BODY_NUM,-1)<>nvl(ITEM_PREV.CAR_BODY_NUM,-1) THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Идентификационный номер (номер кузова)',
                                    ITEM_ACT.CAR_BODY_NUM,
                                    ITEM.CAR_BODY_NUM);
                           END IF;
                           ---------------
                           IF nvl(ITEM.ENGINE_NUM,-1)<>nvl(ITEM_PREV.ENGINE_NUM,-1) THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Номер двигателя',
                                    ITEM_ACT.ENGINE_NUM,
                                    ITEM.ENGINE_NUM);
                           END IF;
                           ---------------
                           IF nvl(ITEM.ID_FUEL_TYPE,-1)<>nvl(ITEM_PREV.ID_FUEL_TYPE,-1) or
                              nvl(ITEM.FUEL_AMOUNT,-1)<>nvl(ITEM_PREV.FUEL_AMOUNT,-1) or
                              nvl(ITEM.FUEL_NO_CAUSE,'-1')<>nvl(ITEM_PREV.FUEL_NO_CAUSE,'-1') THEN
                             
                               INSERT_LIST_REM( IN_ID_DOC,1,'Наличие топлива ',
                                        NRI.GET_NAME_LIST_DETAIL(ITEM_ACT.ID_FUEL_TYPE)||', '||
                                       ITEM_ACT.FUEL_AMOUNT||', '||
                                       ITEM_ACT.FUEL_NO_CAUSE,
                                        
                                        NRI.GET_NAME_LIST_DETAIL(ITEM.ID_FUEL_TYPE)||', '||
                                        ITEM.FUEL_AMOUNT||', '||
                                       ITEM.FUEL_NO_CAUSE);
                            END IF;
                            --------------
                             IF nvl(ITEM.FUEL_METERING_METHOD,'-1')<>nvl(ITEM_PREV.FUEL_METERING_METHOD,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Способ замера топлива',
                                    ITEM_ACT.FUEL_METERING_METHOD,
                                    ITEM.FUEL_METERING_METHOD);
                             END IF;
                           --------------------
                           IF nvl(ITEM.ID_DELIVER_METHOD,'-1')<>nvl(ITEM_PREV.ID_DELIVER_METHOD,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Способ доставки',
                                     NRI.GET_NAME_LIST_DETAIL(ITEM_ACT.ID_DELIVER_METHOD),
                                     NRI.GET_NAME_LIST_DETAIL(ITEM.ID_DELIVER_METHOD));
                             END IF;
                           --------------------
                           
                            IF nvl(ITEM.TECHNICAL_CONDITION,'-1')<>nvl(ITEM_PREV.TECHNICAL_CONDITION,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Техническое состояние транспортного средства, неисправности',
                                     ITEM_ACT.TECHNICAL_CONDITION,
                                     ITEM.TECHNICAL_CONDITION);
                             END IF;
                           --------------------
                           
                            IF nvl(ITEM.NUMBER_PHOTOS,'-1')<>nvl(ITEM_PREV.NUMBER_PHOTOS,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Состояние и комплектность транспортного средства определены визуальным осмотром,фотоматериалы, видеоматериалы (прилагаются)',
                                     ITEM_ACT.NUMBER_PHOTOS,
                                     ITEM.NUMBER_PHOTOS);
                             END IF;
                           --------------------
                           IF nvl(ITEM.PERSONAL_ITEMS,'-1')<>nvl(ITEM_PREV.PERSONAL_ITEMS,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Наличие личных вещей в транспортном средстве',
                                     ITEM_ACT.PERSONAL_ITEMS,
                                     ITEM.PERSONAL_ITEMS);
                             END IF;
                           --------------------
                           IF nvl(ITEM.REMARKS_STATEMENTS,'-1')<>nvl(ITEM_PREV.REMARKS_STATEMENTS,'-1') THEN
                              INSERT_LIST_REM( IN_ID_DOC,1,'Замечания и заявления, сделанные присутствующими при осмотре',
                                     ITEM_ACT.REMARKS_STATEMENTS,
                                     ITEM.REMARKS_STATEMENTS);
                             END IF;
                           --------------------
                           
                 END LOOP;
        END LOOP;
  
END LOOP;
   --- Формирование отличий по разделам 2-4
     CREATE_LIST_2_4(IN_ID_DOC);
   
  return 1;
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
      l_errmsg:=SQLERRM;
       return -1;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
        l_errmsg:=SQLERRM;
       return -1;
       RAISE;
END CREATE_LIST;
---------------------------
--- Создание листа замечаний
-- На основании сравнения данных в акте осмотра раздел 2-4
PROCEDURE CREATE_LIST_2_4( IN_ID_DOC  DOC.ID_DOC%TYPE)  IS
L_ID_PART ACT_INSPECTION_VENICLE_PART.ID_PART%TYPE;
BEGIN
FOR ITEM_LIST IN (SELECT ID_PARENT,
                        ID_LIST_DETAIL,
                        NAME_LIST_DETAIL
                  FROM NRI.LIST_DETAIL
                  WHERE ID_LIST = 41 AND IS_ACTUAL=1 order by 1)
 LOOP
 
   IF  ITEM_LIST.ID_PARENT IS NOT NULL THEN
      FOR ITEM IN ( SELECT I.ID_PART,
                           I.NUM_PART,
                           I.IS_ELEMENT_YES,
                           I.ELEMENT_DESCRIPTION,
                           I.ID_ELEMENT_DESCRIPTION,
                           I.IS_ELEMENT_NO
                      FROM KONF.ACT_INSPECTION_VENICLE_PART I,
                           KONF.ACT_INSPECTION_VENICLE_PART PR
                     WHERE     I.ID_DOC =IN_ID_DOC
                           AND I.ID_ELEMENT = ITEM_LIST.ID_LIST_DETAIL
                           AND PR.ID_DOC = L_ID_DOC_PREV
                           AND PR.ID_ELEMENT = ITEM_LIST.ID_LIST_DETAIL
                           AND (   NVL (I.IS_ELEMENT_YES, -1) <> NVL (PR.IS_ELEMENT_YES, -1)
                                OR NVL (I.ELEMENT_DESCRIPTION, -1) <>
                                      NVL (PR.ELEMENT_DESCRIPTION, -1)
                                OR NVL (I.ID_ELEMENT_DESCRIPTION, -1) <>
                                      NVL (PR.ID_ELEMENT_DESCRIPTION, -1)
                                OR NVL (I.IS_ELEMENT_NO, -1) <> NVL (PR.IS_ELEMENT_NO, -1)))
                 LOOP         
      
           
                     --- Есть отличия
                     SELECT  ID_PART  
                       INTO  L_ID_PART                         
                       FROM  ACT_INSPECTION_VENICLE_PART 
                       WHERE ID_DOC=L_ID_PARENT AND ID_ELEMENT=ITEM_LIST.ID_LIST_DETAIL;
                       
                     INSERT_LIST_REM( IN_ID_DOC,ITEM.NUM_PART,
                                      NRI.GET_NAME_LIST_DETAIL(ITEM_LIST.ID_LIST_DETAIL),
                                     GET_VALUE_ELEMENT(L_ID_PART),
                                     GET_VALUE_ELEMENT(ITEM.ID_PART));
                   
                  
                
           END LOOP;
 END IF;
 END LOOP;                 

NULL;
END CREATE_LIST_2_4;
------------
 -- Формирует значение элемента по разделам 2-4 
FUNCTION GET_VALUE_ELEMENT( IN_ID_PART  ACT_INSPECTION_VENICLE_PART.ID_PART%TYPE)  return VARCHAR2 IS

STR VARCHAR2(1024);
BEGIN
SELECT TRIM(TRAILING ',' FROM
        TRIM( TRAILING ' ' FROM
            CASE  IS_ELEMENT_YES
               WHEN 1 THEN 'Есть, '
            END ||
            CASE    
               WHEN  ELEMENT_DESCRIPTION is not null  then ELEMENT_DESCRIPTION||',' 
            END ||
            CASE 
            WHEN ID_ELEMENT_DESCRIPTION is not null then NRI.GET_NAME_LIST_DETAIL( ID_ELEMENT_DESCRIPTION)||', '
            END ||
            CASE  IS_ELEMENT_NO
               WHEN 1 THEN 'Отсутствует'
            END
            ) 
          )
     INTO STR
FROM KONF.ACT_INSPECTION_VENICLE_PART WHERE ID_PART=IN_ID_PART;
  RETURN STR;
END;

-------
-- Вставляет запись в таблицу, содержащую информацию по листам замечаний и расхождений 
PROCEDURE INSERT_LIST_REM( 
                       IN_ID_DOC  DOC.ID_DOC%TYPE,
                       IN_NUM_PART ACT_INSPECT_VENICLE_LIST_REM.NUM_PART%TYPE,
                       IN_NAME_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.NAME_CHARACTERISTIC%TYPE,
                       IN_ACT_VALUE_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.ACT_VALUE_CHARACTERISTIC%TYPE, 
                       IN_ACTUAL_VALUE_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.ACTUAL_VALUE_CHARACTERISTIC%TYPE
)  IS
l_errmsg VARCHAR2(1024);
BEGIN

INSERT INTO KONF.ACT_INSPECT_VENICLE_LIST_REM (
                                       ID_DOC, 
                                       NUM_PART,
                                       NAME_CHARACTERISTIC,
                                       ACT_VALUE_CHARACTERISTIC, 
                                       ACTUAL_VALUE_CHARACTERISTIC
                                      ) 
                                    VALUES ( 
                                     IN_ID_DOC,
                                     IN_NUM_PART,
                                     IN_NAME_CHARACTERISTIC,
                                     IN_ACT_VALUE_CHARACTERISTIC,
                                     IN_ACTUAL_VALUE_CHARACTERISTIC
                                                                       );
                                                                
 EXCEPTION
     

     WHEN OTHERS THEN
      l_errmsg:=SQLERRM;
      RAISE;
END INSERT_LIST_REM;
END;
/

