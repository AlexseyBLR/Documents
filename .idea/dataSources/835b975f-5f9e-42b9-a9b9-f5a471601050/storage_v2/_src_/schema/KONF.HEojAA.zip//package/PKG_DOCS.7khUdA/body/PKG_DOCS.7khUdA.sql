create PACKAGE BODY      PKG_DOCS IS

    -- функция регистрации входящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION INCOMING_DOC_REGISTRATION(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_INCOMING_NUMBER IN VARCHAR2, -- входящий номер
        IN_INCOMING_DATE IN DATE,       -- дата регистрации входящего документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        IN_LOGIN_ACQUIRED IN VARCHAR2,  -- логин пользователя
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER
    IS
        V_ID_USER_ACQUIRED NUMBER := IN_ID_USER_ACQUIRED;
        V_ID_DOC_TYPE NUMBER;
        var number;
    BEGIN
        OUT_MESSAGE := NULL;
        -- т.к. приоритет у LOGIN_ACQUIRED то по нему вытаскиваем ID_USER
        IF IN_LOGIN_ACQUIRED IS NOT NULL THEN
            SELECT ID_USER INTO V_ID_USER_ACQUIRED FROM KONF_SECURITY.USERS
                WHERE USER_LOGIN = IN_LOGIN_ACQUIRED;
        END IF;

        UPDATE DOC SET
            INCOMING_NUMBER = IN_INCOMING_NUMBER,
            INCOMING_DATE = IN_INCOMING_DATE,
            ID_USER_ACQUIRED = V_ID_USER_ACQUIRED
            WHERE ID_DOC = IN_ID_DOC;

        UPDATE NOTIF SET
            ID_USER_ACQUIRED = V_ID_USER_ACQUIRED,
            IS_NOTIF_PROCESSED = 1
            WHERE ID_DOC = IN_ID_DOC
                AND IS_NOTIF_PROCESSED = 0
                AND ID_ACTION = 1; /*Регистрация входящего документа*/

        SELECT ID_DOC_TYPE INTO V_ID_DOC_TYPE FROM DOC WHERE ID_DOC = IN_ID_DOC;

        CASE V_ID_DOC_TYPE
         /*Заявление на оценку имущества статус имущества из заявления изменять на статус «Подлежит рассмотрению».*/

        WHEN 61 THEN --V_ID_ASSET_STATUS := 3; /*Работа приостановлена*/
            UPDATE ASSET_STATUS SET
                ID_PREV_ASSET_STATUS = ID_CURR_ASSET_STATUS,
                ID_CURR_ASSET_STATUS = 4 /*Подлежит рассмотрению*/
                WHERE ID_ASSET_PARENT IN (
                    SELECT ID_ASSET_PARENT FROM DOC_ASSETS WHERE ID_DOC = IN_ID_DOC
                    );
        /*Письмо от ПД о приостановке работ*/
        WHEN 121 THEN --V_ID_ASSET_STATUS := 3; /*Работа приостановлена*/
            UPDATE ASSET_STATUS SET
                ID_PREV_ASSET_STATUS = ID_CURR_ASSET_STATUS,
                ID_CURR_ASSET_STATUS = 3 /*Работа приостановлена*/
                WHERE ID_ASSET_PARENT IN (
                    SELECT ID_ASSET_PARENT FROM DOC_ASSETS WHERE ID_DOC = IN_ID_DOC
                    );
        /*Письмо от ПД о возобновлении работ*/
        WHEN 122 THEN
            UPDATE ASSET_STATUS SET
                ID_CURR_ASSET_STATUS = ID_PREV_ASSET_STATUS,
                ID_PREV_ASSET_STATUS = 3 /*Работа приостановлена*/
                WHERE ID_ASSET_PARENT IN (
                    SELECT ID_ASSET_PARENT FROM DOC_ASSETS WHERE ID_DOC = IN_ID_DOC
                    );
        /*Письмо от ПД о прекращении работ*/
        WHEN 123 THEN
            UPDATE ASSET_STATUS SET
                ID_PREV_ASSET_STATUS = ID_CURR_ASSET_STATUS,
                ID_CURR_ASSET_STATUS = 2 /*Работа прекращена*/
                WHERE ID_ASSET_PARENT IN (
                    SELECT ID_ASSET_PARENT FROM DOC_ASSETS WHERE ID_DOC = IN_ID_DOC
                    );
         /*Письмо от ПД о необходимости проведения оценки имущества*/
        WHEN 124 THEN
            UPDATE ASSET_STATUS SET
                ID_PREV_ASSET_STATUS = ID_CURR_ASSET_STATUS,
                ID_CURR_ASSET_STATUS = 1 /*На рассмотрении*/
                WHERE ID_ASSET_PARENT IN (
                    SELECT ID_ASSET_PARENT FROM DOC_ASSETS WHERE ID_DOC = IN_ID_DOC
                    );
        ELSE
          OUT_MESSAGE:= 'Неизвестный тип документа';
          RETURN -1;
        END CASE;

        RETURN 0;
    EXCEPTION
        WHEN OTHERS THEN
            OUT_MESSAGE:= SQLERRM;
            RETURN -1;
    END;


    -- функция регистрации исходящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION OUTGOING_DOC_REGISTRATION(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_OUTGOING_NUMBER IN VARCHAR2, -- входящий номер
        IN_OUTGOING_DATE IN DATE,       -- дата регистрации входящего документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER
    IS
    BEGIN
        UPDATE DOC SET
            OUTGOING_NUMBER = IN_OUTGOING_NUMBER,
            OUTGOING_DATE = IN_OUTGOING_DATE,
            ID_USER_ACQUIRED = IN_ID_USER_ACQUIRED
            WHERE ID_DOC = IN_ID_DOC;

        UPDATE NOTIF SET
            ID_USER_ACQUIRED = IN_ID_USER_ACQUIRED,
            IS_NOTIF_PROCESSED = 1
            WHERE ID_DOC = IN_ID_DOC
                AND IS_NOTIF_PROCESSED = 0
                AND ID_ACTION = 2; /*Регистрация входящего документа*/

        RETURN 0;
    EXCEPTION
        WHEN OTHERS THEN
            OUT_MESSAGE := SQLERRM;
            RETURN -1;
    END;

    -- функция проверяет наличие роли у пользователя
    -- возвращает
    --  -1 - есть ошибка
    -- 0 - роль пользователю НЕ дана
    -- 1 - роль у пользователя есть
    FUNCTION CHECK_USER_ROLE(
        IN_ID_USER NUMBER,  -- ID пользователя
        IN_ID_ROLE NUMBER   -- ID роли
    )
    RETURN NUMBER
    IS
        V_CNT NUMBER;
    BEGIN
        SELECT COUNT(*) INTO V_CNT FROM KONF_SECURITY.USER_ROLES
            WHERE ID_USER = IN_ID_USER
                AND ID_ROLE = IN_ID_ROLE;
        RETURN V_CNT;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN -1;
    END;


    -- функция, реализующая взятие в работу документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION PROCEED_WITH_DOCUMENT(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER
    IS
        V_DOC_TYPE NUMBER;
        V_DOC_STATUS NUMBER;

        V_IS_AGREEMENT_REQUIRED NUMBER;
        V_IS_DIGITAL_SIGN_REQUIRED NUMBER;
        V_IS_OUTGOING_REG_REQUIRED NUMBER;

        V_REZ_CHECK_USER_ROLE NUMBER;
        V_REZ_DOC_STATUS NUMBER;
        V_REZ_FUNC NUMBER := 0;

    BEGIN
        OUT_MESSAGE := NULL;

        SELECT ID_DOC_TYPE, ID_DOC_STATUS INTO V_DOC_TYPE, V_DOC_STATUS
            FROM DOC
            WHERE ID_DOC = IN_ID_DOC;

        SELECT IS_AGREEMENT_REQUIRED, IS_DIGITAL_SIGN_REQUIRED, IS_OUTGOING_REG_REQUIRED
            INTO V_IS_AGREEMENT_REQUIRED, V_IS_DIGITAL_SIGN_REQUIRED, V_IS_OUTGOING_REG_REQUIRED
            FROM NRI.DOC_TYPE
            WHERE ID_DOC_TYPE = V_DOC_TYPE;

        CASE V_DOC_STATUS
        WHEN 1 /* Создан */THEN
            IF V_IS_AGREEMENT_REQUIRED = 1 THEN
                V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 1 /* Согласование документа */);
                IF V_REZ_CHECK_USER_ROLE = 1 THEN
                    V_REZ_DOC_STATUS := 7; /* Готов для согласования */
                ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                    V_REZ_FUNC := -1;
                    OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Согласование документа''';
                ELSE
                    V_REZ_FUNC := -1;
                END IF;
            ELSE
                IF V_IS_DIGITAL_SIGN_REQUIRED = 1 THEN
                    V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 2 /* Подписание документа */);
                    IF V_REZ_CHECK_USER_ROLE = 1 THEN
                        V_REZ_DOC_STATUS := 10; /* Готов для подписания */
                    ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                        V_REZ_FUNC := -1;
                        OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Подписание документа''';
                    ELSE
                        V_REZ_FUNC := -1;
                    END IF;
                ELSE
                    IF V_IS_OUTGOING_REG_REQUIRED = 1 THEN
                        V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
                        IF V_REZ_CHECK_USER_ROLE = 1 THEN
                            V_REZ_DOC_STATUS := 13; /* Готов для регистрации */
                        ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                            V_REZ_FUNC := -1;
                            OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
                        ELSE
                            V_REZ_FUNC := -1;
                        END IF;
                    ELSE
                        V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
                        IF V_REZ_CHECK_USER_ROLE = 1 THEN
                            V_REZ_DOC_STATUS := 4; /* Отправлен */
                        ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                            V_REZ_FUNC := -1;
                            OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
                        ELSE
                            V_REZ_FUNC := -1;
                        END IF;
                    END IF;
                END IF;
            END IF;

        WHEN 2 /* На регистрации */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 3; /* Зарегистрирован */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 3 /* Зарегистрирован */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 4; /* Отправлен */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;
        --WHEN 4 THEN /* пока не определено*/


        WHEN 5 /* На доработке */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 4 /* Создание документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 14; /* Отправлен */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Создание документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 6 /* Требуется доработка */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 4 /* Создание документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 5; /* На доработке */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Создание документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 7 /* Готов для согласования */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 1 /* Согласование документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 8; /* На согласовании */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Согласование документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 8 /* На согласовании */ THEN
            --  возможных новых статусов документа более одного
            -- это исключительная ситуация
            V_REZ_FUNC := -1;
            OUT_MESSAGE := 'Ошибка. Обратитесь к разработчикам';

        WHEN 9 /* Согласован */ THEN
            IF V_IS_DIGITAL_SIGN_REQUIRED = 1 THEN
                V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 2 /* Подписание документа */);
                IF V_REZ_CHECK_USER_ROLE = 1 THEN
                    V_REZ_DOC_STATUS := 10; /* Готов для подписания */
                ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                    V_REZ_FUNC := -1;
                    OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Подписание документа''';
                ELSE
                    V_REZ_FUNC := -1;
                END IF;
            ELSE
                IF V_IS_OUTGOING_REG_REQUIRED = 1 THEN
                    V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
                    IF V_REZ_CHECK_USER_ROLE = 1 THEN
                        V_REZ_DOC_STATUS := 13; /* Готов для регистрации */
                    ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                        V_REZ_FUNC := -1;
                        OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
                    ELSE
                        V_REZ_FUNC := -1;
                    END IF;
                ELSE
                    V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
                    IF V_REZ_CHECK_USER_ROLE = 1 THEN
                        V_REZ_DOC_STATUS := 4; /* Отправлен */
                    ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                        V_REZ_FUNC := -1;
                        OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
                    ELSE
                        V_REZ_FUNC := -1;
                    END IF;
                END IF;
            END IF;

        WHEN 10 /* Готов для подписания */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 2 /* Подписание документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 11; /* Готов для подписания */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Подписание документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 11 /* На подписании */ THEN
            --  возможных новых статусов документа более одного
            -- это исключительная ситуация
            V_REZ_FUNC := -1;
            OUT_MESSAGE := 'Ошибка. Обратитесь к разработчикам';

        WHEN 12 /* Подписан */ THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                IF V_IS_OUTGOING_REG_REQUIRED = 1 THEN
                    V_REZ_DOC_STATUS := 13; /* Готов для регистрации */
                ELSE
                    V_REZ_DOC_STATUS := 4; /* Отправлен */
                END IF;
            ELSE
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
            END IF;

        WHEN 13 /* Готов для регистрации*/  THEN
            V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 3 /* Регистрация документа */);
            IF V_REZ_CHECK_USER_ROLE = 1 THEN
                V_REZ_DOC_STATUS := 2; /* На регистрации */
            ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                V_REZ_FUNC := -1;
                OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Регистрация документа''';
            ELSE
                V_REZ_FUNC := -1;
            END IF;

        WHEN 14 /* Доработан */ THEN
            IF V_IS_AGREEMENT_REQUIRED = 1 THEN
                V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 1 /* Согласование документа */);
                IF V_REZ_CHECK_USER_ROLE = 1 THEN
                    V_REZ_DOC_STATUS := 7; /* Готов для согласования */
                ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                    V_REZ_FUNC := -1;
                    OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Согласование документа''';
                ELSE
                    V_REZ_FUNC := -1;
                END IF;
            ELSE
                IF V_IS_DIGITAL_SIGN_REQUIRED = 1 THEN
                    V_REZ_CHECK_USER_ROLE := CHECK_USER_ROLE(IN_ID_USER_ACQUIRED, 2 /* Подписание документа */);
                    IF V_REZ_CHECK_USER_ROLE = 1 THEN
                        V_REZ_DOC_STATUS := 10; /* Готов для подписания */
                    ELSIF V_REZ_CHECK_USER_ROLE = 0 THEN
                        V_REZ_FUNC := -1;
                        OUT_MESSAGE := 'У пользователя нет права выполнить действие ''Подписание документа''';
                    ELSE
                        V_REZ_FUNC := -1;
                    END IF;
                ELSE
                    V_REZ_FUNC := -1;
                    OUT_MESSAGE := 'Ошибка. Обратитесь к разработчикам';
                END IF;
            END IF;

        END CASE;

        IF V_REZ_FUNC = 0 THEN
        -- нашли подходящий статус документа
            UPDATE DOC SET
                ID_DOC_STATUS = V_REZ_DOC_STATUS,
                ID_USER_ACQUIRED = IN_ID_USER_ACQUIRED
                WHERE ID_DOC = IN_ID_DOC;

            UPDATE NOTIF SET
                IS_NOTIF_PROCESSED = 1,
                ID_USER_ACQUIRED = IN_ID_USER_ACQUIRED
                WHERE ID_DOC = IN_ID_DOC
                    AND IS_NOTIF_PROCESSED = 0;
        END IF;

        RETURN V_REZ_FUNC;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN -1;
    END;

    -- создание уведомления
    -- возвращает
    -- -1 - есть ошибка
    -- 0 - нет ошибок
    FUNCTION NOTIF_CREATE(
        IN_ID_NOTIF_TYPE       IN NUMBER,     -- ID типа уведомления
        IN_IS_NOTIF_PROCESSED     IN NUMBER,     -- Уведомление обработано (1/0 - Да/Нет)
        IN_NOTIF_SHORT_TEXT       IN VARCHAR2,   -- Краткий текст уведомления
        IN_NOTIF_COMMENT          IN VARCHAR2,   -- Комментарий
        IN_ID_ACTION              IN NUMBER,     -- ID действия, которое можно выполнить в ответ на уведомление
        IN_ID_GROUP_ASSIGNEE      IN NUMBER,     -- ID группы (роли, права), на которую назначено уведомление
        IN_ID_USER_ASSIGNEE       IN NUMBER,     -- ID пользователя, на которого назначено уведомление
        IN_ID_USER_ACQUIRED       IN NUMBER,     -- ID пользователя, который взял в работу уведомление
        IN_ID_DOC                 IN NUMBER,     -- ID связанного документа
        IN_ID_PROCESS             IN NUMBER,     -- ID связанного бизнес-процесса/функции/шага функции
        IN_TASKNUMBER             IN NUMBER,     -- Номер задачи (BPEL task number)
        IN_IS_NOTIF_NEED_PROCESS  IN NUMBER,     -- На уведомление нужно обязательно отреагировать
        IN_CREATED_DATE           IN DATE,       -- Дата создания
        IN_EXPIRATION_DATE        IN DATE,       -- Дата истечения уведомления - после этой даты оно не актуально
        IN_UPDATED_DATE           IN DATE,       -- Дата обновления уведомления
        IN_PRIORITY               IN NUMBER,     -- Приоритет
        IN_NOTIF_ACTION_DESC      IN VARCHAR2,   -- Описание действия (можно писать название действия из справочника)
        IN_ASSIGNEE_ROLE_DESC    IN VARCHAR2,    -- Описание роли (можно писать название роли из справочника)
        IN_ASSIGNEE_USER_DESC     IN VARCHAR2,   -- Описание пользователя (можно писать ФИО, должность и т.д.)
        IN_ACQUIRED_USER_DESC     IN VARCHAR2,   -- Описание пользователя (можно писать ФИО, должность и т.д.)
        IN_DOC_DESC               IN VARCHAR2,   -- Описание документа
        IN_PROCESS_DESC           IN VARCHAR2,   -- Описание процесса
        IN_NOTIF_STATUS_DESC      IN VARCHAR2,   -- Описание статуса
        IN_ID_ORGANIZATION        IN NUMBER      -- ID организации
    )
    RETURN NUMBER
    IS
        V_NOTIF_TEXT VARCHAR2(2000 CHAR) := '';

        V_REZ_FUNC NUMBER := 0;
        V_TEMPLATE_STR VARCHAR2(2000 CHAR);
        V_SQL_TEXT VARCHAR2(1000 CHAR);
        V_SUBSTITUTION_VALUE VARCHAR2(256 CHAR);
    BEGIN
        -- СБОРКА V_NOTIF_TEXT
        SELECT NOTIF_TYPE_TEMPLATE INTO V_TEMPLATE_STR
            FROM NRI.NOTIF_TYPE
            WHERE ID_NOTIF_TYPE = IN_ID_NOTIF_TYPE;
        V_NOTIF_TEXT := V_TEMPLATE_STR;
        FOR SUBSTR_TMPL IN (SELECT REGEXP_SUBSTR(STR, '\%.*?\%+?', 1, LEVEL) STR
                                FROM (SELECT V_TEMPLATE_STR STR FROM DUAL) T
                            CONNECT BY INSTR(STR, '%', 1, LEVEL * 2 - 1) > 1)
        LOOP
            --цикл перебирает каждую подстановку в строке-шаблоне
            SELECT SQL_TEXT INTO V_SQL_TEXT FROM NRI.SUBSTR_TEMPLATE WHERE SUBSTITUTION_STR = SUBSTR_TMPL.STR;
            EXECUTE IMMEDIATE V_SQL_TEXT INTO V_SUBSTITUTION_VALUE USING IN_ID_DOC;
            V_NOTIF_TEXT := REPLACE(V_NOTIF_TEXT, SUBSTR_TMPL.STR, V_SUBSTITUTION_VALUE);
        END LOOP;

        INSERT INTO NOTIF (
            ID_NOTIF_TYPE,
            IS_NOTIF_PROCESSED,
            NOTIF_TEXT,
            NOTIF_SHORT_TEXT,
            NOTIF_COMMENT,
            ID_ACTION,
            ID_ROLE_ASSIGNEE,
            ID_USER_ASSIGNEE,
            ID_USER_ACQUIRED,
            ID_DOC,
            ID_PROCESS,
            TASKNUMBER,
            IS_NOTIF_NEED_PROCESS,
            CREATED_DATE,
            EXPIRATION_DATE,
            UPDATED_DATE,
            PRIORITY,
            NOTIF_ACTION_DESC,
            ASSIGNEE_ROLE_DESC,
            ASSIGNEE_USER_DESC,
            ACQUIRED_USER_DESC,
            DOC_DESC, PROCESS_DESC,
            NOTIF_STATUS_DESC,
            ID_ORGANIZATION
           )
        VALUES (
            IN_ID_NOTIF_TYPE ,
            IN_IS_NOTIF_PROCESSED ,
            V_NOTIF_TEXT ,
            IN_NOTIF_SHORT_TEXT ,
            IN_NOTIF_COMMENT ,
            IN_ID_ACTION ,
            IN_ID_GROUP_ASSIGNEE ,
            IN_ID_USER_ASSIGNEE ,
            IN_ID_USER_ACQUIRED ,
            IN_ID_DOC ,
            IN_ID_PROCESS ,
            IN_TASKNUMBER ,
            IN_IS_NOTIF_NEED_PROCESS ,
            IN_CREATED_DATE ,
            IN_EXPIRATION_DATE ,
            IN_UPDATED_DATE ,
            IN_PRIORITY ,
            IN_NOTIF_ACTION_DESC ,
            IN_ASSIGNEE_ROLE_DESC ,
            IN_ASSIGNEE_USER_DESC ,
            IN_ACQUIRED_USER_DESC ,
            IN_DOC_DESC ,
            IN_PROCESS_DESC ,
            IN_NOTIF_STATUS_DESC ,
            IN_ID_ORGANIZATION
         );


        RETURN V_REZ_FUNC;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN -1;
    END;

    -- функция, реализующая отправку исходящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (OUT_MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION SENDING_OUTGOING_DOC(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        IN_SENDING_DATE DATE,           -- дата отправки
        IN_SENDING_MODE VARCHAR2,       -- способ отправки
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER
    IS
        V_REZ_FUNC NUMBER := 0;
        V_IS_INCOMING_REG_REQUIRED NUMBER;
        V_IS_EXT_DEST NUMBER;
        V_ID_DEST_ORG NUMBER;

        -- Список ID организаций из DOC_ORGS для которых будут уведомления
        TYPE V_ID_ORG_NOTIF_T IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
        V_ID_ORG_NOTIF V_ID_ORG_NOTIF_T;

        REZ_CREATE_NOTIF NUMBER := 0;
    BEGIN
        UPDATE DOC SET
            ID_DOC_STATUS = 4, /* отправлен */
            ID_USER_ACQUIRED = IN_ID_USER_ACQUIRED,
            SENDING_DATE = IN_SENDING_DATE,
            SENDING_MODE = IN_SENDING_MODE
            WHERE ID_DOC = IN_ID_DOC;

        SELECT DT.IS_INCOMING_REG_REQUIRED, D.IS_EXT_DEST, D.ID_DEST_ORG
            INTO V_IS_INCOMING_REG_REQUIRED, V_IS_EXT_DEST, V_ID_DEST_ORG
            FROM NRI.DOC_TYPE DT, DOC D
            WHERE D.ID_DOC = IN_ID_DOC
                AND D.ID_DOC_TYPE = DT.ID_DOC_TYPE;

        IF (V_IS_INCOMING_REG_REQUIRED = 1) /* обязательная регистрация входящего */
            AND (V_IS_EXT_DEST = 0) /* участник АИС "Конфискат" */
        THEN
            -- генерация уведомления на организацию из поля DOC.ID_DEST_ORG
            REZ_CREATE_NOTIF := NOTIF_CREATE(
               1, --ID_NOTIF_TYPE
               NULL, --IS_NOTIF_PROCESSED
               NULL, --NOTIF_SHORT_TEXT
               NULL, --NOTIF_COMMENT
               1,  /* Регистрация входящего документ */ -- ID_ACTION
               3,  /* Регистрирация документа */ --ID_GROUP_ASSIGNEE
               NULL, --ID_USER_ASSIGNEE
               NULL, --ID_USER_ACQUIRED
               IN_ID_DOC, --ID_DOC
               NULL, --ID_PROCESS
               NULL, --TASKNUMBER
               NULL, --IS_NOTIF_NEED_PROCESS
               NULL, --CREATED_DATE
               NULL, --EXPIRATION_DATE
               NULL, --UPDATED_DATE
               NULL, --PRIORITY
               NULL, --NOTIF_ACTION_DESC
               NULL, --ASSIGNEE_GROUP_DESC
               NULL, --ASSIGNEE_USER_DESC
               NULL, --ACQUIRED_USER_DESC
               NULL, --DOC_DESC,
               NULL, --PROCESS_DESC
               NULL, --NOTIF_STATUS_DESC
               V_ID_DEST_ORG --ID_ORGANIZATION
            );
            IF REZ_CREATE_NOTIF = -1 THEN
                V_REZ_FUNC:= -1;
                OUT_MESSAGE := 'Ошибка создания уведомления';
            END IF;
        END IF;

        -- генерация уведомления на организации из DOC_ORGS
        FOR SEL_ORGS IN (
            SELECT ID_ORG FROM DOC_ORGS
                WHERE ID_DOC = IN_ID_DOC
                    AND IS_EXT_CONF_PERSON = 0
                    AND IS_DOC_NOTICE = 1
                    )
        LOOP
            REZ_CREATE_NOTIF := NOTIF_CREATE(
               1, --ID_NOTIF_TYPE
               NULL, --IS_NOTIF_PROCESSED
               NULL, --NOTIF_SHORT_TEXT
               NULL, --NOTIF_COMMENT
               1,  /* Регистрация входящего документ */ -- ID_ACTION
               3,  /* Регистрирация документа */ --ID_GROUP_ASSIGNEE
               NULL, --ID_USER_ASSIGNEE
               NULL, --ID_USER_ACQUIRED
               IN_ID_DOC, --ID_DOC
               NULL, --ID_PROCESS
               NULL, --TASKNUMBER
               NULL, --IS_NOTIF_NEED_PROCESS
               NULL, --CREATED_DATE
               NULL, --EXPIRATION_DATE
               NULL, --UPDATED_DATE
               NULL, --PRIORITY
               NULL, --NOTIF_ACTION_DESC
               NULL, --ASSIGNEE_GROUP_DESC
               NULL, --ASSIGNEE_USER_DESC
               NULL, --ACQUIRED_USER_DESC
               NULL, --DOC_DESC,
               NULL, --PROCESS_DESC
               NULL, --NOTIF_STATUS_DESC
               SEL_ORGS.ID_ORG --ID_ORGANIZATION
            );
            IF REZ_CREATE_NOTIF = -1 THEN
                V_REZ_FUNC:= -1;
                OUT_MESSAGE := 'Ошибка создания уведомления';
            END IF;
        END LOOP;
        RETURN V_REZ_FUNC;
    EXCEPTION
        WHEN OTHERS THEN
            OUT_MESSAGE:= SQLERRM;
            RETURN -1;
    END;

    FUNCTION TEST_INSERT_DB RETURN NUMBER
    IS
    BEGIN
        INSERT INTO TEST VALUES (XMLTYPE('<DOC/>'));
        RETURN 0;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN -1;
    END;
END;
/

