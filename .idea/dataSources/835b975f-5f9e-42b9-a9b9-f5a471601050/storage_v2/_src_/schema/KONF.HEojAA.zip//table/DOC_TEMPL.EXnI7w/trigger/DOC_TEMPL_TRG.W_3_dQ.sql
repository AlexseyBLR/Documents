create trigger DOC_TEMPL_TRG
  before insert
  on DOC_TEMPL
  for each row
  begin   
  if :NEW.ID_DOC_TEMPL is null then
    :NEW.ID_DOC_TEMPL := konf.DOC_TEMPL_SEQ.nextval;
  end if; 
end;
/

