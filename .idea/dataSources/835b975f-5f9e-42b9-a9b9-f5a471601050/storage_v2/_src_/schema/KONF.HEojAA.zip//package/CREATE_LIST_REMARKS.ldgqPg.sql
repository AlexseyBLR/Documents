create PACKAGE      CREATE_LIST_REMARKS AS

  --Формирование различий между актом осмотра ТС (документ - IN_ID_DOC) и его предшественником
  FUNCTION CREATE_LIST( IN_ID_DOC  DOC.ID_DOC%TYPE) RETURN NUMBER;
   --Формирование различий  по разделам 2-4 между актом осмотра ТС (документ - IN_ID_DOC) и его предшественником 
  PROCEDURE CREATE_LIST_2_4( IN_ID_DOC  DOC.ID_DOC%TYPE);
  -- Формирует значение элемента по разделам 2-4 
  FUNCTION GET_VALUE_ELEMENT( IN_ID_PART  ACT_INSPECTION_VENICLE_PART.ID_PART%TYPE)  return VARCHAR2;
  -- Вставляет запись в таблицу, содержащую информацию по листам замечаний и расхождений 
 PROCEDURE INSERT_LIST_REM( 
                       IN_ID_DOC  DOC.ID_DOC%TYPE,
                       IN_NUM_PART ACT_INSPECT_VENICLE_LIST_REM.NUM_PART%TYPE,
                       IN_NAME_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.NAME_CHARACTERISTIC%TYPE,
                       IN_ACT_VALUE_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.ACT_VALUE_CHARACTERISTIC%TYPE, 
                       IN_ACTUAL_VALUE_CHARACTERISTIC ACT_INSPECT_VENICLE_LIST_REM.ACTUAL_VALUE_CHARACTERISTIC%TYPE);

END CREATE_LIST_REMARKS;
/

