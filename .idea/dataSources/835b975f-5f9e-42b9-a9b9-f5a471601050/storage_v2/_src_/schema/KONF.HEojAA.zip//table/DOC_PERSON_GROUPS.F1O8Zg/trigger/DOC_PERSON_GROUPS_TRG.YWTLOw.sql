create trigger DOC_PERSON_GROUPS_TRG
  before insert
  on DOC_PERSON_GROUPS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_PERSON_GROUPS_SEQ.NEXTVAL;
  END IF; 
END;
/

