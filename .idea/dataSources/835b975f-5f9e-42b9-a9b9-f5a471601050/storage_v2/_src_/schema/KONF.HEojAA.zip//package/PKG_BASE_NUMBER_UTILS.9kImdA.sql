create PACKAGE      PKG_BASE_NUMBER_UTILS
IS
   /******************************************************************************/
   /* Функция: Функции преобразования и вывода чисел прописью                    */
   /* Разработчик: Лычковский Я.В.                                               */
   /* Дата создания    : 17,03,2010                                              */
   /* Дата модификации :                                                         */
   /******************************************************************************/
   FUNCTION moneytospeechshort (quant IN NUMBER)
      RETURN VARCHAR2;

   PRAGMA RESTRICT_REFERENCES (moneytospeechshort, WNPS, RNPS, WNDS);
   
    FUNCTION moneytospeech (quant IN NUMBER)
      RETURN VARCHAR2;

   PRAGMA RESTRICT_REFERENCES (moneytospeech, WNPS, RNPS, WNDS);

   FUNCTION inttospeech (dig IN NUMBER, sex IN VARCHAR2)
      RETURN VARCHAR2;

   PRAGMA RESTRICT_REFERENCES (inttospeech, WNPS, RNPS, WNDS);

   FUNCTION date_speech (num IN NUMBER, dmy IN VARCHAR2)
      RETURN VARCHAR2;

   PRAGMA RESTRICT_REFERENCES (date_speech, WNPS, RNPS, WNDS);

   FUNCTION count_sheet_speech (sht IN NUMBER)
      RETURN VARCHAR2;

   PRAGMA RESTRICT_REFERENCES (count_sheet_speech, WNPS, RNPS, WNDS);
END pkg_base_number_utils;
/

