create trigger ASSET_STATUS_TRG_AFTER_IU
  after insert or update
  on ASSET_STATUS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
    CASE
    WHEN INSERTING
        THEN
            TYPE_OPER := 0;
    WHEN UPDATING
        THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
                TYPE_OPER := 2;
            ELSE
                TYPE_OPER := 1;
            END IF;
    END CASE;
    
      INSERT INTO KONF.ASSET_STATUS_HISTORY (
                    ID_ASSET,
                    ID_ASSET_PARENT,
                    ID_INVENTORY_DOC,
                    ID_INVENTORY_EST_DOC,
                    ID_TRANSFER_DOC,
                    ID_STORAGE_DOC,
                    ORDER_NUM,
                    ASSET_NAME,
                    ID_MEASURE,
                    ASSET_AMOUNT,
                    ID_CURRENCY,
                    NUM_IN_INV,
                    NUM_IN_INV_EST,
                    ASSET_NOTE,
                    ID_GOODS_GROUP,
                    IS_ANOTHERWORK,
                    IS_EXPERT_EVALUATION,
                    IS_PERISHABLE,
                    IS_WORTH,
                    IS_NORECEPTION,
                    IS_SPECIFIC,
                    IS_REALTY,
                    IS_EQUIPMENT_MORE,
                    IS_TRANSPORT,
                    IS_WEAPONS,
                    IS_CULTURAL,
                    IS_EQUIPMENT,
                    IS_ALCOHOL,
                    IS_TOBACCO,
                    IS_DEFECT_HIDDEN,
                    IS_SPECIAL_STORAGE,
                    IS_MARKDOWN_MORE,
                    IS_MARKDOWN_REALIZ,
                    IS_ESTIMATED_VALUE,
                    ASSET_ADJECTIVES,
                    ASSET_COST,
                    ASSET_TOTAL_COST,
                    OTHER_ACTION_NAME,
                    OTHER_ACTION_BASES,
                    OTHER_ACTION_TERM,
                    ID_OTHER_ACTION_TERM_TYPE,
                    ASSET_AMOUNT2,
                    ID_MEASURE2,
                    ASSET_AMOUNT3,
                    ID_MEASURE3,
                    MEASURE_NAME,
                    MEASURE_NAME2,
                    MEASURE_NAME3,
                    ID_DESTR_METHOD,
                    DESTR_METHOD_NAME,
                    ID_ADDDOC,
                    IS_ACTUAL,
                    DATE_CHANGE,
                    TYPE_OPERATION,
                    ID_USER,
                    ID_CURR_ASSET_STATUS,
                    ID_PREV_ASSET_STATUS
                    )
           VALUES ( :NEW."ID_ASSET",
                    :NEW."ID_ASSET_PARENT",
                    :NEW."ID_INVENTORY_DOC",
                    :NEW."ID_INVENTORY_EST_DOC",
                    :NEW."ID_TRANSFER_DOC",
                    :NEW."ID_STORAGE_DOC",
                    :NEW."ORDER_NUM",
                    :NEW."ASSET_NAME",
                    :NEW."ID_MEASURE",
                    :NEW."ASSET_AMOUNT",
                    :NEW."ID_CURRENCY",
                    :NEW."NUM_IN_INV",
                    :NEW."NUM_IN_INV_EST",
                    :NEW."ASSET_NOTE",
                    :NEW."ID_GOODS_GROUP",
                    :NEW."IS_ANOTHERWORK",
                    :NEW."IS_EXPERT_EVALUATION",
                    :NEW."IS_PERISHABLE",
                    :NEW."IS_WORTH",
                    :NEW."IS_NORECEPTION",
                    :NEW."IS_SPECIFIC",
                    :NEW."IS_REALTY",
                    :NEW."IS_EQUIPMENT_MORE",
                    :NEW."IS_TRANSPORT",
                    :NEW."IS_WEAPONS",
                    :NEW."IS_CULTURAL",
                    :NEW."IS_EQUIPMENT",
                    :NEW."IS_ALCOHOL",
                    :NEW."IS_TOBACCO",
                    :NEW."IS_DEFECT_HIDDEN",
                    :NEW."IS_SPECIAL_STORAGE",
                    :NEW."IS_MARKDOWN_MORE",
                    :NEW."IS_MARKDOWN_REALIZ",
                    :NEW."IS_ESTIMATED_VALUE",
                    :NEW."ASSET_ADJECTIVES",
                    :NEW."ASSET_COST",
                    :NEW."ASSET_TOTAL_COST",
                    :NEW."OTHER_ACTION_NAME",
                    :NEW."OTHER_ACTION_BASES",
                    :NEW."OTHER_ACTION_TERM",
                    :NEW."ID_OTHER_ACTION_TERM_TYPE",
                    :NEW."ASSET_AMOUNT2",
                    :NEW."ID_MEASURE2",
                    :NEW."ASSET_AMOUNT3",
                    :NEW."ID_MEASURE3",
                    :NEW."MEASURE_NAME",
                    :NEW."MEASURE_NAME2",
                    :NEW."MEASURE_NAME3",
                    :NEW."ID_DESTR_METHOD",
                    :NEW."DESTR_METHOD_NAME",
                    :NEW."ID_ADDDOC",
                    :NEW."IS_ACTUAL",
                   SYSDATE,
                   TYPE_OPER,
                   1,
                   :NEW."ID_CURR_ASSET_STATUS",
                   :NEW."ID_PREV_ASSET_STATUS");

END;
/

