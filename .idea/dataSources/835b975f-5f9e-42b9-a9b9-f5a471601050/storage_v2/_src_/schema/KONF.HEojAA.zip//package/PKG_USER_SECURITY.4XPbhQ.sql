create PACKAGE      pkg_user_security
  IS
--
-- To modify this template, edit file PKGSPEC.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
   -- Enter package declarations as shown below


-- Имеет ли пользователь право редактировать ранее зарегистрированный/созданный входящий документ от внеш. организации
   FUNCTION IS_EDIT_PROP_EXT_DOC (p_ID_DOC IN NUMBER, p_ID_USER IN NUMBER) RETURN NUMBER;

-- Имеет ли пользователь право взять в работу (на себя) документ (кнопка "В работу" для документов и уведомлений)
   FUNCTION IS_ACQUIRE_DOC (p_ID_DOC IN NUMBER, p_ID_USER IN NUMBER) RETURN NUMBER;

END; -- Package spec
/

