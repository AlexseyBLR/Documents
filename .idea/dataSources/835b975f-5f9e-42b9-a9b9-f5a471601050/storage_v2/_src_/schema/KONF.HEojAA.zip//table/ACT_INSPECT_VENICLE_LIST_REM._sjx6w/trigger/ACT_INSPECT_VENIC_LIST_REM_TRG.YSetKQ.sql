create trigger ACT_INSPECT_VENIC_LIST_REM_TRG
  before insert
  on ACT_INSPECT_VENICLE_LIST_REM
  for each row
  BEGIN
  if :NEW."ID_LIST" is null then 
    :NEW."ID_LIST":="ACT_INSPECT_VENIC_LIST_REM_SEQ".nextval; 
  end if;
END;
/

