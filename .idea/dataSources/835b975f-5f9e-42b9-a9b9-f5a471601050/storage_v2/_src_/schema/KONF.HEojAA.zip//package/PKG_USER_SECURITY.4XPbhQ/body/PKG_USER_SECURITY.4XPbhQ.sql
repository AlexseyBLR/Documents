create PACKAGE BODY      pkg_user_security
IS
--
-- To modify this template, edit file PKGBODY.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package body
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
   -- Enter procedure, function bodies as shown below

   FUNCTION IS_EDIT_PROP_EXT_DOC (p_ID_DOC IN NUMBER, p_ID_USER IN NUMBER) RETURN NUMBER IS
     l_doc    konf.DOC%ROWTYPE;
     l_user   konf_security.USERS%ROWTYPE;
   BEGIN
     SELECT *
       INTO l_doc
       FROM konf.DOC d
      WHERE d.id_doc = p_ID_DOC;

     SELECT *
       INTO l_user
       FROM konf_security.USERS u
      WHERE u.ID_USER = p_ID_USER;

     if l_doc.ID_DOC_STATUS = 3 and
        l_doc.IS_EXT_AUTHOR = 1 and
        l_doc.ID_DEST_ORG = l_user.ID_ORGANIZATION and
        l_doc.ID_DEST_USER = l_user.ID_USER and
        l_doc.ID_USER_ACQUIRED = l_user.ID_USER then
       RETURN 1;
     ELSE
       RETURN 0;
     END IF;
   EXCEPTION
     WHEN OTHERS THEN
       RETURN 0;
   END;

   FUNCTION IS_ACQUIRE_DOC (p_ID_DOC IN NUMBER, p_ID_USER IN NUMBER) RETURN NUMBER IS
     l_count  NUMBER;
   BEGIN
/*
7       Готов для согласования
10      Готов для подписания
13      Готов для регистрации
6       Требуется доработка
*/
     SELECT COUNT(*)
       INTO l_count
       FROM konf_security.v_user_roles r,
            konf.doc d,
            nri.doc_status s
      WHERE 1 = 1
        AND d.id_doc = p_ID_DOC
        AND d.id_doc_status IN (7, 10, 13, 6)
        AND r.ID_USER = p_ID_USER
        AND s.id_doc_status = d.id_doc_status
        AND s.id_role_process = r.id_role;
     if l_count > 0 then
       RETURN 1;
     ELSE
       RETURN 0;
     END IF;
   EXCEPTION
     WHEN OTHERS THEN
       RETURN 0;
   END;

   -- Enter further code below as specified in the Package spec.
END;
/

