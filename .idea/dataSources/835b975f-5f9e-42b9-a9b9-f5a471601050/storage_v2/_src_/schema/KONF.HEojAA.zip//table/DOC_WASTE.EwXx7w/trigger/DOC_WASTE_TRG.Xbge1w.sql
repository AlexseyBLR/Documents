create trigger DOC_WASTE_TRG
  before insert
  on DOC_WASTE
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_WASTE_SEQ.NEXTVAL;
  END IF; 
END;
/

