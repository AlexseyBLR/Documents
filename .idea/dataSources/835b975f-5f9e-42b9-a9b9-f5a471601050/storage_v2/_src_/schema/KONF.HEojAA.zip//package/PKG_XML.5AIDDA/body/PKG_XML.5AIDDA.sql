create PACKAGE BODY      PKG_XML
IS

-- собирает XML по указанной таблице IN_TAB_NAME 
-- поле добавляются, если для него в NRI.XML_TUNING указано IS_INSERT_XML = 1 
-- возвращает XML если XML успешно сформирован, NULL - если произошла ошибка
FUNCTION COLLECT_XML_ONE_TABLE(IN_TAB_NAME IN  VARCHAR2, IN_ID_DOC IN NUMBER, IN_ORDER_BY IN VARCHAR2) RETURN XMLTYPE
IS
    
   SELECTED_XMLTABLE TYPE_XMLTABLE;
   ONE_XMLTABLE XMLTYPE;
   
   CURSOR TAB_COLUMNS
   IS
    SELECT 
           COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NVL(XML_TAG, CONVERT_STR_TO_TAG(COLUMN_NAME)) TAG, REF_TABLE, REF_COLUMN, VAL_COLUMN
        FROM NRI.XML_TUNING
        WHERE 
            TABLE_NAME = IN_TAB_NAME
            AND IS_INSERT_XML = 1
        ORDER BY NUM_COLUMN;
        
    SQL_STR VARCHAR2(32000) := 'SELECT XMLELEMENT("row" ';      
    TAB_NAME_TAG VARCHAR2(100); 
BEGIN
    
    TAB_NAME_TAG := CONVERT_STR_TO_TAG(IN_TAB_NAME);

    FOR ITEM IN TAB_COLUMNS LOOP
        SQL_STR:= SQL_STR || ', XMLELEMENT( "' ||ITEM.TAG || '", ' || ' XMLAttributes( '''|| ITEM.DATA_TYPE || ''' AS "type", ''' || ITEM.DATA_LENGTH|| ''' AS "length"'||'), ' || 
            ' DECODE ('''|| ITEM.REF_TABLE || ''' , NULL,' ||
            ' CASE ''' || ITEM.DATA_TYPE || ''' WHEN ''DATE'' THEN TO_CHAR(' || ITEM.COLUMN_NAME || ', ''' ||KONF.PKG_XML.FOMAT_DATE_STR || ''') ELSE TO_CHAR(' || ITEM.COLUMN_NAME|| 
            ') END, KONF.PKG_XML.GET_FK_VAL(''' || ITEM.REF_TABLE || ''','''|| ITEM.REF_COLUMN||''','''|| ITEM.VAL_COLUMN||''', '||ITEM.COLUMN_NAME||')))';      
    END LOOP;
    SQL_STR:= SQL_STR || ') FROM '|| IN_TAB_NAME ||' E WHERE E.ID_doc = :1 ';
    IF IN_ORDER_BY IS NOT NULL THEN
        SQL_STR:= SQL_STR || ' ORDER BY ' ||IN_ORDER_BY;
    END IF;        
    --DBMS_OUTPUT.PUT_LINE(SQL_STR);
    --в SELECTED_XMLTABLE будет столько элементов, сколько строк было в IN_TAB_NAME
    EXECUTE IMMEDIATE SQL_STR BULK COLLECT INTO SELECTED_XMLTABLE USING IN_ID_DOC; 

    EXECUTE IMMEDIATE 'SELECT XMLELEMENT("' || TAB_NAME_TAG || '") FROM DUAL' INTO ONE_XMLTABLE;
        
    IF SELECTED_XMLTABLE.COUNT = 0 THEN RETURN NULL; END IF;
    
    FOR I IN SELECTED_XMLTABLE.FIRST..SELECTED_XMLTABLE.LAST
    LOOP
        SELECT  APPENDCHILDXML(ONE_XMLTABLE, TAB_NAME_TAG, SELECTED_XMLTABLE(I) ) 
            INTO ONE_XMLTABLE
        FROM DUAL;                   
    END LOOP;

    RETURN ONE_XMLTABLE;
    
--EXCEPTION
--    WHEN OTHERS THEN
--        RETURN NULL;          
END;

FUNCTION COLLECT_XML_ONE_TABLE_F(IN_TAB_NAME IN  VARCHAR2, IN_SEL_F IN VARCHAR2, IN_SEL_F_VAL IN NUMBER, IN_ORDER_BY IN VARCHAR2 DEFAULT '') RETURN XMLTYPE
IS
    
   SELECTED_XMLTABLE TYPE_XMLTABLE;
   ONE_XMLTABLE XMLTYPE;
   
   CURSOR TAB_COLUMNS
   IS
    SELECT 
           COLUMN_NAME, DATA_TYPE, DATA_LENGTH, NVL(XML_TAG, CONVERT_STR_TO_TAG(COLUMN_NAME)) TAG, REF_TABLE, REF_COLUMN, VAL_COLUMN
        FROM NRI.XML_TUNING
        WHERE 
            TABLE_NAME = IN_TAB_NAME
            AND IS_INSERT_XML = 1
        ORDER BY NUM_COLUMN;
        
    SQL_STR VARCHAR2(32000) := 'SELECT XMLELEMENT("row" ';      
    TAB_NAME_TAG VARCHAR2(100); 
BEGIN
    
    TAB_NAME_TAG := CONVERT_STR_TO_TAG(IN_TAB_NAME);

    FOR ITEM IN TAB_COLUMNS LOOP
        SQL_STR:= SQL_STR || ', XMLELEMENT( "' ||ITEM.TAG || '", ' || ' XMLAttributes( '''|| ITEM.DATA_TYPE || ''' AS "type", ''' || ITEM.DATA_LENGTH|| ''' AS "length"'||'), ' || 
            ' DECODE ('''|| ITEM.REF_TABLE || ''' , NULL,' ||
            ' CASE ''' || ITEM.DATA_TYPE || ''' WHEN ''DATE'' THEN TO_CHAR(' || ITEM.COLUMN_NAME || ', ''' ||KONF.PKG_XML.FOMAT_DATE_STR || ''') ELSE TO_CHAR(' || ITEM.COLUMN_NAME|| 
            ') END, KONF.PKG_XML.GET_FK_VAL(''' || ITEM.REF_TABLE || ''','''|| ITEM.REF_COLUMN||''','''|| ITEM.VAL_COLUMN||''', '||ITEM.COLUMN_NAME||')))';      
    END LOOP;
    SQL_STR:= SQL_STR || ') FROM '|| IN_TAB_NAME ||' E WHERE '||IN_SEL_F||' = :1 ';
    IF IN_ORDER_BY IS NOT NULL THEN
        SQL_STR:= SQL_STR || ' ORDER BY ' ||IN_ORDER_BY;
    END IF;        
    --DBMS_OUTPUT.PUT_LINE(SQL_STR);
    --в SELECTED_XMLTABLE будет столько элементов, сколько строк было в IN_TAB_NAME
    EXECUTE IMMEDIATE SQL_STR BULK COLLECT INTO SELECTED_XMLTABLE USING IN_SEL_F_VAL; 

    EXECUTE IMMEDIATE 'SELECT XMLELEMENT("' || TAB_NAME_TAG || '") FROM DUAL' INTO ONE_XMLTABLE;
        
    IF SELECTED_XMLTABLE.COUNT = 0 THEN RETURN NULL; END IF;
    
    FOR I IN SELECTED_XMLTABLE.FIRST..SELECTED_XMLTABLE.LAST
    LOOP
        SELECT  APPENDCHILDXML(ONE_XMLTABLE, TAB_NAME_TAG, SELECTED_XMLTABLE(I) ) 
            INTO ONE_XMLTABLE
        FROM DUAL;                   
    END LOOP;

    RETURN ONE_XMLTABLE;
    
--EXCEPTION
--    WHEN OTHERS THEN
--        RETURN NULL;          
END;

-- собирает  один XML по всем таблицам, указанным в настроечной таблице NRI.XML_TUNING_DT
-- плюс информация по блоку для подписывающих 
-- возвращает XML если XML успешно сформирован, NULL - если произошла ошибка
FUNCTION COLLECT_DOC_XML(IN_ID_DOC IN NUMBER) RETURN XMLTYPE
IS
    SELECTED_XMLTABLE TYPE_XMLTABLE; 
    ONE_XMLTABLE XMLTYPE;
    
    IN_ID_DOC_TYPE NUMBER;
    
    CURSOR ALL_TABLES
    IS
        SELECT *
        FROM (SELECT DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                FROM NRI.XML_TUNING_DT DT
               WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
              UNION
              SELECT DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                FROM NRI.XML_TUNING_DT DT
               WHERE (    DT.ID_TYPE_DOC IS NULL
                      AND NOT EXISTS
                             (SELECT DT.NUM_TABLE, DT.NAME_TABLE
                                FROM NRI.XML_TUNING_DT DT
                               WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE)))
        ORDER BY NUM_TABLE;
/*  CURSOR ALL_TABLES
    IS
        SELECT DT.NAME_TABLE 
        FROM NRI.XML_TUNING_DT DT
        WHERE DT.ID_TYPE_DOC = IN_TYPE_DOC
            AND EXISTS(SELECT * FROM NRI.XML_TUNING WHERE NAME_TABLE = DT.NAME_TABLE AND IS_INSERT_XML = 1)
        ORDER BY DT.NUM_TABLE;*/
    CNT NUMBER;   
         
BEGIN
    SELECT ID_DOC_TYPE INTO IN_ID_DOC_TYPE FROM DOC  WHERE ID_DOC = IN_ID_DOC;
    
    SELECTED_XMLTABLE := TYPE_XMLTABLE();
    
    FOR ITEM IN ALL_TABLES LOOP
        SELECTED_XMLTABLE.EXTEND;
        SELECTED_XMLTABLE(SELECTED_XMLTABLE.LAST) := COLLECT_XML_ONE_TABLE(ITEM.NAME_TABLE, IN_ID_DOC, ITEM.ORDER_BY);    
    END LOOP;
    
    SELECT COUNT(ID_DOC_TYPE) INTO CNT FROM DOC  WHERE ID_DOC = IN_ID_DOC;
    IF CNT = 0 THEN
        RETURN NULL;
    END IF;
             
    
    EXECUTE IMMEDIATE 'SELECT XMLELEMENT("document", XMLAttributes('|| IN_ID_DOC || ' AS "ID_DOC", '|| IN_ID_DOC_TYPE || ' AS "ID_DOC_TYPE" '||')) FROM DUAL' INTO ONE_XMLTABLE;
    
    FOR I IN SELECTED_XMLTABLE.FIRST..SELECTED_XMLTABLE.LAST
    LOOP
        SELECT  APPENDCHILDXML(ONE_XMLTABLE, 'document', SELECTED_XMLTABLE(I) ) 
            INTO ONE_XMLTABLE
        FROM DUAL;   
        --DBMS_OUTPUT.PUT_LINE(I);                
    END LOOP;

    --select XMLConcat(ONE_XMLTABLE, COLLECT_XML_PERSONS(IN_ID_DOC)) into  ONE_XMLTABLE from dual; 
    SELECT  APPENDCHILDXML(ONE_XMLTABLE, 'document', COLLECT_XML_PERSONS(IN_ID_DOC) ) 
            INTO ONE_XMLTABLE
        FROM DUAL; 
    --DBMS_OUTPUT.PUT_LINE('COLLECT_XML_PERSONS');    
    RETURN ONE_XMLTABLE;
    
--    EXCEPTION
--    WHEN OTHERS THEN
--        RETURN NULL; 
   
END;

-- записывает полученный XML в таблицу DOC, возвращает 1 если XML успешно сформирован, 0 - если произошла ошибка 
FUNCTION UPDATE_DOC_XML(IN_ID_DOC IN NUMBER, IN_XML IN XMLTYPE) RETURN NUMBER
IS
BEGIN
    --DELETE FROM TEST;
    --INSERT INTO TEST VALUES (IN_XML);
    
    UPDATE DOC SET DOC_XML = IN_XML.GETCLOBVAL() WHERE ID_DOC = IN_ID_DOC;
    
    RETURN 1;
    
--    EXCEPTION
--    WHEN OTHERS THEN
--        RETURN 0;
END;

-- создает XML и записывает его в DOC.DOC_XML, возвращает 1 если XML успешно сформирован и записан, 0 - если произошла ошибка  
FUNCTION CREATE_XML_DOC(IN_ID_DOC IN NUMBER) RETURN NUMBER
IS
    REZ_XML XMLTYPE;
    REZ NUMBER;
BEGIN
    REZ_XML := COLLECT_DOC_XML(IN_ID_DOC);
    IF REZ_XML IS NOT NULL THEN 
        REZ:= UPDATE_DOC_XML(IN_ID_DOC,REZ_XML);
    END IF;
    
    RETURN REZ;
    
--    EXCEPTION
--    WHEN OTHERS THEN
--        RETURN 0;
END;

-- преобразовывает строки типа ID_DOC_BANK_DETAIL в idDocBankDetail
FUNCTION CONVERT_STR_TO_TAG (IN_STR IN VARCHAR2)
  RETURN VARCHAR2
IS
  OUT_STR   VARCHAR2 (100);
BEGIN
      SELECT LISTAGG (DECODE (ROWNUM,
                              1, LOWER (REGEXP_SUBSTR (str, '[^_]+', 1, LEVEL)),
                              INITCAP (REGEXP_SUBSTR (str, '[^_]+', 1, LEVEL))),
                      '')
             WITHIN GROUP (ORDER BY ROWNUM) str
                
        INTO OUT_STR
        FROM (SELECT IN_STR str FROM DUAL) t
  CONNECT BY INSTR (str,
                    '_',
                    1,
                    LEVEL - 1) > 0;

  RETURN OUT_STR;
--EXCEPTION
--  WHEN OTHERS
--  THEN
--     RETURN NULL;
END;

-- для указанного элемента IN_ELEMENT устанавливает атрибуты
PROCEDURE SET_ALL_ATTRIBUTES(
    IN_ELEMENT IN DBMS_XMLDOM.DOMElement,
    IN_ATTR_VALUE          IN VARCHAR2, 
    IN_ATTR_NUM            IN NUMBER,
    IN_MIN_VALUE           IN VARCHAR2,
    IN_MAX_VALUE           IN VARCHAR2,
    IN_MIN_LENGTH          IN NUMBER,
    IN_MAX_LENGTH          IN NUMBER,                      
    IN_IS_VISIBLE          IN NUMBER,
    IN_IS_EDITABLE         IN NUMBER,    
    IN_IS_REQUIRED         IN NUMBER,
    IN_ATTR_FOOTER         IN VARCHAR2,
    IN_ATTR_HEADER         IN VARCHAR2,
    IN_ATTR_PREFIX         IN VARCHAR2,
    IN_ATTR_POSTFIX        IN VARCHAR2,
    IN_MASK                IN VARCHAR2
)
IS
BEGIN
    DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'value', IN_ATTR_NUM);      
    IF IN_ATTR_NUM IS NOT NULL THEN     DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'num', IN_ATTR_NUM); END IF;
    IF IN_ATTR_VALUE IS NOT NULL THEN   DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'value', IN_ATTR_VALUE); END IF;
    IF IN_MIN_VALUE IS NOT NULL THEN    DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'minPersons', IN_MIN_VALUE); END IF;
    IF IN_MAX_VALUE IS NOT NULL THEN    DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'maxPersons', IN_MAX_VALUE); END IF;
    IF IN_MIN_LENGTH IS NOT NULL THEN   DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'minLength', IN_MIN_LENGTH); END IF;
    IF IN_MAX_LENGTH IS NOT NULL THEN   DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'maxLength', IN_MAX_LENGTH); END IF;
    IF IN_IS_VISIBLE IS NOT NULL THEN   DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'visible', IN_IS_VISIBLE); END IF;
    IF IN_IS_EDITABLE IS NOT NULL THEN  DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'ediable', IN_IS_EDITABLE); END IF;
    IF IN_IS_REQUIRED IS NOT NULL THEN  DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'required', IN_IS_REQUIRED); END IF;
    IF IN_ATTR_FOOTER IS NOT NULL THEN  DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'footer', IN_ATTR_FOOTER); END IF;
    IF IN_ATTR_HEADER IS NOT NULL THEN  DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'header', IN_ATTR_HEADER); END IF;
    IF IN_ATTR_PREFIX IS NOT NULL THEN  DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'prefix', IN_ATTR_PREFIX); END IF;
    IF IN_ATTR_POSTFIX IS NOT NULL THEN DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'postfix', IN_ATTR_POSTFIX); END IF;
    IF IN_MASK IS NOT NULL THEN DBMS_XMLDOM.setAttribute(IN_ELEMENT, 'mask', IN_MASK); END IF;
END;


-- выбираем значение Элемента 
FUNCTION GET_ATTR_VALUE(IN_ID_DOC IN NUMBER, IN_TABLE_NAME IN VARCHAR2, IN_COL_NAME IN VARCHAR2,IN_PERSON_GROUP_NUM IN NUMBER, IN_PERSON_NUM IN NUMBER, IN_ATTR_TYPE IN VARCHAR2) RETURN VARCHAR2
IS
    STR VARCHAR2(1000 CHAR);
    REZ VARCHAR2(1000 CHAR);
BEGIN
    STR := 'SELECT CASE UPPER('''|| IN_ATTR_TYPE || ''') WHEN ''DATE'' THEN TO_CHAR(' || IN_COL_NAME || ',''DD.MM.YYYY'') ELSE TO_CHAR('|| IN_COL_NAME || ') END FROM ' || IN_TABLE_NAME || 
            ' WHERE ID_DOC = ' || IN_ID_DOC || ' AND PERSON_GROUP_NUM = '|| IN_PERSON_GROUP_NUM ||' AND ORDER_NUM = ' || IN_PERSON_NUM;
    EXECUTE IMMEDIATE STR INTO REZ;
    
    RETURN REZ;
EXCEPTION
    WHEN OTHERS THEN
        RETURN '';     
END;

FUNCTION COLLECT_XML_PERSONS (IN_ID_DOC IN NUMBER) RETURN XMLTYPE
IS
    IN_ID_DOC_TYPE      NUMBER; 
    IN_ID_ATTR_START    NUMBER;-- точка отсчета построения основного дерева 
    IN_ID_DOC_TEMPL     NUMBER;
    
    CURSOR C_PERSON_GROUPS IS
        -- выбираем нужные docPersonGroups
        SELECT 
            LEVEL,
            '/view'||regexp_replace(SYS_CONNECT_BY_PATH(prior ATTR_XMLTAG,'/'), '^/', '') as parent_tag,  
            NVL(prior ATTR_XMLTAG, 'view') PT,
            DTA.ATTR_NUM, 
            nvl(DTA.ATTR_CODE, DTA.ATTR_XMLTAG) ATTR_CODE,--DTA.ATTR_CODE,
            DTA.ATTR_VALUE,    
            DTA.MIN_VALUE,
            DTA.MAX_VALUE,
            DTA.MIN_LENGTH,
            DTA.MAX_LENGTH,
            DTA.IS_VISIBLE,
            DTA.IS_EDITABLE, 
            DTA.IS_REQUIRED, 
            DTA.ATTR_FOOTER, 
            DTA.ATTR_HEADER, 
            DTA.ATTR_PREFIX, 
            DTA.ATTR_POSTFIX,
            DTA.MASK,
            DTA.ATTR_XMLTAG,
            DTA.ID_DOC_TEMPL_ATTR,
            DTA.TABLE_REF        
                        
        FROM  (select * 
                    from KONF.DOC_TEMPL_PERS dtp
                    where 
                        DTP.ID_DOC_TEMPL = IN_ID_DOC_TEMPL) DTA 
           WHERE LEVEL <= 3
           AND DECODE(LEVEL, 3, CONNECT_BY_ISLEAF, 1) = 1 
        START WITH ID_DOC_TEMPL_ATTR/*ATTR_NUM*/ = IN_ID_ATTR_START--10--DOC_PERSON_SIGN_ATTR_NUM
        CONNECT BY PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT --ATTR_NUM = ATTR_NUM_PARENT
        ORDER BY ATTR_NUM;
        
    -- по указанному docPersonGroups определяем сколько будет docPersons      
    CURSOR C_PERSONS(IN_ATTR_VALUE VARCHAR2) IS
        SELECT rn, ID_DOC_TEMPL_ATTR, qq.*
          FROM (  SELECT ROWNUM rn, A.ID_DOC_TEMPL_ATTR ID_DOC_TEMPL_ATTR
                      FROM DUAL,
                           (SELECT CUR_DTA.ID_DOC_TEMPL_ATTR_parent ID_DOC_TEMPL_ATTR,
               DOC_PERSON_GROUPS.min_persons MP
          FROM KONF.DOC_TEMPL_PERS CUR_DTA
               INNER JOIN KONF.DOC_PERSON_GROUPS
                  ON     (ATTR_VALUE = PERSON_GROUP_NAME)
                     AND (DOC_PERSON_GROUPS.ID_DOC = /*40*/IN_ID_DOC)                  
        WHERE DOC_PERSON_GROUPS.ORDER_NUM = /*1*/ IN_ATTR_VALUE
            AND CUR_DTA.ID_DOC_TEMPL = /*147*/ IN_ID_DOC_TEMPL  ) A
                     WHERE LEVEL <= A.MP
                CONNECT BY ROWNUM = LEVEL)
               FULL JOIN
               (  SELECT DOC_PERSONS.ORDER_NUM PERSON_NUM,
                         DOC_PERSON_GROUPS.ORDER_NUM--,
                    --     CUR_DTA.ID_DOC_TEMPL_ATTR_parent ID_DOC_TEMPL_ATTR,
                        -- DOC_PERSON_GROUPS.min_persons
                    FROM KONF.DOC_TEMPL_PERS CUR_DTA
                         INNER JOIN KONF.DOC_PERSON_GROUPS
                            ON (ATTR_VALUE = PERSON_GROUP_NAME)
                         INNER JOIN KONF.DOC_PERSONS
                            ON     (DOC_PERSON_GROUPS.ID_DOC = DOC_PERSONS.ID_DOC)
                               AND (DOC_PERSON_GROUPS.ORDER_NUM =
                                       DOC_PERSONS.PERSON_GROUP_NUM)
                   WHERE     DOC_PERSONS.ID_DOC = /*40 */IN_ID_DOC
                         AND DOC_PERSON_GROUPS.ORDER_NUM = /*1*/IN_ATTR_VALUE
                         AND CUR_DTA.ID_DOC_TEMPL = /*147*/IN_ID_DOC_TEMPL
                ORDER BY PERSON_NUM) qq
                  ON rn = qq.PERSON_NUM;
/*    SELECT
            PERSON_NUM,
            DOC_PERSON_GROUPS.PERSON_GROUP_NUM,
            CUR_DTA.ID_DOC_TEMPL_ATTR_parent ID_DOC_TEMPL_ATTR  
        FROM KONF.DOC_TEMPL_PERS CUR_DTA
--           INNER JOIN KONF.DOC_TEMPL
--              ON (CUR_DTA.ID_DOC_TEMPL = DOC_TEMPL.ID_DOC_TEMPL AND ID_DOC_TYPE =  IN_ID_DOC_TYPE)
           INNER JOIN KONF.DOC_PERSON_GROUPS ON (ATTR_VALUE = PERSON_GROUP_NAME)
           INNER JOIN KONF.DOC_PERSONS
              ON     (DOC_PERSON_GROUPS.ID_DOC = DOC_PERSONS.ID_DOC)
                 AND (DOC_PERSON_GROUPS.PERSON_GROUP_NUM =
                         DOC_PERSONS.PERSON_GROUP_NUM)
            WHERE DOC_PERSONS.ID_DOC = IN_ID_DOC
            AND DOC_PERSON_GROUPS.PERSON_GROUP_NUM = IN_ATTR_VALUE  
            AND CUR_DTA.ID_DOC_TEMPL = IN_ID_DOC_TEMPL
            ORDER BY PERSON_NUM;*/     
          
    CURSOR C_PERSON_TYPE(NUM_POINT NUMBER) IS
        -- достаем информацию по указанному человеку     
        select LEVEL, A.* from (SELECT --LEVEL,
           '/view' || REGEXP_REPLACE (SYS_CONNECT_BY_PATH (PRIOR ATTR_XMLTAG, '/'), '^/','') AS parent_tag,
           NVL(prior ATTR_XMLTAG, 'view') PT,
           DTA.ATTR_NUM,
           DTA.ID_DOC_TEMPL_ATTR,
           DTA.ID_DOC_TEMPL_ATTR_PARENT,--DTA.ATTR_NUM_PARENT,
           nvl(DTA.ATTR_CODE, DTA.ATTR_XMLTAG) ATTR_CODE,
           DTA.ATTR_VALUE,
           DTA.MIN_VALUE,
           DTA.MAX_VALUE,
           DTA.MIN_LENGTH,
           DTA.MAX_LENGTH,
           DTA.IS_VISIBLE,
           DTA.IS_EDITABLE,
           DTA.IS_REQUIRED,
           DTA.ATTR_FOOTER,
           DTA.ATTR_HEADER,
           DTA.ATTR_PREFIX,
           DTA.ATTR_POSTFIX,
           DTA.TABLE_REF,
           DTA.COLUMN_REF,
           DTA.ATTR_TYPE,
           MASK,
           DTA.ATTR_XMLTAG,
           CONNECT_BY_ISLEAF IS_LEAF
      FROM (SELECT DTA.*
              FROM KONF.DOC_TEMPL_PERS DTA, KONF.DOC_TEMPL DT
             WHERE DT.ID_DOC_TYPE = IN_ID_DOC_TYPE AND DT.ID_DOC_TEMPL = DTA.ID_DOC_TEMPL)
           DTA
        START WITH ID_DOC_TEMPL_ATTR = NUM_POINT
        CONNECT BY PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT --ATTR_NUM = ATTR_NUM_PARENT
        ) a
        WHERE DECODE(LEVEL, 1, CONNECT_BY_ISLEAF, 0) = 0
           START WITH ID_DOC_TEMPL_ATTR_PARENT = NUM_POINT
        CONNECT BY PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT --ATTR_NUM = ATTR_NUM_PARENT
          ORDER BY ATTR_NUM;     
          
        
    doc            DBMS_XMLDOM.DOMDocument; -- объект документа
    rootElement    DBMS_XMLDOM.DOMElement; -- корневой элемент 
    el DBMS_XMLDOM.DOMNodeList; 
    --paramsElement1 DBMS_XMLDOM.DOMElement; -- элемент 1 уровня 
    --paramsElement2 DBMS_XMLDOM.DOMElement; -- элемент 2 уровня
    docPersonsElement DBMS_XMLDOM.DOMElement;
    docPersonsDetailElement DBMS_XMLDOM.DOMElement;
    textNode dbms_xmldom.domtext; -- значение узла
        
    node           DBMS_XMLDOM.DOMNode; -- узел
    c              CLOB;
    
    ATTR_VALUE_TEXT VARCHAR2(1000 CHAR);
    xmlOutput     XmlType;
    
    PERS_GROUP_NUM NUMBER;
BEGIN
    SELECT ID_DOC_TYPE INTO IN_ID_DOC_TYPE FROM KONF.DOC WHERE ID_DOC = IN_ID_DOC;  
    SELECT ID_DOC_TEMPL INTO IN_ID_DOC_TEMPL FROM KONF.DOC_TEMPL WHERE ID_DOC_TYPE = IN_ID_DOC_TYPE;    
    SELECT ID_DOC_TEMPL_ATTR INTO IN_ID_ATTR_START FROM KONF.DOC_TEMPL_PERS WHERE ID_DOC_TEMPL = IN_ID_DOC_TEMPL AND ATTR_XMLTAG = 'docSign';

    
    doc := dbms_xmldom.createDocument('', null, null);
    rootElement := DBMS_XMLDOM.createElement(doc, 'view');
    node        := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(doc),
                                         DBMS_XMLDOM.makeNode(rootElement));
          
    FOR INF_PERSON_GROUPS IN C_PERSON_GROUPS LOOP
        -- строим первый (docPersonSign) и второй (docPersonGroups) уровни   
        docPersonsElement := DBMS_XMLDOM.createElement(doc, INF_PERSON_GROUPS.ATTR_CODE);
        el := DBMS_XMLDOM.getElementsByTagName(doc, INF_PERSON_GROUPS.pt);
               
        node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.ITEM(EL,DBMS_XMLDOM.getLength(EL)-1)/*DBMS_XMLDOM.makeNode(rootElement)*/,
                                  DBMS_XMLDOM.makeNode(docPersonsElement));
        SET_ALL_ATTRIBUTES(docPersonsElement,    
            INF_PERSON_GROUPS.ATTR_VALUE,  
            INF_PERSON_GROUPS.ATTR_NUM,    
            INF_PERSON_GROUPS.MIN_VALUE,   
            INF_PERSON_GROUPS.MAX_VALUE,   
            INF_PERSON_GROUPS.MIN_LENGTH,  
            INF_PERSON_GROUPS.MAX_LENGTH,  
            INF_PERSON_GROUPS.IS_VISIBLE,  
            INF_PERSON_GROUPS.IS_EDITABLE, 
            INF_PERSON_GROUPS.IS_REQUIRED, 
            INF_PERSON_GROUPS.ATTR_FOOTER, 
            INF_PERSON_GROUPS.ATTR_HEADER, 
            INF_PERSON_GROUPS.ATTR_PREFIX, 
            INF_PERSON_GROUPS.ATTR_POSTFIX,
            INF_PERSON_GROUPS.MASK 
            );                            
        IF INF_PERSON_GROUPS.LEVEL = 2 THEN
            -- информация по отдельным людям
            SELECT ATTR_VALUE INTO PERS_GROUP_NUM 
                FROM KONF.DOC_TEMPL_PERS DTP
                WHERE ID_DOC_TEMPL = IN_ID_DOC_TEMPL
                    AND ATTR_CODE = 'personGroupNum'
                    AND ID_DOC_TEMPL_ATTR_PARENT = INF_PERSON_GROUPS.ID_DOC_TEMPL_ATTR; 
            FOR INF_COUNT_PERSON IN C_PERSONS(PERS_GROUP_NUM/*INF_PERSON_GROUPS.ID_DOC_TEMPL_ATTR*/)  LOOP
                -- цикл строит нужное количество docPersons для родительского docPersonGroups 
                FOR INF_PERSON IN C_PERSON_TYPE(INF_COUNT_PERSON.ID_DOC_TEMPL_ATTR) LOOP
                    -- создаем docPersons и его элементы (типа Job, Fio и т.д.)  
                    el := DBMS_XMLDOM.getElementsByTagName(doc, INF_PERSON.pt);
                    docPersonsElement := DBMS_XMLDOM.createElement(doc, INF_PERSON.ATTR_CODE);
                    node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.ITEM(EL,DBMS_XMLDOM.getLength(EL)-1),
                                          DBMS_XMLDOM.makeNode(docPersonsElement));
                    SET_ALL_ATTRIBUTES(docPersonsElement,    
                                INF_PERSON.ATTR_VALUE,  
                                INF_PERSON.ATTR_NUM,    
                                INF_PERSON.MIN_VALUE,   
                                INF_PERSON.MAX_VALUE,   
                                INF_PERSON.MIN_LENGTH,  
                                INF_PERSON.MAX_LENGTH,  
                                INF_PERSON.IS_VISIBLE,  
                                INF_PERSON.IS_EDITABLE, 
                                INF_PERSON.IS_REQUIRED, 
                                INF_PERSON.ATTR_FOOTER, 
                                INF_PERSON.ATTR_HEADER, 
                                INF_PERSON.ATTR_PREFIX, 
                                INF_PERSON.ATTR_POSTFIX,
                                INF_PERSON.MASK 
                                );      
                    IF (INF_PERSON.IS_LEAF = 1) THEN
                        -- узел элемента (типа Job, Fio и т.д.), его атрибуты и значение, которое достается функцией GET_ATTR_VALUE
                        ATTR_VALUE_TEXT := GET_ATTR_VALUE(IN_ID_DOC, 
                                                          INF_PERSON_GROUPS.TABLE_REF, 
                                                          INF_PERSON.COLUMN_REF, 
                                                          INF_COUNT_PERSON.ORDER_NUM, 
                                                          INF_COUNT_PERSON.PERSON_NUM, 
                                                          INF_PERSON.ATTR_TYPE);
                        textNode:= DBMS_XMLDOM.createTextNode(doc, ATTR_VALUE_TEXT);
                        node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(docPersonsElement),
                                          DBMS_XMLDOM.makeNode(textNode));
                    END IF;                               
                END LOOP;                        
            END LOOP;
        END IF;               
    END LOOP;
    
    dbms_lob.createtemporary(c, true, dbms_lob.session);
    dbms_xmldom.writeToClob(doc, c);
    xmlOutput := SYS.XMLTYPE(c);  
    DBMS_LOB.FreeTemporary(c);    
    --dbms_output.put_line(xmlOutput.getClobVal);
    RETURN xmlOutput;

END;
/*
-- СТАРАЯ ВЕРСИЯ, КОГДА ШАБЛОН ДЛЯ ПОДПИСАНТОВ БЫЛ В DOC_TEMPL_ATTR
FUNCTION COLLECT_XML_PERSONS (IN_ID_DOC IN NUMBER) RETURN XMLTYPE
IS
    IN_ID_DOC_TYPE NUMBER;
    DOC_PERSON_SIGN_ATTR_NUM NUMBER := 90; -- точка отсчета построения основного дерева 
    
    CURSOR C_PERSON_GROUPS IS
        -- выбираем нужные docPersonGroups
        SELECT 
            LEVEL,
            '/view'||regexp_replace(SYS_CONNECT_BY_PATH(prior attr_code,'/'), '^/', '') as parent_tag,  
            DTA.ATTR_NUM, 
            DTA.ATTR_CODE,
            DTA.ATTR_VALUE,    
            DTA.MIN_VALUE,
            DTA.MAX_VALUE,
            DTA.MIN_LENGTH,
            DTA.MAX_LENGTH,
            DTA.IS_VISIBLE,
            DTA.IS_EDITABLE, 
            DTA.IS_REQUIRED, 
            DTA.ATTR_FOOTER, 
            DTA.ATTR_HEADER, 
            DTA.ATTR_PREFIX, 
            DTA.ATTR_POSTFIX,
            DTA.MASK
                        
        FROM  (SELECT DTA.* FROM DOC_TEMPL_ATTR DTA, DOC_TEMPL DT WHERE DT.ID_DOC_TYPE = IN_ID_DOC_TYPE AND  DT.ID_DOC_TEMPL = DTA.ID_DOC_TEMPL) DTA 
           WHERE LEVEL <= 2
        START WITH ATTR_NUM = DOC_PERSON_SIGN_ATTR_NUM
        CONNECT BY PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT --ATTR_NUM = ATTR_NUM_PARENT
        ORDER BY ATTR_NUM;
        
    CURSOR C_PERSONS(IN_ATTR_VALUE VARCHAR2) IS
        -- по указанному docPersonGroups определяем сколько будет docPersons 
        SELECT
            PERSON_NUM,
            DOC_PERSON_GROUPS.PERSON_GROUP_NUM   
        FROM DOC_TEMPL_ATTR CUR_DTA
           INNER JOIN DOC_TEMPL
              ON (CUR_DTA.ID_DOC_TEMPL = DOC_TEMPL.ID_DOC_TEMPL AND ID_DOC_TYPE =  IN_ID_DOC_TYPE)
           INNER JOIN DOC_PERSON_GROUPS ON (ATTR_VALUE = PERSON_GROUP_NAME)
           INNER JOIN DOC_PERSONS
              ON     (DOC_PERSON_GROUPS.ID_DOC = DOC_PERSONS.ID_DOC)
                 AND (DOC_PERSON_GROUPS.PERSON_GROUP_NUM =
                         DOC_PERSONS.PERSON_GROUP_NUM)
            WHERE DOC_PERSONS.ID_DOC = IN_ID_DOC
            AND PERSON_GROUP_NAME = IN_ATTR_VALUE  
            ORDER BY PERSON_NUM;      
            
    CURSOR C_PERSON_TYPE(NUM_POINT NUMBER) IS
        -- достаем информацию по указанному человеку        
    SELECT LEVEL,
           '/view' || REGEXP_REPLACE (SYS_CONNECT_BY_PATH (PRIOR attr_code, '/'), '^/','') AS parent_tag,
           DTA.ATTR_NUM,
           DTA.ID_DOC_TEMPL_ATTR_PARENT,--DTA.ATTR_NUM_PARENT,
           DTA.ATTR_CODE,
           DTA.ATTR_VALUE,
           DTA.MIN_VALUE,
           DTA.MAX_VALUE,
           DTA.MIN_LENGTH,
           DTA.MAX_LENGTH,
           DTA.IS_VISIBLE,
           DTA.IS_EDITABLE,
           DTA.IS_REQUIRED,
           DTA.ATTR_FOOTER,
           DTA.ATTR_HEADER,
           DTA.ATTR_PREFIX,
           DTA.ATTR_POSTFIX,
           DTA.TABLE_REF,
           DTA.COLUMN_REF,
           DTA.ATTR_TYPE,
           MASK
      FROM (SELECT DTA.*
              FROM DOC_TEMPL_ATTR DTA, DOC_TEMPL DT
             WHERE DT.ID_DOC_TYPE = IN_ID_DOC_TYPE AND DT.ID_DOC_TEMPL = DTA.ID_DOC_TEMPL)
           DTA
        START WITH ATTR_NUM = NUM_POINT
        CONNECT BY PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT --ATTR_NUM = ATTR_NUM_PARENT
          ORDER BY ATTR_NUM;            
        
    doc            DBMS_XMLDOM.DOMDocument; -- объект документа
    rootElement    DBMS_XMLDOM.DOMElement; -- корневой элемент 
    paramsElement1 DBMS_XMLDOM.DOMElement; -- элемент 1 уровня 
    paramsElement2 DBMS_XMLDOM.DOMElement; -- элемент 2 уровня
    docPersonsElement DBMS_XMLDOM.DOMElement;
    docPersonsDetailElement DBMS_XMLDOM.DOMElement;
    textNode dbms_xmldom.domtext; -- значение узла
        
    node           DBMS_XMLDOM.DOMNode; -- узел
    l_nameText dbms_xmldom.domtext;
    c              CLOB;
    
    ATTR_VALUE_TEXT VARCHAR2(1000 CHAR);
    xmlOutput     XmlType;

BEGIN
    SELECT ID_DOC_TYPE INTO IN_ID_DOC_TYPE FROM DOC WHERE ID_DOC = IN_ID_DOC;  
    
    doc := dbms_xmldom.createDocument('', null, null);
    rootElement := DBMS_XMLDOM.createElement(doc, 'view');
    node        := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(doc),
                                         DBMS_XMLDOM.makeNode(rootElement));
          
    FOR INF_PERSON_GROUPS IN C_PERSON_GROUPS LOOP
        -- строим первыйи  (docPersonSign) и второй (docPersonGroups) уровни   
        paramsElement1 := DBMS_XMLDOM.createElement(doc, INF_PERSON_GROUPS.ATTR_CODE);
        node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(rootElement),
                                  DBMS_XMLDOM.makeNode(paramsElement1));
        SET_ALL_ATTRIBUTES(paramsElement1,    
            INF_PERSON_GROUPS.ATTR_VALUE,  
            INF_PERSON_GROUPS.ATTR_NUM,    
            INF_PERSON_GROUPS.MIN_VALUE,   
            INF_PERSON_GROUPS.MAX_VALUE,   
            INF_PERSON_GROUPS.MIN_LENGTH,  
            INF_PERSON_GROUPS.MAX_LENGTH,  
            INF_PERSON_GROUPS.IS_VISIBLE,  
            INF_PERSON_GROUPS.IS_EDITABLE, 
            INF_PERSON_GROUPS.IS_REQUIRED, 
            INF_PERSON_GROUPS.ATTR_FOOTER, 
            INF_PERSON_GROUPS.ATTR_HEADER, 
            INF_PERSON_GROUPS.ATTR_PREFIX, 
            INF_PERSON_GROUPS.ATTR_POSTFIX,
            INF_PERSON_GROUPS.MASK 
            );                            
        IF INF_PERSON_GROUPS.LEVEL = 2 THEN
            -- информация по отдельным людям
            FOR INF_COUNT_PERSON IN C_PERSONS(INF_PERSON_GROUPS.ATTR_VALUE)  LOOP
                -- цикл строит нужное количество docPersons для родительского docPersonGroups 
                FOR INF_PERSON IN C_PERSON_TYPE(INF_PERSON_GROUPS.ATTR_NUM) LOOP
                    -- создаем docPersons и его элементы (типа Job, Fio и т.д.)  
                    IF INF_PERSON_GROUPS.ATTR_NUM <> INF_PERSON.ATTR_NUM THEN
                        IF INF_PERSON.LEVEL = 2 THEN 
                            -- узел самого docPersons и его атрибуты
                            docPersonsElement := DBMS_XMLDOM.createElement(doc, INF_PERSON.ATTR_CODE);
                            node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(paramsElement1),
                                          DBMS_XMLDOM.makeNode(docPersonsElement));
                            SET_ALL_ATTRIBUTES(docPersonsElement,    
                                INF_PERSON.ATTR_VALUE,  
                                INF_PERSON.ATTR_NUM,    
                                INF_PERSON.MIN_VALUE,   
                                INF_PERSON.MAX_VALUE,   
                                INF_PERSON.MIN_LENGTH,  
                                INF_PERSON.MAX_LENGTH,  
                                INF_PERSON.IS_VISIBLE,  
                                INF_PERSON.IS_EDITABLE, 
                                INF_PERSON.IS_REQUIRED, 
                                INF_PERSON.ATTR_FOOTER, 
                                INF_PERSON.ATTR_HEADER, 
                                INF_PERSON.ATTR_PREFIX, 
                                INF_PERSON.ATTR_POSTFIX,
                                INF_PERSON.MASK 
                                );                         
                        ELSE
                            -- узел элетента (типа Job, Fio и т.д.), его атрибуты и значение, которое достается функцией GET_ATTR_VALUE
                            ATTR_VALUE_TEXT := GET_ATTR_VALUE(IN_ID_DOC, 
                                                              INF_PERSON.TABLE_REF, 
                                                              INF_PERSON.COLUMN_REF, 
                                                              INF_COUNT_PERSON.PERSON_GROUP_NUM, 
                                                              INF_COUNT_PERSON.PERSON_NUM, 
                                                              INF_PERSON.ATTR_TYPE);
                            textNode:= DBMS_XMLDOM.createTextNode(doc, ATTR_VALUE_TEXT);
                               
                            docPersonsDetailElement := DBMS_XMLDOM.createElement(doc, INF_PERSON.ATTR_CODE);
                            node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(docPersonsElement),
                                          DBMS_XMLDOM.makeNode(docPersonsDetailElement));
                            node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(docPersonsDetailElement),
                                          DBMS_XMLDOM.makeNode(textNode));
                            SET_ALL_ATTRIBUTES(docPersonsDetailElement,    
                                INF_PERSON.ATTR_VALUE,  
                                INF_PERSON.ATTR_NUM,    
                                INF_PERSON.MIN_VALUE,   
                                INF_PERSON.MAX_VALUE,   
                                INF_PERSON.MIN_LENGTH,  
                                INF_PERSON.MAX_LENGTH,  
                                INF_PERSON.IS_VISIBLE,  
                                INF_PERSON.IS_EDITABLE, 
                                INF_PERSON.IS_REQUIRED, 
                                INF_PERSON.ATTR_FOOTER, 
                                INF_PERSON.ATTR_HEADER, 
                                INF_PERSON.ATTR_PREFIX, 
                                INF_PERSON.ATTR_POSTFIX,
                                INF_PERSON.MASK
                                );                         
                        END IF;
                    END IF;                   
                END LOOP;                        
            END LOOP;
        END IF;               
    END LOOP;
    
    dbms_lob.createtemporary(c, true, dbms_lob.session);
    dbms_xmldom.writeToClob(doc, c);
    xmlOutput := SYS.XMLTYPE(c);  
    DBMS_LOB.FreeTemporary(c);    
    --dbms_output.put_line(xmlOutput.getClobVal);
    RETURN xmlOutput;
END;
*/
-- выбирает значение поля VAL_COLUMN из REF_TABLE если поле REF_COLUMN равно значению REF_VAL
FUNCTION GET_FK_VAL(
    REF_TABLE IN VARCHAR2, 
    REF_COLUMN IN VARCHAR2, 
    VAL_COLUMN IN VARCHAR2,
    REF_VAL IN VARCHAR2
)RETURN VARCHAR2
IS
    STR VARCHAR2(30000);
    REZ VARCHAR2(30000);
BEGIN
    STR:= 'SELECT '||VAL_COLUMN ||' FROM '||REF_TABLE||' WHERE '|| REF_COLUMN||' = '||REF_VAL ||' AND ROWNUM = 1';
    --DBMS_OUTPUT.PUT_LINE(STR);
    EXECUTE IMMEDIATE STR INTO REZ;
    RETURN REZ;
EXCEPTION
    WHEN OTHERS THEN
        RETURN '';      
END;
FUNCTION TEST RETURN NUMBER
IS
    IN_ID_DOC NUMBER := 14;
    SELECTED_XMLTABLE KONF.PKG_XML.TYPE_XMLTABLE; 
    CURR_XML XMLTYPE;
    ONE_XMLTABLE XMLTYPE;
    
    IN_ID_DOC_TYPE NUMBER;
    
    CURSOR ALL_TABLES
    IS
    SELECT LEVEL, A.*
                  FROM (SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                          FROM NRI.XML_TUNING_DT DT
                         WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                        UNION
                        SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                          FROM NRI.XML_TUNING_DT DT
                         WHERE (    DT.ID_TYPE_DOC IS NULL
                                AND NOT EXISTS
                                        (SELECT DT.NUM_TABLE, DT.NAME_TABLE
                                           FROM NRI.XML_TUNING_DT DT
                                          WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                                                                   ))) A
                 WHERE LEVEL = 1
            START WITH ID_PARENT IS NULL
            CONNECT BY PRIOR ID_XML_TUNING_DT = ID_PARENT
/*        SELECT *
        FROM (SELECT DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                FROM NRI.XML_TUNING_DT DT
               WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
              UNION
              SELECT DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                FROM NRI.XML_TUNING_DT DT
               WHERE (    DT.ID_TYPE_DOC IS NULL
                      AND NOT EXISTS
                             (SELECT DT.NUM_TABLE, DT.NAME_TABLE
                                FROM NRI.XML_TUNING_DT DT
                               WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE)))
        ORDER BY NUM_TABLE*/;

    CNT NUMBER;   
PROCEDURE SUB_LEVEL (IN_ID_PARENT IN NUMBER, IN_XML IN OUT XMLTYPE)
    IS
    SUB_XMLTABLE XMLTYPE;
    SQL_STR VARCHAR2(30000 CHAR);
    ID_SEL VARCHAR2(100);
    doc            DBMS_XMLDOM.DOMDocument;
    doc1            DBMS_XMLDOM.DOMDocument;
    doc2            DBMS_XMLDOM.DOMDocument;
    el DBMS_XMLDOM.DOMNodeList;
    el1 DBMS_XMLDOM.DOMNodeList;
    el_to_update DBMS_XMLDOM.DOMNodeList; 
    I NUMBER;
    J NUMBER;
    l_nlist DBMS_XMLDOM.DOMNodeList; 
    ID_FOR_SEL_PARENT VARCHAR2(100);
    ID_FOR_SEL VARCHAR2(100);
    node           DBMS_XMLDOM.DOMNode;
    node1           DBMS_XMLDOM.DOMNode;
    node2           DBMS_XMLDOM.DOMNode;
    BEGIN
        --DBMS_OUTPUT.PUT_LINE(IN_XML.getclobval);
        DOC := dbms_xmldom.newDOMDocument(IN_XML);
        
        FOR CC_SUB_LEVEL
            IN (              SELECT LEVEL, B.* 
            FROM (  SELECT /*LEVEL, */A.*, PRIOR NAME_TABLE PARENT_TABLE_NAME, NVL(PRIOR FIELD_SEL, 'ID_DOC') PARENT_FIELD_SEL
                      FROM (SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                              FROM NRI.XML_TUNING_DT DT
                             WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                            UNION
                            SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                              FROM NRI.XML_TUNING_DT DT
                             WHERE (    DT.ID_TYPE_DOC IS NULL
                                    AND NOT EXISTS
                                            (SELECT DT.NUM_TABLE, DT.NAME_TABLE
                                               FROM NRI.XML_TUNING_DT DT
                                              WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                                                                       ))) A
                     --WHERE LEVEL = 1
                START WITH NUM_TABLE = 1-- ID_PARENT = 33--IN_ID_PARENT
                CONNECT BY PRIOR ID_XML_TUNING_DT = ID_PARENT)
                B
                WHERE LEVEL = 1
                START WITH ID_PARENT = IN_ID_PARENT
                CONNECT BY PRIOR ID_XML_TUNING_DT = ID_PARENT
                 /* SELECT LEVEL, A.*
                      FROM (SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                              FROM NRI.XML_TUNING_DT DT
                             WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                            UNION
                            SELECT dt.* --DT.NUM_TABLE, DT.NAME_TABLE, DT.ORDER_BY
                              FROM NRI.XML_TUNING_DT DT
                             WHERE (    DT.ID_TYPE_DOC IS NULL
                                    AND NOT EXISTS
                                            (SELECT DT.NUM_TABLE, DT.NAME_TABLE
                                               FROM NRI.XML_TUNING_DT DT
                                              WHERE DT.ID_TYPE_DOC = IN_ID_DOC_TYPE
                                                                       ))) A
                     WHERE LEVEL = 1
                START WITH ID_PARENT = IN_ID_PARENT
                CONNECT BY PRIOR ID_XML_TUNING_DT = ID_PARENT*/)
        LOOP
            FOR CC IN (SELECT * FROM NRI.XML_TUNING WHERE TABLE_NAME = CC_SUB_LEVEL.PARENT_TABLE_NAME AND TABLE_SEL = CC_SUB_LEVEL.NAME_TABLE) LOOP
                --DBMS_OUTPUT.PUT_LINE(CC.COLUMN_NAME);
                DBMS_OUTPUT.PUT_LINE('CC_SUB_LEVEL.PARENT_FIELD_SEL '||CC_SUB_LEVEL.PARENT_FIELD_SEL);
                el := DBMS_XMLDOM.getElementsByTagName(doc, KONF.PKG_XML.CONVERT_STR_TO_TAG(CC_SUB_LEVEL.PARENT_FIELD_SEL));
                FOR I IN 0..DBMS_XMLDOM.getLength(EL)-1 LOOP
                          
                    l_nlist := DBMS_XMLDOM.getchildnodes(DBMS_XMLDOM.ITEM(EL,I));
                    IF NOT DBMS_XMLDOM.isNull(l_nlist) THEN
                        
                        FOR J IN 0..DBMS_XMLDOM.getLength(l_nlist)-1 LOOP      
                            IF DBMS_XMLDOM.getNodeName(DBMS_XMLDOM.item(l_nlist,i)) = '#text' THEN
                                DBMS_OUTPUT.PUT_LINE('START SUBLEVEL ' || IN_ID_PARENT); 
                                ID_FOR_SEL_PARENT:= DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.item(l_nlist,j));
                                DBMS_OUTPUT.PUT_LINE('ID_FOR_SEL_PARENT SUBLEVEL ' || ID_FOR_SEL_PARENT);  
                                EXIT;   
                            END IF;
                        END LOOP; 
                    SQL_STR:= 'SELECT '||CC.COLUMN_NAME||' FROM KONF.'||CC_SUB_LEVEL.PARENT_TABLE_NAME||' WHERE '||CC_SUB_LEVEL.PARENT_FIELD_SEL||' = ' ||ID_FOR_SEL_PARENT;
                    DBMS_OUTPUT.PUT_LINE (SQL_STR);
                    EXECUTE IMMEDIATE SQL_STR INTO ID_FOR_SEL;
                    SELECT KONF.PKG_XML.COLLECT_XML_ONE_TABLE_F(CC_SUB_LEVEL.NAME_TABLE, CC_SUB_LEVEL.FIELD_SEL, ID_FOR_SEL/*IN_ID_DOC*/, CC_SUB_LEVEL.ORDER_BY) INTO SUB_XMLTABLE FROM DUAL;
                    
                    DBMS_OUTPUT.PUT_LINE ('to add '||SUB_XMLTABLE.GETCLOBVAL);
                        
                    -- ищем, куда будем добавлять потомка
                    DOC2 := dbms_xmldom.newDOMDocument(IN_XML);
                    el_to_update := DBMS_XMLDOM.getElementsByTagName(doc2, KONF.PKG_XML.CONVERT_STR_TO_TAG(CC.COLUMN_NAME));
                    IF NOT DBMS_XMLDOM.isNull(el_to_update) THEN
                        node2 := DBMS_XMLDOM.ITEM(el_to_update,0);
                        --node :=  DBMS_XMLDOM.makenode(DOC);
                        --NODE:= dbms_xmldom.getNodeFromFragment (SUB_XMLTABLE);
                        DOC1 := dbms_xmldom.newDOMDocument(SUB_XMLTABLE);
                        el1:=  DBMS_XMLDOM.getElementsByTagName(doc1, KONF.PKG_XML.CONVERT_STR_TO_TAG(CC_SUB_LEVEL.PARENT_TABLE_NAME));
                        IF NOT DBMS_XMLDOM.isNull(el1) THEN
                           -- node := DBMS_XMLDOM.ITEM(el1,0);
                           node := DBMS_XMLDOM.clonenode(DBMS_XMLDOM.ITEM(el1,0), true);
                           node:= DBMS_XMLDOM.importnode (doc2 , node,  true);
                           -- NODE :=DBMS_XMLDOM.adoptnode(DOC, NODE);
                           node1 := DBMS_XMLDOM.appendChild(node2,node/* DBMS_XMLDOM.ITEM(el1,0)*/);        
                        END IF;
--                        node := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.ITEM(el_to_update,0),
--                                           -- DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(doc,'ssss'))
--                                            
--                                           dbms_xmldom.makenode (dbms_xmldom.newDOMDocument(SUB_XMLTABLE))
--                                          -- node
--                                           );
                     END IF;                           
                    END IF;
                END LOOP;
            END LOOP;    
            
            --SUB_XMLTABLE:= KONF.PKG_XML.COLLECT_XML_ONE_TABLE_F(CC_SUB_LEVEL.NAME_TABLE, CC_SUB_LEVEL.FIELD_SEL, 1/*IN_ID_DOC*/, CC_SUB_LEVEL.ORDER_BY);
            --DBMS_OUTPUT.PUT_LINE (CC_SUB_LEVEL.NAME_TABLE);
            --DBMS_OUTPUT.PUT_LINE('SUB_LEVEL');    
            SUB_LEVEL (CC_SUB_LEVEL.ID_XML_TUNING_DT, SUB_XMLTABLE);
        END LOOP;
        --select DBMS_XMLDOM.getxmltype(doc) into IN_XML from dual;
    END;
         
BEGIN
    SELECT ID_DOC_TYPE INTO IN_ID_DOC_TYPE FROM KONF.DOC  WHERE ID_DOC = IN_ID_DOC;
    
   -- SELECTED_XMLTABLE := TYPE_XMLTABLE();
    
    SELECT COUNT(ID_DOC_TYPE) INTO CNT FROM KONF.DOC  WHERE ID_DOC = IN_ID_DOC;
    /*IF CNT = 0 THEN
        RETURN NULL;
    END IF;  */
    EXECUTE IMMEDIATE 'SELECT XMLELEMENT("document", XMLAttributes('|| IN_ID_DOC || ' AS "ID_DOC", '|| IN_ID_DOC_TYPE || ' AS "ID_DOC_TYPE" '||')) FROM DUAL' INTO ONE_XMLTABLE;
  
    FOR ITEM IN ALL_TABLES LOOP
        SELECT  KONF.PKG_XML.COLLECT_XML_ONE_TABLE(ITEM.NAME_TABLE, IN_ID_DOC, ITEM.ORDER_BY) INTO CURR_XML FROM DUAL;
        IF CURR_XML IS NOT NULL THEN
--            DBMS_OUTPUT.PUT_LINE('BEFORE SUBLEVEL');
            SUB_LEVEL (ITEM.ID_XML_TUNING_DT, CURR_XML);
            SELECT  APPENDCHILDXML(ONE_XMLTABLE, 'document', CURR_XML ) 
                INTO ONE_XMLTABLE
            FROM DUAL;
--            DBMS_OUTPUT.PUT_LINE('AFTER SUBLEVEL');
        END IF;        
        --DBMS_OUTPUT.PUT_LINE(ONE_XMLTABLE.getclobval);
    END LOOP;
    

             
    
--    EXECUTE IMMEDIATE 'SELECT XMLELEMENT("document", XMLAttributes('|| IN_ID_DOC || ' AS "ID_DOC", '|| IN_ID_DOC_TYPE || ' AS "ID_DOC_TYPE" '||')) FROM DUAL' INTO ONE_XMLTABLE;
/*    
    FOR I IN SELECTED_XMLTABLE.FIRST..SELECTED_XMLTABLE.LAST
    LOOP
        SELECT  APPENDCHILDXML(ONE_XMLTABLE, 'document', SELECTED_XMLTABLE(I) ) 
            INTO ONE_XMLTABLE
        FROM DUAL;   
        --DBMS_OUTPUT.PUT_LINE(I);                
    END LOOP;*/

    --select XMLConcat(ONE_XMLTABLE, COLLECT_XML_PERSONS(IN_ID_DOC)) into  ONE_XMLTABLE from dual; 
    /*SELECT  APPENDCHILDXML(ONE_XMLTABLE, 'document', COLLECT_XML_PERSONS(IN_ID_DOC) ) 
            INTO ONE_XMLTABLE
        FROM DUAL; */
        
    DBMS_OUTPUT.PUT_LINE(ONE_XMLTABLE.getclobval);
    
        
RETURN 1;
END;

END PKG_XML;
/

