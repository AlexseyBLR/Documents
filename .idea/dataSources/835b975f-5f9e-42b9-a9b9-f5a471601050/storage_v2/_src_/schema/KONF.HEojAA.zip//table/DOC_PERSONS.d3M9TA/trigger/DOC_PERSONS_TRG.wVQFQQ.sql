create trigger DOC_PERSONS_TRG
  before insert
  on DOC_PERSONS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_PERSONS_SEQ.NEXTVAL;
  END IF; 
END;
/

