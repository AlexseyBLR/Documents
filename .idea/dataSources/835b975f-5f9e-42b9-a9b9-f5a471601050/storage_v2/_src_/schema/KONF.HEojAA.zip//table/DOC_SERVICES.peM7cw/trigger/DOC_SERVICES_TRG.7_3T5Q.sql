create trigger DOC_SERVICES_TRG
  before insert
  on DOC_SERVICES
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_SERVICES_SEQ.NEXTVAL;
  END IF; 
END;
/

