create trigger DOC_ASSETS_TRG
  before insert
  on DOC_ASSETS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_ASSETS_SEQ.NEXTVAL;
  END IF; 
END;
/

