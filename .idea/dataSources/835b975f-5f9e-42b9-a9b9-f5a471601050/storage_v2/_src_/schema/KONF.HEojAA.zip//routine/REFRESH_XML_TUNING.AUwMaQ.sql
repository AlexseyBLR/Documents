create PROCEDURE      REFRESH_XML_TUNING
IS
BEGIN
   -- Удаляем поля, которых уже нет в БД
   DELETE FROM NRI.XML_TUNING
         WHERE (table_NAME, column_NAME) IN
                  (SELECT table_NAME tn, column_NAME cn FROM NRI.XML_TUNING
                   MINUS
                   SELECT TABLE_NAME tn, COLUMN_NAME cn
                     FROM SYS.ALL_TAB_COLS
                    WHERE     OWNER = 'KONF'
                          AND TABLE_NAME IN (SELECT DISTINCT NAME_TABLE
                                               FROM NRI.XML_TUNING_DT)
                          AND COLUMN_ID IS NOT NULL);
   -- обновляем информацию по имеющимся полям и добавляем новые
   MERGE INTO NRI.XML_TUNING p
        USING (  SELECT TABLE_NAME,
                        COLUMN_ID,
                        COLUMN_NAME,
                        DATA_TYPE,
                        CASE
                           WHEN DATA_TYPE = 'DATE' THEN 10
                           ELSE DATA_LENGTH
                        END
                           AS DATA_LENGTH,
                        CASE
                           WHEN DATA_TYPE = 'CLOB' OR DATA_TYPE = 'BLOB' THEN 0
                           ELSE 1
                        END
                           AS IS_INSERT_XML,
                        KONF.PKG_XML.CONVERT_STR_TO_TAG (COLUMN_NAME) XML_TAG
                   FROM SYS.ALL_TAB_COLS
                  WHERE     OWNER = 'KONF'
                        AND TABLE_NAME IN (SELECT DISTINCT NAME_TABLE
                                             FROM NRI.XML_TUNING_DT)
                        AND COLUMN_ID IS NOT NULL
               ORDER BY TABLE_NAME, COLUMN_ID) p1
           ON (    p.TABLE_NAME = p1.TABLE_NAME
               AND P.COLUMN_NAME = P1.COLUMN_NAME)
   WHEN MATCHED
   THEN
      UPDATE SET
         p.NUM_COLUMN = p1.COLUMN_ID,
         P.DATA_TYPE = P1.DATA_TYPE,
         P.DATA_LENGTH = P1.DATA_LENGTH
   WHEN NOT MATCHED
   THEN
      INSERT     (P.TABLE_NAME,
                  P.NUM_COLUMN,
                  P.COLUMN_NAME,
                  P.DATA_TYPE,
                  P.DATA_LENGTH,
                  P.IS_INSERT_XML,
                  P.XML_TAG)
          VALUES (P1.TABLE_NAME,
                  P1.COLUMN_ID,
                  P1.COLUMN_NAME,
                  P1.DATA_TYPE,
                  P1.DATA_LENGTH,
                  p1.IS_INSERT_XML,
                  P1.XML_TAG);
END;
/

