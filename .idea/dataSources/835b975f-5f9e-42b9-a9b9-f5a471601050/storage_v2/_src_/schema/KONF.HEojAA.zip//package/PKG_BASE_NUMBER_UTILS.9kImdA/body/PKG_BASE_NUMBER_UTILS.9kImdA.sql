create PACKAGE BODY      PKG_BASE_NUMBER_UTILS
IS
   --------------------------------------------------------------------------------
   -- Предназначена для внутреннего использования другими функциями.
   -- Первый параметр - число, которое требуется перевести;
   -- второй - род существительного ('M' - мужской, 'F' - женский), к которому относится число.
   -- (c) Gleb V. Levin 1998
   --------------------------------------------------------------------------------
   FUNCTION int2speech (dig IN NUMBER, sex IN VARCHAR2)
      RETURN VARCHAR2
   IS
      ret         VARCHAR2 (300);
      REMAINDER   NUMBER;
   BEGIN
      REMAINDER := TRUNC (MOD (dig, 1000) / 100);

      SELECT DECODE (REMAINDER,
                     1, 'сто ',
                     2, 'двести ',
                     3, 'триста ',
                     4, 'четыреста ',
                     5, 'пятьсот ',
                     6, 'шестьсот ',
                     7, 'семьсот ',
                     8, 'восемьсот ',
                     9, 'девятьсот ')
        INTO ret
        FROM DUAL;

      REMAINDER := TRUNC (MOD (dig, 100) / 10);

      SELECT    ret
             || DECODE (
                   REMAINDER,
                   1, DECODE (MOD (dig, 10),
                              0, 'десять ',
                              1, 'одиннадцать ',
                              2, 'двенадцать ',
                              3, 'тринадцать ',
                              4, 'четырнадцать ',
                              5, 'пятнадцать ',
                              6, 'шестнадцать ',
                              7, 'семнадцать ',
                              8, 'восемнадцать ',
                              9, 'девятнадцать '),
                   2, 'двадцать ',
                   3, 'тридцать ',
                   4, 'сорок ',
                   5, 'пятьдесят ',
                   6, 'шестьдесят ',
                   7, 'семьдесят ',
                   8, 'восемьдесят ',
                   9, 'девяносто ')
        INTO ret
        FROM DUAL;

      IF REMAINDER = 1
      THEN
         RETURN ret;
      END IF;

      REMAINDER := MOD (dig, 10);

      SELECT    ret
             || DECODE (
                   REMAINDER,
                   1, DECODE (UPPER (sex),
                              'M', 'один ',
                              'F', 'одна '),
                   2, DECODE (UPPER (sex),  'M', 'два ',  'F', 'две '),
                   3, 'три ',
                   4, 'четыре ',
                   5, 'пять ',
                   6, 'шесть ',
                   7, 'семь ',
                   8, 'восемь ',
                   9, 'девять ')
        INTO ret
        FROM DUAL;

      RETURN ret;
   END;

   --------------------------------------------------------------------------------
   -- предназначена для внутреннего использования другими функциями.
   -- Первый параметр - преобразуемое число, второй - род существительного,
   -- третий используется самой функцией при рекурсивном вызове себя и должен быть равен нулю.
   -- (c) Gleb V. Levin 1998
   --------------------------------------------------------------------------------
   FUNCTION float2speech (VALUE IN NUMBER, sex IN VARCHAR2, POWER IN INTEGER)
      RETURN VARCHAR2
   IS
      ret   VARCHAR2 (300);
      p     VARCHAR2 (1);
      i     INTEGER;
   BEGIN
      IF POWER = 0
      THEN
         ret := '';
         p := sex;
      ELSE
         IF POWER > 1
         THEN
            p := 'M';
         ELSE
            p := 'F';
         END IF;

         i := TRUNC (VALUE);

         IF TRUNC (MOD (i, 100) / 10) = 1
         THEN
            i := 5;
         ELSE
            i := MOD (i, 10);
         END IF;

         IF i = 1
         THEN
            SELECT DECODE (p,  'M', ' ',  'F', 'а ') || ret
              INTO ret
              FROM DUAL;
         ELSIF (i >= 2) AND (i <= 4)
         THEN
            SELECT DECODE (p,  'M', 'а ',  'F', 'и ') || ret
              INTO ret
              FROM DUAL;
         ELSE
            SELECT DECODE (p,  'M', 'ов ',  'F', ' ') || ret
              INTO ret
              FROM DUAL;
         END IF;

         SELECT    DECODE (POWER,
                           1, 'тысяч',
                           2, 'миллион',
                           3, 'миллиард',
                           4, 'триллион')
                || ret
           INTO ret
           FROM DUAL;
      END IF;

      ret := int2speech (TRUNC (VALUE) MOD 1000, p) || ret;

      IF VALUE >= 1000
      THEN
         ret := float2speech (VALUE / 1000, p, POWER + 1) || ret;
      END IF;

      RETURN ret;
   END;

   --------------------------------------------------------------------------------
   -- Предназначена для перевода целых чисел.
   -- Первый параметр - число, второй - род существительного.
   -- (c) Gleb V. Levin 1998
   --------------------------------------------------------------------------------
   FUNCTION inttospeech (dig IN NUMBER, sex IN VARCHAR2)
      RETURN VARCHAR2
   IS
      ret   VARCHAR2 (300);
   BEGIN
      ret := float2speech (ABS (dig), sex, 0);

      IF ret IS NULL
      THEN
         RETURN 'ноль';
      ELSIF dig < 0
      THEN
         RETURN 'минус ' || ret;
      ELSE
         RETURN ret;
      END IF;

      RETURN ret;
   END;

   --------------------------------------------------------------------------------
   -- Предназначена для вывода некоторой суммы рублей и копеек прописью
   --------------------------------------------------------------------------------
   FUNCTION moneytospeech (quant IN NUMBER)
      RETURN VARCHAR2
   IS
      ret   VARCHAR2 (500);
      q     NUMBER;
   BEGIN
      q := ROUND (quant, 2);
      ret :=
            inttospeech (q, 'm')
         || ' руб. '
         || inttospeech (TO_CHAR (ABS (q - TRUNC (q)) * 100, '00'), 'f')
         || ' коп.';
      RETURN NLS_UPPER (SUBSTR (ret, 1, 1)) || SUBSTR (ret, 2);
   END;

   --------------------------------------------------------------------------------
   -- Предназначена для вывода некоторой суммы рублей и копеек прописью
   -- Окончание -Short означает, что копейки выводятся в виде числа
   -- (c) Gleb V. Levin 1998
   --------------------------------------------------------------------------------
   FUNCTION moneytospeechshort (quant IN NUMBER)
      RETURN VARCHAR2
   IS
      ret   VARCHAR2 (500);
      q     NUMBER;
   BEGIN
      q := ROUND (quant, 2);
      ret :=
            inttospeech (q, 'm')
         || ' руб. '
         || TO_CHAR (ABS (q - TRUNC (q)) * 100, '00')
         || ' коп.';
      RETURN NLS_UPPER (SUBSTR (ret, 1, 1)) || SUBSTR (ret, 2);
   END;

   --------------------------------------------------------------------------------
   -- Согласует переданное число и дни (месяцы, годы) в зависимости от флага (D- дни, M- месяцы, Y- года)
   -- (c) Evgeniy V. Kib 15,03,2010
   --------------------------------------------------------------------------------
   FUNCTION changedate (num IN NUMBER, dmy IN VARCHAR2)
      RETURN VARCHAR2
   IS
      VRESULT   VARCHAR2 (255);
      numt      NUMBER;
   BEGIN
      VRESULT := '';
      numt := ABS (num);

      IF 10 < MOD (numt, 100) AND MOD (numt, 100) < 15
      THEN
         SELECT DECODE (UPPER (dmy),
                        'D', 'дней',
                        'M', 'месяцев',
                        'Y', 'лет')
           INTO VRESULT
           FROM DUAL;
      ELSIF MOD (numt, 10) = 1
      THEN
         SELECT DECODE (UPPER (dmy),
                        'D', 'день',
                        'M', 'месяц',
                        'Y', 'год')
           INTO VRESULT
           FROM DUAL;
      ELSIF 1 < MOD (numt, 10) AND MOD (numt, 10) < 5
      THEN
         SELECT DECODE (UPPER (dmy),
                        'D', 'дня',
                        'M', 'месяца',
                        'Y', 'года')
           INTO VRESULT
           FROM DUAL;
      ELSE
         SELECT DECODE (UPPER (dmy),
                        'D', 'дней',
                        'M', 'месяцев',
                        'Y', 'лет')
           INTO VRESULT
           FROM DUAL;
      END IF;

      RETURN VRESULT;
   END changedate;

   --------------------------------------------------------------------------------
   -- Возвращает строку в формате : Число ("число прописью") лет\месяцев\дней в зависимости от флага
   -- Например: 5 (пять) дней
   -- (c) Evgeniy V. Kib 15,03,2010
   --------------------------------------------------------------------------------
   FUNCTION date_speech (num IN NUMBER, dmy IN VARCHAR2)
      RETURN VARCHAR2
   IS
      VRESULT   VARCHAR2 (255);
   BEGIN
      VRESULT :=
            num
         || ' ('
         || RTRIM (inttospeech (num, 'M'))
         || ') '
         || changedate (num, dmy);
      RETURN VRESULT;
   END date_speech;

   --------------------------------------------------------------------------------
   -- Предназначена для внутреннего использования другими функциями.
   -- Первый параметр - число, которое требуется перевести;
   -- второй - род существительного ('M' - мужской, 'F' - женский), к которому относится число.
   -- третий - падеж ('И'- Именительный,'Р'- Родительный,'Д'- Дательный,'В'- Винительный,'Т'- Творительный,'П'- Предложный)
   -- Лычковский Я.В, 17.03.2010
   --------------------------------------------------------------------------------
   FUNCTION int2speechpadeg (dig IN NUMBER, sex IN VARCHAR2, pdg IN VARCHAR2)
      RETURN VARCHAR2
   IS
      VRESULT     VARCHAR2 (300);
      REMAINDER   NUMBER;
   BEGIN
      IF (UPPER (pdg) = 'И') OR (UPPER (pdg) = 'В')
      THEN
         VRESULT := int2speech (dig, sex);
      ELSIF UPPER (pdg) = 'Р'
      THEN
         REMAINDER := TRUNC (MOD (dig, 1000) / 100);

         SELECT DECODE (REMAINDER,
                        1, 'ста ',
                        2, 'двухсот ',
                        3, 'трехсот ',
                        4, 'четырехсот ',
                        5, 'пятисот ',
                        6, 'шестисот ',
                        7, 'семисот ',
                        8, 'восьмисот ',
                        9, 'девятисот ')
           INTO VRESULT
           FROM DUAL;

         REMAINDER := TRUNC (MOD (dig, 100) / 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (MOD (dig, 10),
                                 0, 'десяти ',
                                 1, 'одиннадцати ',
                                 2, 'двенадцати ',
                                 3, 'тринадцати ',
                                 4, 'четырнадцати ',
                                 5, 'пятнадцати ',
                                 6, 'шестнадцати ',
                                 7, 'семнадцати ',
                                 8, 'восемнадцати ',
                                 9, 'девятнадцати '),
                      2, 'двадцати ',
                      3, 'тридцати ',
                      4, 'сорока ',
                      5, 'пятидесяти ',
                      6, 'шестидесяти ',
                      7, 'семидесяти ',
                      8, 'восьмидесяти ',
                      9, 'девяноста ')
           INTO VRESULT
           FROM DUAL;

         IF REMAINDER = 1
         THEN
            RETURN VRESULT;
         END IF;

         REMAINDER := MOD (dig, 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (UPPER (sex),
                                 'M', 'одого ',
                                 'F', 'одной '),
                      2, 'двух ',
                      3, 'трех ',
                      4, 'четырех ',
                      5, 'пяти ',
                      6, 'шести ',
                      7, 'семи ',
                      8, 'восьми ',
                      9, 'девяти ')
           INTO VRESULT
           FROM DUAL;
      ELSIF UPPER (pdg) = 'Д'
      THEN
         REMAINDER := TRUNC (MOD (dig, 1000) / 100);

         SELECT DECODE (REMAINDER,
                        1, 'ста ',
                        2, 'двухстам ',
                        3, 'трехстам ',
                        4, 'четырехстам ',
                        5, 'пятистам ',
                        6, 'шестистам ',
                        7, 'семистам ',
                        8, 'восьмистам ',
                        9, 'девятистам ')
           INTO VRESULT
           FROM DUAL;

         REMAINDER := TRUNC (MOD (dig, 100) / 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (MOD (dig, 10),
                                 0, 'десяти ',
                                 1, 'одиннадцати ',
                                 2, 'двенадцати ',
                                 3, 'тринадцати ',
                                 4, 'четырнадцати ',
                                 5, 'пятнадцати ',
                                 6, 'шестнадцати ',
                                 7, 'семнадцати ',
                                 8, 'восемнадцати ',
                                 9, 'девятнадцати '),
                      2, 'двадцати ',
                      3, 'тридцати ',
                      4, 'сорока ',
                      5, 'пятидесяти ',
                      6, 'шестидесяти ',
                      7, 'семидесяти ',
                      8, 'восьмидесяти ',
                      9, 'девяноста ')
           INTO VRESULT
           FROM DUAL;

         IF REMAINDER = 1
         THEN
            RETURN VRESULT;
         END IF;

         REMAINDER := MOD (dig, 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (UPPER (sex),
                                 'M', 'одному ',
                                 'F', 'одной '),
                      2, 'двум ',
                      3, 'трем ',
                      4, 'четырем ',
                      5, 'пяти ',
                      6, 'шести ',
                      7, 'семи ',
                      8, 'восьми ',
                      9, 'девяти ')
           INTO VRESULT
           FROM DUAL;
      ELSIF UPPER (pdg) = 'Т'
      THEN
         REMAINDER := TRUNC (MOD (dig, 1000) / 100);

         SELECT DECODE (REMAINDER,
                        1, 'ста ',
                        2, 'двумястами ',
                        3, 'тремястами ',
                        4, 'четырьмястами ',
                        5, 'пятьюстами ',
                        6, 'шестьюстами ',
                        7, 'семьюстами ',
                        8, 'восьмьюстами ',
                        9, 'девятьюстами ')
           INTO VRESULT
           FROM DUAL;

         REMAINDER := TRUNC (MOD (dig, 100) / 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (MOD (dig, 10),
                                 0, 'десятью ',
                                 1, 'одиннадцатью ',
                                 2, 'двенадцатью ',
                                 3, 'тринадцатью ',
                                 4, 'четырнадцатью ',
                                 5, 'пятнадцатью ',
                                 6, 'шестнадцатью ',
                                 7, 'семнадцатью ',
                                 8, 'восемнадцатью ',
                                 9, 'девятнадцатью '),
                      2, 'двадцатью ',
                      3, 'тридцатью ',
                      4, 'сорока ',
                      5, 'пятидесятью ',
                      6, 'шестидесятью ',
                      7, 'семидесятью ',
                      8, 'восьмидесятью ',
                      9, 'девяноста ')
           INTO VRESULT
           FROM DUAL;

         IF REMAINDER = 1
         THEN
            RETURN VRESULT;
         END IF;

         REMAINDER := MOD (dig, 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (UPPER (sex),
                                 'M', 'одним ',
                                 'F', 'одной '),
                      2, 'двумя ',
                      3, 'тремя ',
                      4, 'четырьмя ',
                      5, 'пятью ',
                      6, 'шестью ',
                      7, 'семью ',
                      8, 'восьмью ',
                      9, 'девятью ')
           INTO VRESULT
           FROM DUAL;
      ELSIF UPPER (pdg) = 'П'
      THEN
         REMAINDER := TRUNC (MOD (dig, 1000) / 100);

         SELECT DECODE (REMAINDER,
                        1, 'ста ',
                        2, 'двухстах ',
                        3, 'трехстах ',
                        4, 'четырехстах ',
                        5, 'пятистах ',
                        6, 'шестистах ',
                        7, 'семистах ',
                        8, 'восьмистах ',
                        9, 'девятистах ')
           INTO VRESULT
           FROM DUAL;

         REMAINDER := TRUNC (MOD (dig, 100) / 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (MOD (dig, 10),
                                 0, 'десяти ',
                                 1, 'одиннадцати ',
                                 2, 'двенадцати ',
                                 3, 'тринадцати ',
                                 4, 'четырнадцати ',
                                 5, 'пятнадцати ',
                                 6, 'шестнадцати ',
                                 7, 'семнадцати ',
                                 8, 'восемнадцати ',
                                 9, 'девятнадцати '),
                      2, 'двадцати ',
                      3, 'тридцати ',
                      4, 'сорока ',
                      5, 'пятидесяти ',
                      6, 'шестидесяти ',
                      7, 'семидесяти ',
                      8, 'восьмидесяти ',
                      9, 'девяноста ')
           INTO VRESULT
           FROM DUAL;

         IF REMAINDER = 1
         THEN
            RETURN VRESULT;
         END IF;

         REMAINDER := MOD (dig, 10);

         SELECT    VRESULT
                || DECODE (
                      REMAINDER,
                      1, DECODE (UPPER (sex),
                                 'M', 'одном ',
                                 'F', 'одной '),
                      2, 'двух ',
                      3, 'трех ',
                      4, 'четырех ',
                      5, 'пяти ',
                      6, 'шести ',
                      7, 'семи ',
                      8, 'восьми ',
                      9, 'девяти ')
           INTO VRESULT
           FROM DUAL;
      ELSE
         VRESULT := '';
      END IF;

      RETURN VRESULT;
   END;

   --------------------------------------------------------------------------------
   -- предназначена для вызова из функции float2speechpadeg рпеобразования тысяч(миллионов и т.д.) в нужный падеж
   --------------------------------------------------------------------------------
   FUNCTION GetPadegFloat2speech (VALUE   IN NUMBER,
                                  sex     IN VARCHAR2,
                                  POWER   IN INTEGER,
                                  pdg     IN VARCHAR2)
      RETURN VARCHAR2
   IS
      VRESULT   VARCHAR2 (300);
      p         VARCHAR2 (1);
      i         INTEGER;
   BEGIN
      IF POWER = 0
      THEN
         VRESULT := '';
         p := sex;
      ELSE
         IF (UPPER (pdg) = 'И') OR (UPPER (pdg) = 'В')
         THEN
            IF POWER > 1
            THEN
               p := 'M';
            ELSE
               p := 'F';
            END IF;

            i := TRUNC (VALUE);

            IF TRUNC (MOD (i, 100) / 10) = 1
            THEN
               i := 5;
            ELSE
               i := MOD (i, 10);
            END IF;

            IF i = 1
            THEN
               SELECT DECODE (p,  'M', ' ',  'F', 'а ') || VRESULT
                 INTO VRESULT
                 FROM DUAL;
            ELSIF (i >= 2) AND (i <= 4)
            THEN
               SELECT DECODE (p,  'M', 'а ',  'F', 'и ') || VRESULT
                 INTO VRESULT
                 FROM DUAL;
            ELSE
               SELECT DECODE (p,  'M', 'ов ',  'F', ' ') || VRESULT
                 INTO VRESULT
                 FROM DUAL;
            END IF;

            SELECT    DECODE (POWER,
                              1, 'тысяч',
                              2, 'миллион',
                              3, 'миллиард',
                              4, 'триллион')
                   || VRESULT
              INTO VRESULT
              FROM DUAL;
         ELSIF UPPER (pdg) = 'Р'
         THEN
            SELECT    DECODE (POWER,
                              1, 'тысячи ',
                              2, 'миллиона ',
                              3, 'миллиарда ',
                              4, 'триллиона ')
                   || VRESULT
              INTO VRESULT
              FROM DUAL;
         ELSIF UPPER (pdg) = 'Д'
         THEN
            SELECT    DECODE (POWER,
                              1, 'тысяче ',
                              2, 'миллиону ',
                              3, 'миллиарду ',
                              4, 'триллиону ')
                   || VRESULT
              INTO VRESULT
              FROM DUAL;
         ELSIF UPPER (pdg) = 'Т'
         THEN
            SELECT    DECODE (POWER,
                              1, 'тысячами ',
                              2, 'миллионами ',
                              3, 'миллиардами ',
                              4, 'триллионами ')
                   || VRESULT
              INTO VRESULT
              FROM DUAL;
         ELSIF UPPER (pdg) = 'П'
         THEN
            SELECT    DECODE (POWER,
                              1, 'тысячах ',
                              2, 'миллионах ',
                              3, 'миллиардах ',
                              4, 'триллионах ')
                   || VRESULT
              INTO VRESULT
              FROM DUAL;
         ELSE
            VRESULT := '';
         END IF;
      END IF;

      RETURN VRESULT;
   END GetPadegFloat2speech;

   --------------------------------------------------------------------------------
   -- предназначена для внутреннего использования другими функциями.
   -- Первый параметр - преобразуемое число, второй - род существительного,
   -- третий используется самой функцией при рекурсивном вызове себя и должен быть равен нулю.
   -- четвертый - требуемый падеж
   -- Лычковский Я.В, 17.03.2010
   --------------------------------------------------------------------------------
   FUNCTION float2speechpadeg (VALUE   IN NUMBER,
                               sex     IN VARCHAR2,
                               POWER   IN INTEGER,
                               pdg     IN VARCHAR2)
      RETURN VARCHAR2
   IS
      VRESULT   VARCHAR2 (300);
   BEGIN
      VRESULT :=
         GetPadegFloat2speech (VALUE,
                               sex,
                               POWER,
                               pdg);
      VRESULT := int2speechpadeg (TRUNC (VALUE) MOD 1000, sex, pdg) || VRESULT;

      IF VALUE >= 1000
      THEN
         VRESULT :=
               float2speechpadeg (VALUE / 1000,
                                  sex,
                                  POWER + 1,
                                  pdg)
            || VRESULT;
      END IF;

      RETURN VRESULT;
   END;

   --------------------------------------------------------------------------------
   -- Возвращает строку в формате : "число прописью" листов
   -- Например: пяти листах
   -- (c) Evgeniy V. Kib 16.03.2010
   --------------------------------------------------------------------------------
   FUNCTION count_sheet_speech (sht IN NUMBER)
      RETURN VARCHAR2
   IS
      SRESULT   VARCHAR2 (255);
      shtm      NUMBER;
   BEGIN
      SRESULT := '';
      shtm := ABS (sht);

      IF MOD (shtm, 100) = 11
      THEN
         SRESULT := 'листах';
      ELSIF MOD (shtm, 10) = 1
      THEN
         SRESULT := 'листе';
      ELSE
         SRESULT := 'листах';
      END IF;

      RETURN    float2speechpadeg (sht,
                                   'M',
                                   0,
                                   'П')
             || SRESULT;
   END count_sheet_speech;
--------------------------------------------------------------------------------
END pkg_base_number_utils;
/

