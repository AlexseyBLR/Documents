create PACKAGE      PKG_XML
IS
    TYPE TYPE_XMLTABLE IS TABLE OF XMLTYPE;
    
    FOMAT_DATE_STR VARCHAR2(10) := 'DD.MM.YYYY';
    
    -- собирает XML по указанной таблице IN_TAB_NAME 
    -- поле добавляются, если для него в NRI.XML_TUNING указано IS_INSERT_XML = 1 
    -- возвращает XML если XML успешно сформирован, NULL - если произошла ошибка
    FUNCTION COLLECT_XML_ONE_TABLE(IN_TAB_NAME IN  VARCHAR2, IN_ID_DOC IN NUMBER, IN_ORDER_BY IN VARCHAR2 DEFAULT '') RETURN XMLTYPE;
    FUNCTION COLLECT_XML_ONE_TABLE_F(IN_TAB_NAME IN  VARCHAR2, IN_SEL_F IN VARCHAR2, IN_SEL_F_VAL IN NUMBER, IN_ORDER_BY IN VARCHAR2 DEFAULT '') RETURN XMLTYPE;
    --PRAGMA RESTRICT_REFERENCES (COLLECT_XML_ONE_TABLE, WNDS, WNPS);
    
    -- собирает  один XML по всем таблицам, указанным в настроечной таблице NRI.XML_TUNING_DT
    -- плюс информация по блоку для подписывающих
    -- возвращает XML если XML успешно сформирован, NULL - если произошла ошибка
    FUNCTION COLLECT_DOC_XML(IN_ID_DOC IN NUMBER) RETURN XMLTYPE;
    
    -- записывает полученный XML в таблицу DOC, возвращает 1 если XML успешно сформирован, 0 - если произошла ошибка  
    FUNCTION UPDATE_DOC_XML(IN_ID_DOC IN NUMBER, IN_XML IN XMLTYPE) RETURN NUMBER;
    
    
    -- создает XML и записывает его в DOC.DOC_XML, возвращает 1 если XML успешно сформирован и записан, 0 - если произошла ошибка  
    FUNCTION CREATE_XML_DOC(IN_ID_DOC IN NUMBER) RETURN NUMBER;
    
    -- преобразовывает строки типа ID_DOC_BANK_DETAIL в idDocBankDetail
    FUNCTION CONVERT_STR_TO_TAG(IN_STR IN VARCHAR2) RETURN VARCHAR2;
    --PRAGMA RESTRICT_REFERENCES (CONVERT_STR_TO_TAG, WNDS, WNPS);

    --  собирает XML с информацией по блоку для подписывающих 
    FUNCTION COLLECT_XML_PERSONS (IN_ID_DOC IN NUMBER ) RETURN XMLTYPE;
    
    -- выбирает значение поля VAL_COLUMN из REF_TABLE если поле REF_COLUMN равно значению REF_VAL
    FUNCTION GET_FK_VAL(
        REF_TABLE IN VARCHAR2, 
        REF_COLUMN IN VARCHAR2, 
        VAL_COLUMN IN VARCHAR2,
        REF_VAL IN VARCHAR2
    )RETURN VARCHAR2;
    
    FUNCTION TEST RETURN NUMBER;
END PKG_XML;
/

