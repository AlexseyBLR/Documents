create trigger DOC_DOCS_TRG_AFTER_IU
  after insert or update
  on DOC_DOCS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_DOCS_HISTORY (ID_ROW_DOC,
                                         ID_DOC,
                                         ID_REF_DOC_TYPE,
                                         ID_REF_DOC,
                                         ID_DOC_TYPE,
                                         ORDER_NUM,
                                         DOC_SERIES,
                                         DOC_NUMBER,
                                         DOC_DATE,
                                         DOC_PLACE,
                                         DOC_NOTE,
                                         DOC_NUMBER_INNER,
                                         DOC_DATE_INNER,
                                         ID_ORG_TYPE,
                                         IS_EXT_CONF_PERSON,
                                         ID_CONF_PERSON,
                                         ID_ORG,
                                         ORG_NAME,
                                         ORG_DESC,
                                         ID_ORG_PLACE,
                                         ORG_PLACE_NAME,
                                         ORG_PLACE_ADDRESS,
                                         ID_USER,
                                         USER_FIO,
                                         USER_JOB,
                                         USER_DESC,
                                         IS_ACTUAL,
                                         TYPE_OPERATION,
                                         DATE_CHANGE,
                                         ID_USER_HISTORY)
           VALUES (:NEW."ID_DOC",
                   :NEW."ID_DOC",
                   :NEW."ID_REF_DOC_TYPE",
                   :NEW."ID_REF_DOC",
                   :NEW."ID_DOC_TYPE",
                   :NEW."ORDER_NUM",
                   :NEW."DOC_SERIES",
                   :NEW."DOC_NUMBER",
                   :NEW."DOC_DATE",
                   :NEW."DOC_PLACE",
                   :NEW."DOC_NOTE",
                   :NEW."DOC_NUMBER_INNER",
                   :NEW."DOC_DATE_INNER",
                   :NEW."ID_ORG_TYPE",
                   :NEW."IS_EXT_CONF_PERSON",
                   :NEW."ID_CONF_PERSON",
                   :NEW."ID_ORG",
                   :NEW."ORG_NAME",
                   :NEW."ORG_DESC",
                   :NEW."ID_ORG_PLACE",
                   :NEW."ORG_PLACE_NAME",
                   :NEW."ORG_PLACE_ADDRESS",
                   :NEW."ID_USER",
                   :NEW."USER_FIO",
                   :NEW."USER_JOB",
                   :NEW."USER_DESC",
                   :NEW."IS_ACTUAL",
                    TYPE_OPER,
                   SYSDATE,
                       1);
   END IF;
END;
/

