create view DOC_TEMPL_TREE_VIEW as
  SELECT LEVEL lvl,
           CONNECT_BY_ISLEAF leaf,
           dt.id_doc_templ,
           table_a.COLUMN_VALUE table_name_outer,
           RPAD (' ', 3 * (LEVEL - 1), ' ') || table_b.attr_type AS structural,
           table_b.id_doc_templ_attr,
           table_b.ATTR_TYPE,
           table_b.ATTR_NUM,
           table_b.ID_DOC_TEMPL_ATTR_PARENT,
           table_b.ATTR_XMLTAG,
                             table_b.ATTR_HEADER,
                             table_b.ATTR_CODE,
                             table_b.COLUMN_REF
      FROM doc_templ dt
           CROSS JOIN TABLE (sys.dbms_debug_vc2coll ('DOC_TEMPL_ATTR',
                                                     'DOC_TEMPL_DOCS',
                                                     'DOC_TEMPL_ORGS',
                                                     'DOC_TEMPL_PERS',
                                                     'DOC_TEMPL_WASTE',
                                                     'DOC_TEMPL_ASSETS',
                                                     'DOC_TEMPL_SERVICES',
                                                     'DOC_TEMPL_BD')) table_a
           LEFT JOIN (SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,        
                             a.COLUMN_REF,
                             'DOC_TEMPL_ATTR' AS table_name
                        FROM konf.DOC_TEMPL_ATTR a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,  
                             a.COLUMN_REF,
                             'DOC_TEMPL_DOCS' AS table_name
                        FROM konf.DOC_TEMPL_DOCS a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,    
                             a.COLUMN_REF,
                             'DOC_TEMPL_ORGS' AS table_name
                        FROM konf.DOC_TEMPL_ORGS a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,    
                             a.COLUMN_REF,
                             'DOC_TEMPL_PERS' AS table_name
                        FROM konf.DOC_TEMPL_PERS a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,      
                             a.COLUMN_REF,
                             'DOC_TEMPL_WASTE' AS table_name
                        FROM konf.DOC_TEMPL_WASTE a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,           
                             a.COLUMN_REF,
                             'DOC_TEMPL_ASSETS' AS table_name
                        FROM konf.DOC_TEMPL_ASSETS a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,             
                             a.COLUMN_REF,
                             'DOC_TEMPL_SERVICES' AS table_name
                        FROM konf.DOC_TEMPL_SERVICES a
                      UNION ALL
                      SELECT a.id_doc_templ_attr,
                             a.attr_type,
                             a.attr_num,
                             a.ID_DOC_TEMPL_ATTR_PARENT,
                             a.id_doc_templ,
                             a.ATTR_XMLTAG,
                             a.ATTR_HEADER,
                             a.ATTR_CODE,             
                             a.COLUMN_REF,
                             'DOC_TEMPL_BD' AS table_name
                        FROM konf.DOC_TEMPL_BD a) table_b
              ON     table_a.COLUMN_VALUE = table_b.table_name
                 AND table_b.id_doc_templ = dt.id_doc_templ
START WITH ID_DOC_TEMPL_ATTR_PARENT IS NULL OR dt.id_doc_templ IS NULL
CONNECT BY     PRIOR ID_DOC_TEMPL_ATTR = ID_DOC_TEMPL_ATTR_PARENT
           AND PRIOR table_name = table_name
           AND PRIOR table_b.id_doc_templ = table_b.id_doc_templ
/

