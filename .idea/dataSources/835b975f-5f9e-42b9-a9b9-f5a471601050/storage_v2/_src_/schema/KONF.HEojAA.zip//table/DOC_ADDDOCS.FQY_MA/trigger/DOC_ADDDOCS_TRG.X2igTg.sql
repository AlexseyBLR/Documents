create trigger DOC_ADDDOCS_TRG
  before insert
  on DOC_ADDDOCS
  for each row
  BEGIN   
  IF :NEW.ID_ADDDOC IS NULL THEN
    :NEW.ID_ADDDOC := DOC_ADDDOCS_SEQ.NEXTVAL;
  END IF; 
END;
/

