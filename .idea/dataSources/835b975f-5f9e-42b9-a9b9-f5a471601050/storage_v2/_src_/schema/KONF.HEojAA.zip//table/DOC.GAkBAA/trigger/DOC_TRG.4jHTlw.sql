create trigger DOC_TRG
  instead of insert or update
  on DOC
  for each row
COMPOUND TRIGGER
   TYPE_OPER   NUMBER;
   L_ID_DOC_TYPE NUMBER;
   L_ID_PARENT NUMBER;
   L_ID_DOC NUMBER;
/*BEFORE STATEMENT
    IS
    BEGIN
    DBMS_OUTPUT.PUT_LINE ('IN BEFORE STATEMENT');
    END
    BEFORE STATEMENT;*/
  
   BEFORE EACH ROW
    IS
    BEGIN
        CASE
        WHEN INSERTING THEN 
             IF :NEW.ID_DOC IS NULL THEN
              :NEW.ID_DOC := DOC_SEQ.NEXTVAL;
            END IF; 
        ELSE NULL;            
        END CASE;             
    END BEFORE EACH ROW;
    
    
    
    AFTER EACH ROW
    IS
    BEGIN
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
            L_ID_DOC_TYPE:=:NEW."ID_DOC_TYPE";
            L_ID_DOC:=:NEW."ID_DOC";
            L_ID_PARENT:=:NEW."ID_PARENT";
            IF L_ID_DOC_TYPE=11 THEN
               L_ID_DOC_TYPE:=10;
            END IF;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;
       IF :NEW.ID_DOC_STATUS_GENERIC > 0
        THEN --- В ИСТОРИИ ХРАНЯТЬСЯ ТОЛЬКО ИЗМЕНЕНИЯ В ДОКУМЕНТАХ СО СТАТУСОМ ВЫШЕ 0
      INSERT INTO KONF.DOC_HISTORY (ID_DOC,
                                    ID_DOC_TYPE,
                                    DOC_SERIES,
                                    DOC_NUMBER,
                                    DOC_DATE,
                                    DOC_PLACE,
                                    DOC_NOTE,
                                    ID_AUTHOR_USER,
                                    AUTHOR_USER_FIO,
                                    AUTHOR_USER_JOB,
                                    ID_AUTHOR_ORG,
                                    AUTHOR_ORG_NAME,
                                    ID_DEST_ORG,
                                    DEST_ORG_NAME,
                                    ACTION_BEGIN_DATE,
                                    ACTION_END_DATE,
                                    ACTION_PAUSE_TIME,
                                    ACTION_PAUSE_REASON,
                                    ID_STORAGE_DOC,
                                    ID_INVENTORY_DOC,
                                    ID_INVENTORY_EST_DOC,
                                    ID_TRANSFER_DOC,
                                    ID_BASIS_DOC,
                                    BASIS_DOC_NAME,
                                    BASIS_COST,
                                    ID_CONF_CATEGORY,
                                    ID_CONF_PERSON,
                                    ID_AUTH_ORG,
                                    AUTH_ORG_NAME,
                                    ID_COMP_ORG,
                                    COMP_ORG_NAME,
                                    COMP_ORG_TYPE_DECISION,
                                    IS_EXT_KEEPER,
                                    ID_KEEPER_ORG,
                                    KEEPER_ORG_NAME,
                                    ID_KEEPER_ORG_PLACE,
                                    KEEPER_ORG_PLACE_NAME,
                                    KEEPER_ORG_PLACE_ADDRESS,
                                    ID_EXT_KEEPER,
                                    IS_SIGN_REQUIRED,
                                    IS_SCAN_REQUIRED,
                                    DOC_XML,
                                    DOC_SIGN,
                                    ADVANCED_ATTRIBUTE,
                                    OTHER_ACTION_NAME,
                                    ADDENDUM_PAGES,
                                    ADDENDUM_COPIES,
                                    DOC_COPIES,
                                    ADDENDUM_NUMBER,
                                    ID_REQUEST_DOC,
                                    ID_DEPART_ORG,
                                    OTHER_ACTION_TERM,
                                    OTHER_ACTION_DECISION,
                                    DEST_USER_FIO,
                                    DEST_USER_JOB,
                                    OTHER_USER_INFO,
                                    GENERIC_ASSETS,
                                    GERERIC_PRODUCERS,
                                    GENERIC_DOCS,
                                    GENERIC_ASSET_DETAILS,
                                    GENERIC_PACKAGE,
                                    GENERIC_REVISION,
                                    GENERIC_PACKAGE_STATE,
                                    GENERIC_STORAGE,
                                    DEPART_ORG_NAME,
                                    ID_ACT_DOC,
                                    ID_KEEPER_USER,
                                    KEEPER_USER_DESC,
                                    TERM_TO,
                                    IS_ACTUAL,
                                    DATE_CHANGE,
                                    TYPE_OPERATION,
                                    ID_USER,
                                    ID_PARENT,
                                    INCOMING_NUMBER,                                      
                                    INCOMING_DATE,                                        
                                    OUTGOING_NUMBER,                                      
                                    OUTGOING_DATE,
                                    ID_DOC_STATUS_GENERIC,
                                    ID_DOC_STATUS,
                                    IS_EXT_AUTHOR,
                                    IS_EXT_DEST,
                                    ID_EXT_AUTHOR,
                                    ID_EXT_DEST,
                                    ID_DEST_USER
                                    )
           VALUES (:NEW."ID_DOC",
                   :NEW."ID_DOC_TYPE",
                   :NEW."DOC_SERIES",
                   :NEW."DOC_NUMBER",
                   :NEW."DOC_DATE",
                   :NEW."DOC_PLACE",
                   :NEW."DOC_NOTE",
                   :NEW."ID_AUTHOR_USER",
                   :NEW."AUTHOR_USER_FIO",
                   :NEW."AUTHOR_USER_JOB",
                   :NEW."ID_AUTHOR_ORG",
                   :NEW."AUTHOR_ORG_NAME",
                   :NEW."ID_DEST_ORG",
                   :NEW."DEST_ORG_NAME",
                   :NEW."ACTION_BEGIN_DATE",
                   :NEW."ACTION_END_DATE",
                   :NEW."ACTION_PAUSE_TIME",
                   :NEW."ACTION_PAUSE_REASON",
                   :NEW."ID_STORAGE_DOC",
                   :NEW."ID_INVENTORY_DOC",
                   :NEW."ID_INVENTORY_EST_DOC",
                   :NEW."ID_TRANSFER_DOC",
                   :NEW."ID_BASIS_DOC",
                   :NEW."BASIS_DOC_NAME",
                   :NEW."BASIS_COST",
                   :NEW."ID_CONF_CATEGORY",
                   :NEW."ID_CONF_PERSON",
                   :NEW."ID_AUTH_ORG",
                   :NEW."AUTH_ORG_NAME",
                   :NEW."ID_COMP_ORG",
                   :NEW."COMP_ORG_NAME",
                   :NEW."COMP_ORG_TYPE_DECISION",
                   :NEW."IS_EXT_KEEPER",
                   :NEW."ID_KEEPER_ORG",
                   :NEW."KEEPER_ORG_NAME",
                   :NEW."ID_KEEPER_ORG_PLACE",
                   :NEW."KEEPER_ORG_PLACE_NAME",
                   :NEW."KEEPER_ORG_PLACE_ADDRESS",
                   :NEW."ID_EXT_KEEPER",
                   :NEW."IS_SIGN_REQUIRED",
                   :NEW."IS_SCAN_REQUIRED",
                   :NEW."DOC_XML",
                   :NEW."DOC_SIGN",
                   :NEW."ADVANCED_ATTRIBUTE",
                   :NEW."OTHER_ACTION_NAME",
                   :NEW."ADDENDUM_PAGES",
                   :NEW."ADDENDUM_COPIES",
                   :NEW."DOC_COPIES",
                   :NEW."ADDENDUM_NUMBER",
                   :NEW."ID_REQUEST_DOC",
                   :NEW."ID_DEPART_ORG",
                   :NEW."OTHER_ACTION_TERM",
                   :NEW."OTHER_ACTION_DECISION",
                   :NEW."DEST_USER_FIO",
                   :NEW."DEST_USER_JOB",
                   :NEW."OTHER_USER_INFO",
                   :NEW."GENERIC_ASSETS",
                   :NEW."GERERIC_PRODUCERS",
                   :NEW."GENERIC_DOCS",
                   :NEW."GENERIC_ASSET_DETAILS",
                   :NEW."GENERIC_PACKAGE",
                   :NEW."GENERIC_REVISION",
                   :NEW."GENERIC_PACKAGE_STATE",
                   :NEW."GENERIC_STORAGE",
                   :NEW."DEPART_ORG_NAME",
                   :NEW."ID_ACT_DOC",
                   :NEW."ID_KEEPER_USER",
                   :NEW."KEEPER_USER_DESC",
                   :NEW."TERM_TO",
                   :NEW."IS_ACTUAL",
                   SYSDATE,
                   TYPE_OPER,
                   1,
                   :NEW."ID_PARENT",
                   :NEW."INCOMING_NUMBER",
                   :NEW."INCOMING_DATE",
                   :NEW."OUTGOING_NUMBER",
                   :NEW."OUTGOING_DATE",
                   :NEW."ID_DOC_STATUS_GENERIC",
                   :NEW."ID_DOC_STATUS",
                   :NEW."IS_EXT_AUTHOR",
                   :NEW."IS_EXT_DEST",
                   :NEW."ID_EXT_AUTHOR",
                   :NEW."ID_EXT_DEST",
                   :NEW."ID_DEST_USER"
                   );
   END IF;
   END AFTER EACH ROW;
   AFTER STATEMENT IS
    BEGIN
       IF TYPE_OPER=0 THEN
          --- ДЛЯ АКТА ОСМОТРА ТС СФОРМИРОВАТЬ ШАБЛОНЫ ЛИСТОВ ЗАМЕЧАНИЙ
                    IF L_ID_DOC_TYPE = 5     THEN
                 INSERT INTO KONF.ACT_INSPECTION_VEHICLE (
                              ID_DOC,
                              ID_VEHICLE_MODEL,
                              YEAR_ISSUE,
                              ID_TYPE_VEHICLE,
                              ID_TYPE_BODY,
                              TYPE_VEHICLE_TEXT,
                              REG_NUMBER,
                              REG_CERTIFICATE_NUM,
                              ID_REG_CERTIFICATE_COUNTRY,
                              CAR_BODY_NUM,
                              ENGINE_NUM,
                              ID_COLOR,
                              ID_COLOR_MOD,
                              ID_COLOR_SHADE,
                              NUMBER_SEATS,
                              ODOMETER_VALUE,
                              ODOMETER_NO_CAUSE,
                              ID_FUEL_TYPE,
                              FUEL_AMOUNT,
                              FUEL_NO_CAUSE,
                              FUEL_METERING_METHOD,
                              ID_DELIVER_METHOD,
                              TECHNICAL_CONDITION,
                              NUMBER_PHOTOS,
                              PERSONAL_ITEMS,
                              REMARKS_STATEMENTS)
                  SELECT  L_ID_DOC,
                          ID_VEHICLE_MODEL,
                          YEAR_ISSUE,
                          ID_TYPE_VEHICLE,
                          ID_TYPE_BODY,
                          TYPE_VEHICLE_TEXT,
                          REG_NUMBER,
                          REG_CERTIFICATE_NUM,
                          ID_REG_CERTIFICATE_COUNTRY,
                          CAR_BODY_NUM,
                          ENGINE_NUM,
                          ID_COLOR,
                          ID_COLOR_MOD,
                          ID_COLOR_SHADE,
                          NUMBER_SEATS,
                          ODOMETER_VALUE,
                          ODOMETER_NO_CAUSE,
                          ID_FUEL_TYPE,
                          FUEL_AMOUNT,
                          FUEL_NO_CAUSE,
                          FUEL_METERING_METHOD,
                          ID_DELIVER_METHOD,
                          TECHNICAL_CONDITION,
                          NUMBER_PHOTOS,
                          PERSONAL_ITEMS,
                          REMARKS_STATEMENTS
                    FROM KONF.ACT_INSPECTION_VEHICLE
                   WHERE ID_DOC = L_ID_PARENT;


               INSERT INTO KONF.ACT_INSPECTION_VENICLE_PART (
                              ID_DOC,
                              NUM_PART,
                              NUM_ELEMENT,
                              ID_ELEMENT,
                              IS_ELEMENT_YES,
                              ELEMENT_DESCRIPTION,
                              ID_ELEMENT_DESCRIPTION,
                              IS_ELEMENT_NO)
                  SELECT L_ID_DOC,
                         NUM_PART,
                         NUM_ELEMENT,
                         ID_ELEMENT,
                         IS_ELEMENT_YES,
                         ELEMENT_DESCRIPTION,
                         ID_ELEMENT_DESCRIPTION,
                         IS_ELEMENT_NO
                    FROM KONF.ACT_INSPECTION_VENICLE_PART
                   WHERE ID_DOC = L_ID_PARENT;
            END IF;
         ----  
         IF (L_ID_DOC_TYPE >5 AND  L_ID_DOC_TYPE <=10)   THEN
                 INSERT INTO KONF.ACT_INSPECTION_VEHICLE (
                              ID_DOC,
                              ID_VEHICLE_MODEL,
                              YEAR_ISSUE,
                              ID_TYPE_VEHICLE,
                              ID_TYPE_BODY,
                              TYPE_VEHICLE_TEXT,
                              REG_NUMBER,
                              REG_CERTIFICATE_NUM,
                              ID_REG_CERTIFICATE_COUNTRY,
                              CAR_BODY_NUM,
                              ENGINE_NUM,
                              ID_COLOR,
                              ID_COLOR_MOD,
                              ID_COLOR_SHADE,
                              NUMBER_SEATS,
                              ODOMETER_VALUE,
                              ODOMETER_NO_CAUSE,
                              ID_FUEL_TYPE,
                              FUEL_AMOUNT,
                              FUEL_NO_CAUSE,
                              FUEL_METERING_METHOD,
                              ID_DELIVER_METHOD,
                              TECHNICAL_CONDITION,
                              NUMBER_PHOTOS,
                              PERSONAL_ITEMS,
                              REMARKS_STATEMENTS)
                  SELECT L_ID_DOC,
                          ID_VEHICLE_MODEL,
                          YEAR_ISSUE,
                          ID_TYPE_VEHICLE,
                          ID_TYPE_BODY,
                          TYPE_VEHICLE_TEXT,
                          REG_NUMBER,
                          REG_CERTIFICATE_NUM,
                          ID_REG_CERTIFICATE_COUNTRY,
                          CAR_BODY_NUM,
                          ENGINE_NUM,
                          ID_COLOR,
                          ID_COLOR_MOD,
                          ID_COLOR_SHADE,
                          NUMBER_SEATS,
                          ODOMETER_VALUE,
                          ODOMETER_NO_CAUSE,
                          ID_FUEL_TYPE,
                          FUEL_AMOUNT,
                          FUEL_NO_CAUSE,
                          FUEL_METERING_METHOD,
                          ID_DELIVER_METHOD,
                          TECHNICAL_CONDITION,
                          NUMBER_PHOTOS,
                          PERSONAL_ITEMS,
                          REMARKS_STATEMENTS
                    FROM KONF.ACT_INSPECTION_VEHICLE
                   WHERE ID_DOC IN (SELECT ID_DOC FROM DOC WHERE ID_DOC_TYPE=L_ID_DOC_TYPE-1 AND ID_PARENT=L_ID_PARENT);


               INSERT INTO KONF.ACT_INSPECTION_VENICLE_PART (
                              ID_DOC,
                              NUM_PART,
                              NUM_ELEMENT,
                              ID_ELEMENT,
                              IS_ELEMENT_YES,
                              ELEMENT_DESCRIPTION,
                              ID_ELEMENT_DESCRIPTION,
                              IS_ELEMENT_NO)
                  SELECT L_ID_DOC,
                         NUM_PART,
                         NUM_ELEMENT,
                         ID_ELEMENT,
                         IS_ELEMENT_YES,
                         ELEMENT_DESCRIPTION,
                         ID_ELEMENT_DESCRIPTION,
                         IS_ELEMENT_NO
                    FROM KONF.ACT_INSPECTION_VENICLE_PART
                   WHERE ID_DOC IN  (SELECT ID_DOC FROM DOC WHERE ID_DOC_TYPE=L_ID_DOC_TYPE-1 AND ID_PARENT=L_ID_PARENT);
            END IF;
 
       
       
       END IF;
    END AFTER STATEMENT;
END;
/

