create trigger DOC_ORGS_TRG
  before insert
  on DOC_ORGS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_ORGS_SEQ.NEXTVAL;
  END IF; 
END;
/

