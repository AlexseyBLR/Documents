create trigger DOC_SERVICES_TRG_AFTER_IU
  after insert or update
  on DOC_SERVICES
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_SERVICES_HISTORY (ID_ROW_SERVICE,
                                             ID_DOC,
                                             ID_ORG_PRICE_LIST_ITEM,
                                             SERVICE_NAME,
                                             ID_MEASURE,
                                             SERVICE_AMOUNT,
                                             COST,
                                             MEASURE_NAME,
                                             VAT,
                                             SUM_WITHOUT_VAT,
                                             SUM_VAT,
                                             SUM_WITH_VAT,
                                             ORDER_NUM,
                                             IS_ACTUAL,
                                             TYPE_OPERATION,
                                             DATE_CHANGE,
                                             ID_USER_HISTORY)
           VALUES (:NEW."ID_ROW",
                   :NEW."ID_DOC",
                   :NEW."ID_ORG_PRICE_LIST_ITEM",
                   :NEW."SERVICE_NAME",
                   :NEW."ID_MEASURE",
                   :NEW."SERVICE_AMOUNT",
                   :NEW."COST",
                   :NEW."MEASURE_NAME",
                   :NEW."VAT",
                   :NEW."SUM_WITHOUT_VAT",
                   :NEW."SUM_VAT",
                   :NEW."SUM_WITH_VAT",
                   :NEW."ORDER_NUM",
                   :NEW."IS_ACTUAL",
                   TYPE_OPER,
                   SYSDATE,
                   1);
   END IF;
END;
/

