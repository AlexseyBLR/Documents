create trigger DOC_ADDDOCS_TRG_AFTER_IU
  after insert or update
  on DOC_ADDDOCS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_ADDDOCS_HISTORY (ID_ADDDOC,
                                            ID_DOC,
                                            ID_ADDDOC_TYPE,
                                            ADDDOC_SERIES,
                                            ADDDOC_NUMBER,
                                            ADDDOC_NOTE,
                                            ORDER_NUM,
                                            IS_ACTUAL,
                                            DATE_CHANGE,
                                            TYPE_OPERATION,
                                            ID_USER)
           VALUES (:NEW."ID_ADDDOC",
                   :NEW."ID_DOC",
                   :NEW."ID_ADDDOC_TYPE",
                   :NEW."ADDDOC_SERIES",
                   :NEW."ADDDOC_NUMBER",
                   :NEW."ADDDOC_NOTE",
                   :NEW."ORDER_NUM",
                   :NEW."IS_ACTUAL",
                   SYSDATE,
                   TYPE_OPER,
                   1);
   END IF;
END;
/

