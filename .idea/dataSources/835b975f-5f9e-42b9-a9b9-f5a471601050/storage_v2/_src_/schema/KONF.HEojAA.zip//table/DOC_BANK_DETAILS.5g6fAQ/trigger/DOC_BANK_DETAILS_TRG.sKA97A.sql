create trigger DOC_BANK_DETAILS_TRG
  before insert
  on DOC_BANK_DETAILS
  for each row
  BEGIN   
  IF :NEW.ID_ROW IS NULL THEN
    :NEW.ID_ROW := DOC_BANK_DETAILS_SEQ.NEXTVAL;
  END IF; 
END;
/

