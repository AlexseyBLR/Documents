create trigger DOC_TEMPL_PERS_TRG
  before insert
  on DOC_TEMPL_PERS
  for each row
  begin   
  if :NEW.ID_DOC_TEMPL_ATTR is null then
    :NEW.ID_DOC_TEMPL_ATTR := konf.DOC_TEMPL_ATTR_SEQ.nextval;
  end if; 
end;
/

