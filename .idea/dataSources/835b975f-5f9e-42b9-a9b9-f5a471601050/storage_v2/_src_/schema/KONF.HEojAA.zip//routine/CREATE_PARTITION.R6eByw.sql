create PROCEDURE      CREATE_PARTITION 
AS 
l_partition_exists exception;

PRAGMA EXCEPTION_INIT(l_partition_exists, -14074);
PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN 

 if  to_char(sysdate,'ddmm')='0101' then
--Создаем новое табличное пространство в БД

      execute immediate 'CREATE TABLESPACE P'||to_char(sysdate,'yy')||'_DATA DATAFILE 
  ''+DATA'' SIZE 100M AUTOEXTEND ON NEXT 50M MAXSIZE UNLIMITED LOGGING ONLINE EXTENT MANAGEMENT LOCAL AUTOALLOCATE BLOCKSIZE 8K SEGMENT SPACE MANAGEMENT AUTO FLASHBACK ON';
end if;
 
---Таблица должна быть секционированной
 execute immediate 'alter table KONF.GOODS add partition APPDOC_Q'||to_char(sysdate,'Q_YYYY')||' values less than (TO_DATE('''||  to_char((ADD_MONTHS (sysdate,3)),'SYYYY-MM-DD HH24:MI:SS') ||''',''SYYYY-MM-DD HH24:MI:SS'', ''NLS_CALENDAR=GREGORIAN'')) LOGGING    NOCOMPRESS     TABLESPACE USERS';
EXCEPTION   
    when l_partition_exists then null;

 END;
/

