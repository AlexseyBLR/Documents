create trigger DOC_PERSON_GROUPS_TRG_AFTER_IU
  after insert or update
  on DOC_PERSON_GROUPS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_PERSON_GROUPS_HISTORY (ID_ROW_PERSON_GROUP,
                                                  ID_DOC,
                                                  ORDER_NUM,
                                                  PERSON_GROUP_NAME,
                                                  MIN_PERSONS,
                                                  MAX_PERSONS,
                                                  IS_VISIBLE,
                                                  IS_ACTUAL,
                                                  TYPE_OPERATION,
                                                  DATE_CHANGE,
                                                  ID_USER_HISTORY)
           VALUES (:NEW."ID_ROW",
                   :NEW."ID_DOC",
                   :NEW."ORDER_NUM",
                   :NEW."PERSON_GROUP_NAME",
                   :NEW."MIN_PERSONS",
                   :NEW."MAX_PERSONS",
                   :NEW."IS_VISIBLE",
                   :NEW."IS_ACTUAL",
                   TYPE_OPER,
                   SYSDATE,
                   1);
   END IF;
END;
/

