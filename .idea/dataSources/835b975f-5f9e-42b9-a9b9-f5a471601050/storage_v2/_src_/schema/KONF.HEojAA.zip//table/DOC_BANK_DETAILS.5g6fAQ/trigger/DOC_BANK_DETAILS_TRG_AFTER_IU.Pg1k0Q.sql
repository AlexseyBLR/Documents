create trigger DOC_BANK_DETAILS_TRG_AFTER_IU
  after insert or update
  on DOC_BANK_DETAILS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_BANK_DETAILS_HISTORY (ID_ROW_BANK_DETAIL,
                                                 ID_DOC,
                                                 TYPE_PARTICIPANT,
                                                 PARTICIPANT,
                                                 ADDRESS,
                                                 UNP,
                                                 IBAN,
                                                 BIC,
                                                 BANK_NAME,
                                                 IS_ACTUAL,
                                                 ORDER_NUM,
                                                 DATE_CHANGE,
                                                 TYPE_OPERATION,
                                                 ID_USER)
           VALUES (:NEW."ID_ROW",
                   :NEW."ID_DOC",
                   :NEW."TYPE_PARTICIPANT",
                   :NEW."PARTICIPANT",
                   :NEW."ADDRESS",
                   :NEW."UNP",
                   :NEW."IBAN",
                   :NEW."BIC",
                   :NEW."BANK_NAME",
                   :NEW."IS_ACTUAL",
                   :NEW."ORDER_NUM",
                   SYSDATE,
                   TYPE_OPER,
                   1);
   END IF;
END;
/

