create trigger DOC_WASTE_TRG_AFTER_IU
  after insert or update
  on DOC_WASTE
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_WASTE_HISTORY (ID_DOC, 
                                            ID_ROW_WASTE,    
                                            ID_WASTE,
                                            WASTE_NAME,  
                                            ID_MEASURE,  
                                            WASTE_AMOUNT,
                                            ORDER_NUM,   
                                            MEASURE_NAME,
                                             TYPE_OPERATION,
                                             DATE_CHANGE,
                                             ID_USER_HISTORY)
           VALUES (:NEW."ID_DOC",
                   :NEW."ID_ROW",
                   :NEW."ID_WASTE",
                   :NEW."WASTE_NAME",
                   :NEW."ID_MEASURE",
                   :NEW."WASTE_AMOUNT",
                   :NEW."ORDER_NUM",
                   :NEW."MEASURE_NAME",
                   TYPE_OPER,
                   SYSDATE,
                   1);
   END IF;
END;
/

