create PACKAGE      pkg_docs IS

    -- функция регистрации входящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (OUT_MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION INCOMING_DOC_REGISTRATION(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_INCOMING_NUMBER IN VARCHAR2, -- входящий номер
        IN_INCOMING_DATE IN DATE,       -- дата регистрации входящего документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        IN_LOGIN_ACQUIRED IN VARCHAR2,  -- логин пользователя
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER;

    -- функция регистрации исходящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (OUT_MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION OUTGOING_DOC_REGISTRATION(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_OUTGOING_NUMBER IN VARCHAR2, -- входящий номер
        IN_OUTGOING_DATE IN DATE,       -- дата регистрации входящего документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER;

    -- функция, реализующая взятие в работу документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (OUT_MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION PROCEED_WITH_DOCUMENT(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    )
    RETURN NUMBER;
    
    -- функция, реализующ отправку исходящего документа
    -- возвращает
    -- -1 - есть ошибка, есть сообщение
    -- 0 - нет ошибок, нет сообщений (OUT_MESSAGE = NULL)
    -- 1 - нет ошибок, есть сообщение
    FUNCTION SENDING_OUTGOING_DOC(
        IN_ID_DOC IN NUMBER,            -- ID документа
        IN_ID_USER_ACQUIRED IN NUMBER,  -- ID пользователя, который взял в работу документ
        IN_SENDING_DATE DATE,           -- дата отправки
        IN_SENDING_MODE VARCHAR2,       -- способ отправки 
        OUT_MESSAGE OUT VARCHAR2        -- сообщение
    ) 
    RETURN NUMBER;
    
    FUNCTION TEST_INSERT_DB RETURN NUMBER;
END;
/

