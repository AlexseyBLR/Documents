create trigger NOTIF_TRG
  before insert
  on NOTIF
  for each row
  BEGIN   
  IF :NEW.ID_NOTIF IS NULL THEN
    :NEW.ID_NOTIF := NOTIF_SEQ.NEXTVAL;
  END IF; 
END;
/

