create trigger ACT_INSPECTION_VEHICLE_P_TRG
  before insert
  on ACT_INSPECTION_VENICLE_PART
  for each row
  begin   
  if :NEW."ID_PART" is null then 
     :NEW."ID_PART":= "ACT_INSPECTION_VEHICLE_P_SEQ".nextval; 
  end if; 
 
end;
/

