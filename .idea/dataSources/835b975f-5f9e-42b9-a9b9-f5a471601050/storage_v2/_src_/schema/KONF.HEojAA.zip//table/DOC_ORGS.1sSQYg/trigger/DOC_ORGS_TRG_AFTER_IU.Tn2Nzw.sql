create trigger DOC_ORGS_TRG_AFTER_IU
  after insert or update
  on DOC_ORGS
  for each row
  DECLARE
   TYPE_OPER   NUMBER;
BEGIN
   SELECT COUNT (*)
     INTO TYPE_OPER
     FROM DOC
    WHERE ID_DOC = :NEW."ID_DOC" AND ID_DOC_STATUS_GENERIC > 0;

   IF TYPE_OPER > 0
   THEN --- В истории храняться только изменения в документах со статусом выше 0
      CASE
         WHEN INSERTING
         THEN
            TYPE_OPER := 0;
         WHEN UPDATING
         THEN
            IF :NEW."IS_ACTUAL" = 0
            THEN
               TYPE_OPER := 2;
            ELSE
               TYPE_OPER := 1;
            END IF;
      END CASE;

      INSERT INTO KONF.DOC_ORGS_HISTORY (ID_ROW_ORG,
                                         ID_DOC,
                                         ID_REF_ORG_TYPE,
                                         ID_ORG_TYPE,
                                         ORDER_NUM,
                                         IS_EXT_CONF_PERSON,
                                         ID_CONF_PERSON,
                                         ID_ORG,
                                         ORG_NAME,
                                         ORG_DESC,
                                         ID_ORG_PLACE,
                                         ORG_PLACE_NAME,
                                         ORG_PLACE_ADDRESS,
                                         ID_USER,
                                         USER_FIO,
                                         USER_JOB,
                                         USER_DESC,
                                         IS_DOC_NOTICE,
                                         --ID_ROW,
                                         USER_BASE_DOC,
                                         ORG_ADDRESS,
                                         ORG_BANK_DETAILS,
                                         ORG_UNP,
                                         USER_FIO_INITIAL,
                                         IS_ACTUAL,
                                         TYPE_OPERATION,
                                         DATE_CHANGE,
                                         ID_USER_HISTORY)
           VALUES (:NEW."ID_ROW",
                   :NEW."ID_DOC",
                   :NEW."ID_REF_ORG_TYPE",
                   :NEW."ID_ORG_TYPE",
                   :NEW."ORDER_NUM",
                   :NEW."IS_EXT_CONF_PERSON",
                   :NEW."ID_CONF_PERSON",
                   :NEW."ID_ORG",
                   :NEW."ORG_NAME",
                   :NEW."ORG_DESC",
                   :NEW."ID_ORG_PLACE",
                   :NEW."ORG_PLACE_NAME",
                   :NEW."ORG_PLACE_ADDRESS",
                   :NEW."ID_USER",
                   :NEW."USER_FIO",
                   :NEW."USER_JOB",
                   :NEW."USER_DESC",
                   :NEW."IS_DOC_NOTICE",
                   --:NEW."ID_ROW",
                   :NEW."USER_BASE_DOC",
                   :NEW."ORG_ADDRESS",
                   :NEW."ORG_BANK_DETAILS",
                   :NEW."ORG_UNP",
                   :NEW."USER_FIO_INITIAL",
                   :NEW."IS_ACTUAL",
                   TYPE_OPER,
                   SYSDATE,
                         1);
   END IF;
END;
/

